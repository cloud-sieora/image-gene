import React, { useState, useEffect, createContext, useReducer, useCallback, useRef } from "react";
import {
  Row,
  Col,
  Card,
  Table,
  Tabs,
  Tab,
  Container,
  Button,
} from "react-bootstrap";
import './style.css'
import Aux from "../../hoc/_Aux";
import HLSVideoPlayer from "../Components/LiveHLSPlayer";
import Loader from "../CommonComponent/Loader";
import { BsArrowLeftShort } from "react-icons/bs";
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import TroubleshootIcon from '@mui/icons-material/Troubleshoot';
import ArrowDropUpIcon from '@mui/icons-material/ArrowDropUp';
import CloseIcon from '@mui/icons-material/Close';
import ArrowCircleLeftIcon from '@mui/icons-material/ArrowCircleLeft';
import ArrowCircleRightIcon from '@mui/icons-material/ArrowCircleRight';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import VideocamOffOutlinedIcon from '@mui/icons-material/VideocamOffOutlined';
import TuneOutlinedIcon from '@mui/icons-material/TuneOutlined';
import CircularProgress from '@mui/material/CircularProgress';
import FullscreenOutlinedIcon from '@mui/icons-material/FullscreenOutlined';
// import EventMenu from "./EventMenu";
import Events from "./Events";
import { date } from './DateTimeFun'
import { useDispatch, useSelector } from 'react-redux';
import Hls from "hls.js";
import * as api from '../Configurations/Api_Details'
import { WebRTCAdaptor } from '@antmedia/webrtc_adaptor';



export const Context = createContext()

function Dashboard() {
  const camera_details = JSON.parse(localStorage.getItem('cameraDetails'))
  const [playing, setPlaying] = useState(false);
  const [websocketConnected, setWebsocketConnected] = useState(false);
  const [streamId, setStreamId] = useState(camera_details.stream_id);
  const webRTCAdaptor = useRef(null);
  var playingStream = useRef(null);
  let pathName = window.location.pathname;
  let arr = pathName.split('/')

  const date1 = date()
  const { page, startdate, starttime, enddate, endtime, apply, select, selected_cameras } = useSelector((state) => state)
  console.log(selected_cameras);
  const [buttonval, setbuttonval] = useState(false);
  const [screenlogic, setscreenlogic] = useState(1);
  const [flag, setflag] = useState(false);

  localStorage.setItem("button_value", buttonval);
  localStorage.setItem("button_flag", flag);


  const [btn, setbtn] = useState('events')
  const [toggle, settoggle] = useState(true)
  const [toggle1, settoggle1] = useState(true)
  const [videoFlag, setvideoFlag] = useState(1)
  const [cameraName, setcameraName] = useState(arr[arr.length - 1])
  const [res, setres] = useState('')
  const [hlsDetail, sethlsDetail] = useState([])

  // const [startdate, setstartdate] = useState(date1[0])
  // const [starttime, setstarttime] = useState('00:00')
  // const [endtime, setendtime] = useState(`${date1[2]}:${date1[3]}`)
  // const [enddate, setenddate] = useState(date1[1])
  const [data, setdata] = useState([])

  useEffect(() => {
    webRTCAdaptor.current = new WebRTCAdaptor({
      websocket_url: 'wss://live.tentovision.com:5443/WebRTCAppEE/websocket',
      mediaConstraints: {
        video: true,
        audio: true,
      },
      peerconnection_config: {
        iceServers: [{ urls: 'stun:stun1.l.google.com:19302' }],
      },
      sdp_constraints: {
        OfferToReceiveAudio: false,
        OfferToReceiveVideo: true, // Set to true to receive video
      },
      remoteVideoId: `video0`,
      callback: (info, obj) => {
        if (info === 'initialized') {
          setWebsocketConnected(true)
          handlePlay()
        }
      },
      callbackError: function (error, message) {
        console.log(error);
        console.log(message);
        if (error === 'no_stream_exist') {
          let tech = document.getElementById(`tech`)
          tech.style.display = 'block'

          let live = document.getElementById(`live`)
          live.style.display = 'none'

          let load = document.getElementById(`load`)
          load.style.display = 'none'

          let buff = document.getElementById(`buff`)
          buff.style.display = 'none'

          // document.getElementById(`p1`).innerText(`"${camera_details.camera_gereral_name}"`)
          // document.getElementById(`p2`).innerText('No Stream Exist')
          handleStopPlaying();
          setPlaying(false);
        } else if (error === 'WebSocketNotConnected') {
          setvideoFlag(0)
        } else if (error === 'invalidStreamName') {
          let tech = document.getElementById(`tech`)
          tech.style.display = 'block'

          let live = document.getElementById(`live`)
          live.style.display = 'none'

          let load = document.getElementById(`load`)
          load.style.display = 'none'

          let buff = document.getElementById(`buff`)
          buff.style.display = 'none'

          // document.getElementById(`p1`).innerText(`"${camera_details.camera_gereral_name}"`)
          // document.getElementById(`p2`).innerText('Please Check the Stream Name')
        }
      },
    });

    return () => {
      if (playing)
        handleStopPlaying();
    }
  }, []);

  const handlePlay = () => {
    setPlaying(true);
    playingStream.current = streamId
    webRTCAdaptor.current.play(streamId);
  };

  const handleStopPlaying = () => {
    setPlaying(false);
    webRTCAdaptor.current.stop(playingStream.current);
  };

  useEffect(() => {
    setres('')
    let pathName = window.location.pathname;
    let arr = pathName.split('/')
    setcameraName(arr[arr.length - 1])

    getdata(startdate, enddate, arr[arr.length - 1])

  }, [apply])

  function getdata(startdate, enddate, cameraName) {
    let pathName = window.location.pathname;
    let arr = pathName.split('/')

    setdata([])

    const axios = require('axios');
    let data = JSON.stringify({
      "camera_id": camera_details._id,
      "camera_name": cameraName,
      // startdate
      "start_date": startdate,
      // enddate
      "end_date": enddate,
    });

    let config = {
      method: 'post',
      maxBodyLength: Infinity,
      url: api.ANALYTICS_LIST,
      headers: {
        'Content-Type': 'application/json'
      },
      data: data
    };

    axios.request(config)
      .then((response) => {
        // console.log(JSON.stringify(response.data.data));
        console.log(JSON.stringify(response.data));
        // let arr1 = []
        // let arr = []
        let element = document.getElementById('outerDiv').clientHeight
        let ele = document.getElementById('video0')
        ele.height = element

        setdata(response.data.data)
        if (response.data.data.length === 0) {
          setres('empty response')
        } else {
          setres('')
        }
        // response.data.data.map((data, j) => {

        //   if (arr.length != 0) {
        //     arr.map((val) => {
        //       let count = 0
        //       if (data.date != val) {
        //         count = count + 1
        //       } else {
        //         count = count - 1
        //       }

        //       if (count === arr.length) {
        //         arr.push(data.date)
        //       }
        //     })

        //   } else {
        //     arr.push(data.date)
        //   }


        // })

        // response.data.data.map((data, j) => {
        //   arr.map((val, i) => {
        //     if (data.date === val) {

        //       if (arr1[i] === undefined) {
        //         let arr = []
        //         arr.push(data)
        //         arr1[i] = arr
        //       } else {
        //         arr1[i].push(data)
        //       }
        //     }
        //   })
        // })
        // setdata(arr1)
        // setarr(arr1)
      })
      .catch((error) => {
        // let div = document.getElementById('videotech')
        // div.style.display = 'block'
        console.log(error);
      })
  }

  const golive = (url) => {
    // console.log(player);


    const player = document.getElementById('video0')

    if (Hls.isSupported() && player) {
      const video = player;
      const hls = new Hls({
        "debug": false,
        "enableWorker": true,
        "lowLatencyMode": true,
        "backBufferLength": 90
      });
      hls.loadSource(url);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, function () {
        video.muted = true;
        var playPromise = video.play();

        if (playPromise !== undefined) {
          // console.log(playPromise, "play");
          playPromise.then(val => {
            // console.log(val, "hdushdhsd");
            // console.log(i);
            let tech = document.getElementById(`tech`)
            tech.style.display = 'none'

            let live = document.getElementById(`live`)
            live.style.display = 'block'

            let load = document.getElementById(`load`)
            load.style.display = 'none'

            let buff = document.getElementById(`buff`)
            buff.style.display = 'none'
            // Automatic playback started!
            // Show playing UI.
            // We can now safely pause video...
          })
            .catch(error => {
              console.log(error, "error");
              // Auto-play was prevented
              // Show paused UI.
            });
        }
      });
      hls.on(Hls.Events.ERROR, function (error, data) {
        // console.log(error);
        // console.log(data.error.message);
        if (data.error.message !== 'A network error (status 404) occurred while loading manifest') {
          hls.loadSource(url)
          let tech = document.getElementById(`tech`)
          tech.style.display = 'none'

          let live = document.getElementById(`live`)
          live.style.display = 'none'

          let load = document.getElementById(`load`)
          load.style.display = 'none'

          let buff = document.getElementById(`buff`)
          buff.style.display = 'block'
        } else {
          let tech = document.getElementById(`tech`)
          tech.style.display = 'block'

          let live = document.getElementById(`live`)
          live.style.display = 'none'

          let load = document.getElementById(`load`)
          load.style.display = 'none'

          let buff = document.getElementById(`buff`)
          buff.style.display = 'none'
        }
        // hls.loadSource(url)
        // hls.startLoad(url)
        // hls.detachMedia()
        // hls.attachMedia(document.getElementById(`video${0}`))
      })

      hlsDetail.push({ 'hls': hls, 'player': player })
      // console.log(hlsDetail);
    }
  }


  if (screenlogic == 0) {
    return (
      <div>
        <Loader />
      </div>
    );
  } else {
    return (
      <>
        <div id="main">
          <Aux>

            <div>
              <div style={{ width: '100%', display: page === 1 ? 'none' : 'block' }}>
                <Row>

                  {/* <button className="backbtn" onClick={() => {
                    window.history.replaceState(null, null, "/Home/Home/")
                    window.location.reload();
                  }}><BsArrowLeftShort size={30} style={{ marginRight: '5px' }} /> Back</button> */}
                  {/* <Button style={{ marginLeft:20,marginBottom:15 }} onClick={() => {
                      setbuttonval(true)
                      setflag(!flag)
                      }} >YESTERDAY</Button>
                      <Button style={{ marginBottom:15 }}onClick={() => {
                      setbuttonval(false)
                      setflag(!flag)
                      }} >TODAY</Button> */}
                </Row>

                <Row>
                  <Col xl={12} lg={12} md={12} sm={12} xs={12}>

                    <div style={{ width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', position: 'relative' }}>
                      <div style={{ position: 'absolute', left: 0, right: 0 }}>
                        <button className="backbtn" onClick={() => {
                          window.history.replaceState(null, null, "/Home/Home/")
                          window.location.reload();
                        }}><BsArrowLeftShort size={30} style={{ marginRight: '5px' }} /> Back</button>
                      </div>

                      <h1 style={{ color: 'black', fontSize: '30px', marginLeft: '10px', fontWeight: 'bolder', display: 'flex', alignItems: 'flex-end' }}>{cameraName}<span><div style={{ width: '10px', height: '10px', backgroundColor: '#e32747', borderRadius: '50%' }}></div></span></h1>
                    </div>

                    <hr></hr>
                  </Col>
                </Row>

                {cameraName != '' && Screen != 1 ?
                  <Row className="justify-content-md-center">
                    <Col xl={8} lg={10} md={10} sm={12} xs={12} >

                      <div className="mx-auto my-3" style={{ backgroundColor: "black", alignItems: 'center', position: 'relative', }}>

                        <div id='outerDiv' style={{ backgroundColor: "black", }}>

                          <video
                            id={`video0`}
                            autoPlay
                            style={{
                              width: '100%',
                              height: '100%',
                              maxWidth: '100%',
                              maxHeight: '100%',
                              lineHeight: 0, display: 'block', objectFit: 'fill'
                            }}
                            onPlay={() => {
                              let tech = document.getElementById(`tech`)
                              tech.style.display = 'none'

                              let live = document.getElementById(`live`)
                              live.style.display = 'block'

                              let load = document.getElementById(`load`)
                              load.style.display = 'none'

                              let buff = document.getElementById(`buff`)
                              buff.style.display = 'none'
                            }}

                            onWaiting={() => {
                              let tech = document.getElementById(`tech`)
                              tech.style.display = 'none'

                              let live = document.getElementById(`live`)
                              live.style.display = 'none'

                              let load = document.getElementById(`load`)
                              load.style.display = 'none'

                              let buff = document.getElementById(`buff`)
                              buff.style.display = 'block'
                            }}

                            onPlaying={() => {
                              let tech = document.getElementById(`tech`)
                              tech.style.display = 'none'

                              let live = document.getElementById(`live`)
                              live.style.display = 'block'

                              let load = document.getElementById(`load`)
                              load.style.display = 'none'

                              let buff = document.getElementById(`buff`)
                              buff.style.display = 'none'
                            }}

                            onPause={() => {
                              let tech = document.getElementById(`tech`)
                              tech.style.display = 'block'

                              let live = document.getElementById(`live`)
                              live.style.display = 'none'

                              let load = document.getElementById(`load`)
                              load.style.display = 'none'

                              let buff = document.getElementById(`buff`)
                              buff.style.display = 'none'

                              // document.getElementById(`p1`).innerText(`"${camera_details.camera_gereral_name}" camera is offline`)
                              // document.getElementById(`p2`).innerText('Please switch on the camera and try again!')
                            }}

                            onError={() => {
                              let tech = document.getElementById(`tech`)
                              tech.style.display = 'block'

                              let live = document.getElementById(`live`)
                              live.style.display = 'none'

                              let load = document.getElementById(`load`)
                              load.style.display = 'none'

                              let buff = document.getElementById(`buff`)
                              buff.style.display = 'none'

                              // document.getElementById(`p1`).innerText(`"${camera_details.camera_gereral_name}" camera is offline`)
                              // document.getElementById(`p2`).innerText('Please switch on the camera and try again!')
                            }}
                          ></video>
                        </div>

                        <div id={`tech`} style={{ display: 'none' }}>
                          <div style={{ position: 'absolute', bottom: 0, top: 0, left: 0, right: 0, width: '100%', height: '100%', backgroundColor: 'black', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>

                            <img id='orginal_image' crossorigin="anonymous" style={{ filter: 'blur(1px)' }} width='100%' height="100%" src={`${camera_details.image_uri}`} onError={() => {
                              document.getElementById('errorimage').style.display = 'block'
                            }} onLoad={() => {
                              document.getElementById('errorimage').style.display = 'none'
                            }}></img>

                            <img id='errorimage' crossorigin="anonymous" style={{ filter: 'blur(1px)', style: 'none' }} width='100%' height="100%" src='https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Image_created_with_a_mobile_phone.png/1200px-Image_created_with_a_mobile_phone.png' onLoad={() => {
                              document.getElementById('orginal_image').style.display = 'none'
                            }}></img>

                            <div style={{ position: 'absolute', bottom: 0, top: 0, left: 0, right: 0, width: '100%', height: '100%', backgroundColor: 'black', opacity: '0.5' }}></div>

                            <div style={{ position: 'absolute', bottom: 0, top: 0, left: 0, right: 0, width: '100%', height: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column', padding: '5px' }}>
                              <div style={{ backgroundColor: 'red', borderRadius: '50%', padding: '5px' }}>
                                <VideocamOffOutlinedIcon style={{ color: 'white' }} />
                              </div>
                              <p id={`p1`} style={{ color: 'white', margin: '0px', fontWeight: 'bolder' }}>"{camera_details.camera_name}" camera is offline</p>
                              <p id={`p2`} style={{ color: 'white', margin: '0px', fontSize: '10px' }}>Please switch on the camera and try again!</p>
                            </div>
                          </div>
                        </div>

                        <div id='live' style={{ display: 'none' }}>
                          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px' }}>
                            <div style={{ display: 'flex', alignItems: 'center' }}>
                              <div style={{ width: '10px', height: '10px', borderRadius: '50%', backgroundColor: '#00ff00' }}></div>
                              <p style={{ color: 'white', fontWeight: 'bolder', marginLeft: '10px', marginBottom: 0, fontSize: '18px' }}>Live</p>
                            </div>
                            <FullscreenOutlinedIcon size={'15px'} style={{ color: 'white', cursor: 'pointer' }} onClick={() => {
                              let elem = document.getElementById("video0")
                              if (elem.requestFullscreen) {
                                elem.requestFullscreen();
                              } else if (elem.webkitRequestFullscreen) { /* Safari */
                                elem.webkitRequestFullscreen();
                              } else if (elem.msRequestFullscreen) { /* IE11 */
                                elem.msRequestFullscreen();
                              }
                            }} />
                          </div>
                        </div>

                        <div id={`load`} style={{ display: 'block', }}>
                          <div style={{ display: 'flex', alignItems: 'center', padding: '10px' }}>
                            <CircularProgress size={'15px'} style={{ color: 'white' }} />
                            <p style={{ color: 'white', fontWeight: 'bolder', marginLeft: '10px', marginBottom: 0, fontSize: '18px' }}>Loading</p>
                          </div>
                        </div>

                        <div id={`buff`} style={{ display: 'none', }}>
                          <div style={{ display: 'flex', alignItems: 'center', padding: '10px' }}>
                            <CircularProgress size={'15px'} style={{ color: 'white' }} />
                            <p style={{ color: 'white', fontWeight: 'bolder', marginLeft: '10px', marginBottom: 0, fontSize: '18px' }}>Buffering</p>
                          </div>
                        </div>

                        {videoFlag === 0 ?
                          <div style={{ position: 'absolute', bottom: 0, top: 0, left: 0, right: 0, width: '100%', height: '100%', backgroundColor: 'black', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
                            <VideocamOffOutlinedIcon style={{ color: 'gray' }} />
                            <p style={{ color: 'white' }}>No internet</p>
                          </div> : ''}

                      </div>
                    </Col>
                  </Row> : ''}
              </div>

              <Row style={{ padding: '10px' }}>
                <div style={{ display: page === 1 ? 'none' : 'block', width: '99.6%' }}>
                  <Row style={{ padding: '10px' }}>
                    <Col xl={2} lg={2} md={2} sm={3} xs={3} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: 0 }}>
                      <button id='btn1' style={{ border: 'none', borderBottom: '1px solid #e32747', backgroundColor: '#e6e8eb', paddingBottom: '20px', color: '#e32747', borderColor: '#e32747', width: '100%' }} onClick={() => {
                        let btn1 = document.getElementById('btn1')
                        btn1.style.color = '#e32747'
                        btn1.style.borderBottomColor = '#e32747'

                        let btn2 = document.getElementById('btn2')
                        btn2.style.color = 'gray'
                        btn2.style.borderBottomColor = 'gray'

                        let btn3 = document.getElementById('btn3')
                        btn3.style.color = 'gray'
                        btn3.style.borderBottomColor = 'gray'

                        let btn4 = document.getElementById('btn4')
                        btn4.style.color = 'gray'
                        btn4.style.borderBottomColor = 'gray'

                        setbtn('events')
                      }}>Events</button>
                    </Col>

                    <Col xl={2} lg={2} md={2} sm={3} xs={3} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: 0 }}>
                      <button id='btn2' style={{ border: 'none', borderBottom: '1px solid black', backgroundColor: '#e6e8eb', paddingBottom: '20px', color: 'gray', borderColor: 'gray', width: '100%' }} onClick={() => {
                        let btn1 = document.getElementById('btn1')
                        btn1.style.color = 'gray'
                        btn1.style.borderBottomColor = 'gray'

                        let btn2 = document.getElementById('btn2')
                        btn2.style.color = '#e32747'
                        btn2.style.borderBottomColor = '#e32747'

                        let btn3 = document.getElementById('btn3')
                        btn3.style.color = 'gray'
                        btn3.style.borderBottomColor = 'gray'

                        let btn4 = document.getElementById('btn4')
                        btn4.style.color = 'gray'
                        btn4.style.borderBottomColor = 'gray'

                        setbtn('tags')
                      }}

                      >Tags</button>
                    </Col>

                    <Col xl={2} lg={2} md={2} sm={3} xs={3} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: 0 }}>
                      <button id='btn3' style={{ border: 'none', borderBottom: '1px solid black', backgroundColor: '#e6e8eb', paddingBottom: '20px', color: 'gray', borderColor: 'gray', width: '100%' }} onClick={() => {
                        let btn1 = document.getElementById('btn1')
                        btn1.style.color = 'gray'
                        btn1.style.borderBottomColor = 'gray'

                        let btn2 = document.getElementById('btn2')
                        btn2.style.color = 'gray'
                        btn2.style.borderBottomColor = 'gray'

                        let btn3 = document.getElementById('btn3')
                        btn3.style.color = '#e32747'
                        btn3.style.borderBottomColor = '#e32747'

                        let btn4 = document.getElementById('btn4')
                        btn4.style.color = 'gray'
                        btn4.style.borderBottomColor = 'gray'

                        setbtn('ptz')
                      }}
                      >PTZ</button>
                    </Col>

                    <Col xl={2} lg={2} md={2} sm={3} xs={3} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: 0 }}>
                      <button id='btn4' style={{ border: 'none', borderBottom: '1px solid black', backgroundColor: '#e6e8eb', paddingBottom: '20px', color: 'gray', borderColor: 'gray', width: '100%' }} onClick={() => {
                        let btn1 = document.getElementById('btn1')
                        btn1.style.color = 'gray'
                        btn1.style.borderBottomColor = 'gray'

                        let btn2 = document.getElementById('btn2')
                        btn2.style.color = 'gray'
                        btn2.style.borderBottomColor = 'gray'

                        let btn3 = document.getElementById('btn3')
                        btn3.style.color = 'gray'
                        btn3.style.borderBottomColor = 'gray'

                        let btn4 = document.getElementById('btn4')
                        btn4.style.color = '#e32747'
                        btn4.style.borderBottomColor = '#e32747'

                        setbtn('settings')
                      }}
                      >Settings</button>
                    </Col>
                  </Row>
                </div>

                {
                  btn === 'events' ?
                    <Events data1={data} res={res} aditional_info={false} camera_name={cameraName} />
                    :
                    btn === 'tags' ?

                      <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                        <div style={{ marginLeft: '10px', marginTop: '40px', marginBottom: '40px' }}>
                          <div style={{ display: 'flex' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', border: '1px solid #0d0e90', alignItems: 'center', padding: '10px', borderRadius: '15px', marginRight: '10px' }}>
                              <p style={{ margin: 0, marginRight: '20px' }}>Office</p>
                              <CloseIcon />
                            </div>

                            <div style={{ display: 'flex', justifyContent: 'space-between', border: '1px solid #0d0e90', alignItems: 'center', padding: '10px', borderRadius: '15px' }}>
                              <p style={{ margin: 0, marginRight: '20px' }}>Office</p>
                              <CloseIcon />
                            </div>
                          </div>

                          <div style={{ marginTop: '20px' }}>
                            <input type="text" placeholder="+Add Tag" style={{ padding: '10px', borderRadius: '5px', border: '1px solid gray' }}></input>
                          </div>
                        </div>
                      </Col>

                      : btn === 'ptz' ?
                        <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                          <div style={{ width: '100%', marginLeft: '10px', marginTop: '40px' }}>
                            <p style={{ color: 'black', }}><span style={{ color: 'black', fontWeight: 'bolder' }}>BETA: </span>Camera moves when command pressed, but there is 5-10s lag before live stream is updated. Lag is shorter via mobile app and will be reduced to 1-2s on web.</p>

                            <div>

                              <Row>
                                <Col xl={5} lg={5} md={5} sm={2} xs={2}>
                                  <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'flex-end', width: '100%', height: '100%' }}>
                                    <AddIcon style={{ border: '2px solid black', fontSize: '50px' }} />
                                    <RemoveIcon style={{ border: '2px solid black', fontSize: '50px' }} />
                                  </div>
                                </Col>

                                <Col xl={3} lg={3} md={3} sm={10} xs={10}>
                                  <div>

                                    <Row>
                                      <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                          <ArrowCircleLeftIcon style={{ transform: 'rotate(90deg)', fontSize: '80px', }} />
                                        </div>
                                      </Col>

                                      <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                          <ArrowCircleLeftIcon style={{ fontSize: '80px' }} />
                                          <ArrowCircleRightIcon style={{ fontSize: '80px' }} />
                                        </div>
                                      </Col>

                                      <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'flex-end' }}>
                                          <ArrowCircleRightIcon style={{ transform: 'rotate(90deg)', fontSize: '80px' }} />
                                        </div>
                                      </Col>
                                    </Row>
                                  </div>
                                </Col>
                              </Row>



                            </div>
                          </div>
                        </Col>

                        : btn === 'settings' ?
                          <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                            <div>
                              <div>
                                <Row style={{ marginTop: '30px' }}>
                                  <Col xl={2} lg={2} md={2} sm={5} xs={5} style={{ display: 'flex', alignItems: 'center' }}>
                                    <p style={{ color: 'black', fontWeight: 'bolder', margin: 0 }}>Name</p>
                                  </Col>
                                  <Col xl={3} lg={3} md={3} sm={7} xs={7}>
                                    <input type="text" style={{ padding: '10px', borderRadius: '5px', width: '100%' }}></input>
                                  </Col>
                                </Row>

                                <Row style={{ marginTop: '30px' }}>
                                  <Col xl={2} lg={2} md={2} sm={5} xs={5} style={{ display: 'flex', alignItems: 'center' }}>
                                    <p style={{ color: 'black', fontWeight: 'bolder', margin: 0 }}>Cloud recording</p>
                                  </Col>
                                  <Col xl={10} lg={10} md={10} sm={7} xs={7}>
                                    <div>

                                      <div style={{ backgroundColor: toggle == true ? '#e32747' : '#a8a4a4', width: '3rem', height: '1.5rem', borderRadius: '15px', display: 'flex', justifyContent: toggle == true ? 'flex-end' : 'flex-start', alignItems: 'center', padding: '2px' }} onClick={() => {
                                        settoggle(!toggle)
                                      }}>
                                        <div style={{ backgroundColor: 'white', width: '1.3rem', height: '1.3rem', borderRadius: '50%' }}></div>
                                      </div>
                                    </div>
                                  </Col>
                                </Row>

                                <Row style={{ marginTop: '30px' }}>
                                  <Col xl={2} lg={2} md={2} sm={5} xs={5} style={{ display: 'flex', alignItems: 'center' }}>
                                    <p style={{ color: 'black', fontWeight: 'bolder', margin: 0 }}>Recording mode</p>
                                  </Col>
                                  <Col xl={3} lg={3} md={3} sm={7} xs={7}>
                                    <select style={{ padding: '10px', borderRadius: '5px', width: '100%' }}>
                                      <option value="Motion triggered">Motion triggered</option>
                                      <option value="Continuous">24/7 Continuous</option>
                                    </select>
                                  </Col>
                                </Row>

                                <Row style={{ marginTop: '30px' }}>
                                  <Col xl={2} lg={2} md={2} sm={5} xs={5} style={{ display: 'flex', alignItems: 'center' }}>
                                    <p style={{ color: 'black', fontWeight: 'bolder', margin: 0 }}>Recording video quality</p>
                                  </Col>
                                  <Col xl={3} lg={3} md={3} sm={7} xs={7}>
                                    <select style={{ padding: '10px', borderRadius: '5px', width: '100%' }}>
                                      <option value="Standard definition">Standard definition</option>
                                      <option value="2MP(1080p)">2MP(1080p)</option>
                                      <option value="4MP">4MP</option>
                                      <option value="8MP(4k)">8MP(4k)</option>
                                    </select>
                                  </Col>
                                </Row>

                                <Row style={{ marginTop: '30px' }}>
                                  <Col xl={2} lg={2} md={2} sm={5} xs={5} style={{ display: 'flex', alignItems: 'center' }}>
                                    <p style={{ color: 'black', fontWeight: 'bolder', margin: 0 }}>Analytics</p>
                                  </Col>
                                  <Col xl={10} lg={10} md={10} sm={7} xs={7}>
                                    <div>

                                      <div style={{ backgroundColor: toggle1 == true ? '#e32747' : '#a8a4a4', width: '3rem', height: '1.5rem', borderRadius: '15px', display: 'flex', justifyContent: toggle1 == true ? 'flex-end' : 'flex-start', alignItems: 'center', padding: '2px' }} onClick={() => {
                                        settoggle1(!toggle1)
                                      }}>
                                        <div style={{ backgroundColor: 'white', width: '1.3rem', height: '1.3rem', borderRadius: '50%' }}></div>
                                      </div>
                                    </div>
                                  </Col>
                                </Row>

                                <Row style={{ marginTop: '30px' }}>
                                  <Col xl={12} lg={12} md={12} sm={12} xs={12} style={{ display: 'flex', alignItems: 'center' }}>
                                    <button style={{ border: 'none', borderRadius: '15px', backgroundColor: '#e32747', color: 'white', padding: '10px', marginTop: '10px', marginBottom: '30px' }}>Delete camera</button>
                                  </Col>
                                </Row>

                              </div>
                            </div>
                          </Col>
                          : ''}
              </Row>



              <Row >

                {
                  btn === 'events' ? ''

                    // <Events datetime={{ startdate, enddate, starttime, endtime }} />


                    // data.map((data, j) => {
                    //   return (
                    //     <>
                    //       <Col xl={12} lg={12} md={12} sm={12} xs={12} >
                    //         <h2 style={{ color: 'grey', fontFamily: 'Poppins-SemiBold', fontSize: 20 }}>{moment(data[j].date).format('dddd, MMMM D YYYY')}</h2>
                    //       </Col>


                    //       <>

                    //         {

                    //           data.map((data, i) => {

                    //             return (

                    //               <>



                    //                 <Col xl={3} lg={6} md={6} sm={12} xs={12}  >



                    //                   <div className="mx-auto my-3" style={{ backgroundColor: 'black', position: 'relative', width: '100%', height: '200px' }} onClick={() => {
                    //                     //    window.history.replaceState(null, null, "/Home/Home/"+data)
                    //                     //    window.location.reload();
                    //                     setsmallVideo(data)

                    //                     const moment = require('moment')
                    //                     let now = moment(data.date)
                    //                     setdate(now.format('dddd, MMMM D YYYY'))
                    //                     handleOpen()

                    //                   }}>

                    //                     <img id={`img${j}${i}`} src={data.uri} width={'100%'} height={'100%'} onError={() => {
                    //                       let tech = document.getElementById(`tech${j}${i}`)
                    //                       tech.style.display = 'block'
                    //                     }} onLoad={() => {
                    //                       let loadimg = document.getElementById(`loadimg${j}${i}`)
                    //                       loadimg.style.display = 'none'
                    //                     }}></img>


                    //                     <div id={`loadimg${j}${i}`} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, height: '100%px', width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', }}>
                    //                       <CircularProgress size={'30px'} style={{ color: 'white' }} />
                    //                     </div>

                    //                     <div id={`tech${j}${i}`} style={{ display: 'none' }}>
                    //                       <div style={{ position: 'absolute', bottom: 0, top: 0, left: 0, right: 0, width: '100%', height: '100%', backgroundColor: 'black', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
                    //                         <HideImageOutlinedIcon style={{ color: 'gray' }} />
                    //                         <p style={{ color: 'white', margin: '0px' }}>No thumbnail</p>
                    //                         <p style={{ color: 'white', margin: '0px', fontSize: '10px' }}>Try again later!</p>
                    //                       </div>
                    //                     </div>

                    //                     <div style={{ position: 'absolute', backgroundColor: 'rgba(0,0,0,0.7)', top: 5, left: 5, right: 0, bottom: 0, height: '28px', width: '80px', padding: '5px', borderRadius: '5px' }}>
                    //                       <p id={`date${j}${i}`} style={{ color: 'white', fontWeight: 'bolder' }}>{data.time}</p>
                    //                     </div>


                    //                   </div>

                    //                   {videoFlag === 0 ?
                    //                     <div style={{ position: 'absolute', bottom: 0, top: 0, left: 0, right: 0, width: '100%', height: '100%', backgroundColor: 'black', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
                    //                       <VideocamOffOutlinedIcon style={{ color: 'gray' }} />
                    //                       <p style={{ color: 'white' }}>No internet</p>
                    //                     </div> : ''}
                    //                 </Col>
                    //               </>
                    //             )
                    //           })
                    //         }
                    //       </>
                    //     </>

                    //   )
                    // }
                    // ) 
                    :
                    ''

                }

                <Col xl={12} lg={12} md={12} sm={12} xs={12} >
                  <div id={`videotech`} style={{ display: 'none' }}>
                    <div style={{ width: '100%', height: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
                      <VideocamOffOutlinedIcon style={{ color: 'gray' }} />
                      <p style={{ color: 'red', margin: '0px' }}>Error!</p>
                      <p style={{ color: 'white', margin: '0px' }}>No video found</p>
                      <p style={{ color: 'white', margin: '0px', fontSize: '10px' }}>Try again later!</p>
                    </div>
                  </div>
                </Col>

              </Row>
            </div>

          </Aux ></div>
      </>
    );
  }
}

export default Dashboard;
