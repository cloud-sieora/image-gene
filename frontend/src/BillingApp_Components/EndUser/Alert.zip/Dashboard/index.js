import React, { useState, useEffect } from 'react'
import {
    Row,
    Col,
    Card,
    Table,
    Tabs,
    Tab,
    Container,
    Button,
} from "react-bootstrap";
import TuneOutlinedIcon from '@mui/icons-material/TuneOutlined';
import ArrowDropUpIcon from '@mui/icons-material/ArrowDropUp';
import CloseIcon from '@mui/icons-material/Close';
import Modal from '@mui/material/Modal';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import { PAGE, STARTDATE, STARTTIME, ENDDATE, ENDTIME, APPLY, SELECT, SELECTED_CAMERAS } from '../../../store/actions'
import * as api from '../../Configurations/Api_Details'
import { useDispatch } from 'react-redux'
import '../style.css'


let flag_type = 'add_tag'
export default function Index() {
    const dispatch = useDispatch()
    const userData = JSON.parse(localStorage.getItem("userData"))
    const [cameras, setcameras] = useState([]);
    const [selectedcameras, setselectedcameras] = useState([]);
    const [actionClick, setactionClick] = useState(false);
    const [open1, setOpen1] = useState(false);
    const [opendelete, setOpendelete] = useState(false);
    const [tag_name, settag_name] = useState('');
    const [tag_list, settag_list] = useState([]);
    const [tag_list_names, settag_list_names] = useState([]);
    const [tag_btn, settag_btn] = useState(false);
    const [create_tag, setcreate_tag] = useState(false);
    const [get_tag_full_data, setget_tag_full_data] = useState([]);

    useEffect(() => {
        dispatch({ type: SELECTED_CAMERAS, value: [] })
        const axios = require('axios');
        let data = JSON.stringify({
            "user_id": userData._id
        });

        let config = {
            method: 'post',
            maxBodyLength: Infinity,
            url: api.LIST_CAMERA_USER_ID,
            headers: {
                'Content-Type': 'application/json'
            },
            data: data
        };

        axios.request(config)
            .then((response) => {
                console.log(JSON.stringify(response.data));
                setcameras(response.data)


            })
            .catch((error) => {
                console.log(error);
            })
    }, [])

    function get_tag_list() {
        const axios = require('axios');
        let data = JSON.stringify({
            "user_id": userData._id
        });

        let config = {
            method: 'post',
            maxBodyLength: Infinity,
            url: flag_type === 'add_tag' ? api.TAG_API_LIST : api.GROUP_API_LIST,
            headers: {
                'Content-Type': 'application/json'
            },
            data: data
        };

        axios.request(config)
            .then((response) => {
                console.log(response.data);
                let newlist = []

                console.log(selectedcameras);

                selectedcameras.map((val) => {
                    if (newlist.length !== 0) {
                        for (let index = 0; index < newlist.length; index++) {
                            let flag = true
                            let obj = {}
                            let current = flag_type === 'add_tag' ? val.camera_tags : val.camera_groups
                            for (let index1 = 0; index1 < current.length; index1++) {
                                if (newlist[index].id === current[index1].id) {
                                    flag = true
                                    newlist[index].count = newlist[index].count + 1
                                    break
                                } else {
                                    flag = false
                                    obj = { name: current[index1].name, id: current[index1].id, count: 1, tags: [] }
                                }
                            }

                            if (flag === false) {
                                newlist.push(obj)
                            }

                        }

                    } else {
                        flag_type === 'add_tag' ?
                            val.camera_tags.map((tag_info) => {
                                newlist.push({ name: tag_info.name, id: tag_info.id, count: 1, tags: [] })
                            })
                            :
                            val.camera_groups.map((tag_info) => {
                                newlist.push({ name: tag_info.name, id: tag_info.id, count: 1, tags: [] })
                            })
                    }
                })

                console.log(newlist);

                let new_tag_list = []

                if (newlist.length !== 0) {

                    for (let index = 0; index < response.data.length; index++) {
                        let flag = true
                        let obj = ''
                        for (let index1 = 0; index1 < newlist.length; index1++) {
                            if (newlist[index1].id === response.data[index]._id) {
                                flag = true
                                newlist[index1].tags = flag_type === 'add_tag' ? response.data[index].tags : response.data[index].groups
                                break
                            } else {
                                flag = false
                                obj = response.data[index]

                            }
                        }

                        if (flag === false) {
                            new_tag_list.push(obj)
                        }
                    }
                } else {
                    new_tag_list = response.data
                }

                console.log(new_tag_list);
                console.log(newlist);
                settag_list(new_tag_list)
                settag_list_names(newlist)
                handleOpen1()


            })
            .catch((error) => {
                console.log(error);
            })
    }

    function get_tag_full_list() {
        const axios = require('axios');
        let data = JSON.stringify({
            "user_id": userData._id
        });

        let config = {
            method: 'post',
            maxBodyLength: Infinity,
            url: flag_type === 'delete_tag' ? api.TAG_API_LIST : api.GROUP_API_LIST,
            headers: {
                'Content-Type': 'application/json'
            },
            data: data
        };

        console.log(flag_type);
        axios.request(config)
            .then((response) => {
                console.log(response.data)
                setget_tag_full_data(response.data)
                handleOpendelete()
            })
            .catch((error) => {
                console.log(error);
            })
    }

    const handleOpen1 = () => setOpen1(true);
    const handleClose1 = () => setOpen1(false);

    const handleOpendelete = () => setOpendelete(true);
    const handleClosedelete = () => setOpendelete(false);


    return (
        <div>
            <Modal
                open={opendelete}
                onClose={handleClosedelete}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
                style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}
            >
                <div style={{ backgroundColor: 'white', width: '80%', borderRadius: '5px' }}>
                    <Row style={{ padding: '10px', alignItems: 'center' }}>
                        <Col xl={12} lg={12} md={12} sm={12} xs={12} style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <input type='text' placeholder='Search' style={{ backgroundColor: '#e6e8eb', color: 'black', padding: '10px', borderRadius: '20px', border: '1px solid gray', marginRight: '20px' }}></input>

                            <CloseIcon style={{ fontSize: '15px', color: 'black' }} onClick={() => {
                                handleClosedelete()
                            }} />
                        </Col>
                        <Col>
                            <hr></hr>
                        </Col>
                        <Col xl={12} lg={12} md={12} sm={12} xs={12} style={{ display: 'flex' }}>
                            {
                                get_tag_full_data.map((val) => (
                                    <p style={{ backgroundColor: '#e6e8eb', color: 'black', padding: '5px', borderRadius: '20px', border: '1px solid gray', marginRight: '20px', display: 'inline-block', fontSize: '15px' }}> {val.tag_name} <CloseIcon style={{ color: 'black', fontSize: '15px' }} onClick={() => {
                                        const axios = require('axios');
                                        let config = {
                                            method: 'put',
                                            maxBodyLength: Infinity,
                                            url: flag_type === 'delete_tag' ? api.TAG_API_CREATE + val._id : api.GROUP_API_CREATE + val._id,
                                            headers: {
                                                'Content-Type': 'application/json'
                                            },
                                        };

                                        axios.request(config)
                                            .then((response) => {
                                                console.log(response.data);
                                                get_tag_full_list()
                                            })
                                            .catch((error) => {
                                                console.log(error);
                                            })
                                    }} /></p>
                                ))
                            }
                        </Col>
                    </Row>
                </div>
            </Modal>


            <Modal
                open={open1}
                onClose={handleClose1}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
                style={{ marginLeft: 'auto', marginRight: 'auto', height: 550, width: '90%', top: 20 }}
            >
                <div>
                    <Row>
                        <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                            <div>
                                <div style={{ backgroundColor: 'white', borderRadius: '5px', paddingTop: '10px', height: 550, maxHeight: 550, overflowY: 'scroll' }}>
                                    <Row style={{ padding: '10px', alignItems: 'center' }}>
                                        <Col xl={6} lg={6} md={6} sm={12} xs={12} style={{ display: 'flex' }}>

                                            <div style={{ position: 'relative' }}>
                                                <button className='eventbtn' onClick={() => {
                                                    setcreate_tag(!create_tag)
                                                }} style={{ display: 'flex', backgroundColor: create_tag ? '#e32747' : '#e6e8eb', color: create_tag ? 'white' : 'black' }}> <TuneOutlinedIcon style={{ marginRight: '10px' }} />{flag_type === 'add_tag' ? 'Create Tag' : 'Create Group'}<ArrowDropDownIcon style={{ marginLeft: '10px' }} /></button>

                                                <div>
                                                    <div style={{ borderRadius: '5px', backgroundColor: '#181828', padding: '10px', position: 'absolute', top: '60px', zIndex: 1, boxShadow: 'rgba(0, 0, 0, 0.35) 0px 5px 15px', display: create_tag ? 'block' : 'none' }}>
                                                        <div style={{ position: 'relative' }}>

                                                            <ArrowDropUpIcon style={{ fontSize: '50px', color: '#181828', margin: 0, position: 'absolute', top: '-37px' }} />
                                                            <div style={{ display: 'flex', justifyContent: 'flex-end', flexDirection: 'column', alignItems: 'flex-end' }}>
                                                                <div style={{ backgroundColor: '#e32747', borderRadius: '50%', padding: '2px', display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '10px' }}>
                                                                    <CloseIcon style={{ fontSize: '12px', color: 'white' }} onClick={() => {
                                                                        setcreate_tag(false)
                                                                    }} />
                                                                </div>
                                                            </div>

                                                            <div>
                                                                <p style={{ margin: 0, color: 'white', fontWeight: 'bolder', marginBottom: '5px' }}>{flag_type === 'add_tag' ? 'Create Tag' : 'Create Group'}</p>
                                                                <input type='text' value={tag_name} placeholder={flag_type === 'add_tag' ? 'Enter tag name' : 'Enter Group name'} style={{ backgroundColor: '#e6e8eb', color: 'black', padding: '10px', borderRadius: '20px', border: '1px solid gray' }} onChange={(e) => {
                                                                    settag_name(e.target.value)
                                                                }}></input>
                                                            </div>

                                                            <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                                                                <button style={{ backgroundColor: '#e32747', color: 'white', padding: '10px', borderRadius: '15px', border: 'none', marginTop: '10px' }} onClick={() => {
                                                                    const axios = require('axios');
                                                                    let data = flag_type === 'add_tag' ? JSON.stringify({
                                                                        'tag_name': tag_name,
                                                                        "user_id": userData._id
                                                                    })
                                                                        :
                                                                        JSON.stringify({
                                                                            'group_name': tag_name,
                                                                            "user_id": userData._id
                                                                        });

                                                                    let config = {
                                                                        method: 'post',
                                                                        maxBodyLength: Infinity,
                                                                        url: flag_type === 'add_tag' ? api.TAG_API_CREATE : api.GROUP_API_CREATE,
                                                                        headers: {
                                                                            'Content-Type': 'application/json'
                                                                        },
                                                                        data: data
                                                                    };

                                                                    console.log(config);

                                                                    axios.request(config)
                                                                        .then((response) => {
                                                                            console.log(JSON.stringify(response.data));
                                                                            get_tag_list()
                                                                            settag_name('')
                                                                            settag_list([])
                                                                            setcreate_tag(!create_tag)
                                                                        })
                                                                        .catch((error) => {
                                                                            console.log(error);
                                                                        })
                                                                }}>{flag_type === 'add_tag' ? 'Add Tag' : 'Add Group'}</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div style={{ position: 'relative' }}>

                                                <button style={{ backgroundColor: '#e32747', color: 'white', padding: '10px', borderRadius: '20px', border: '1px solid gray', }} onClick={() => {
                                                    settag_btn(!tag_btn)
                                                }}><TuneOutlinedIcon style={{ marginRight: '10px' }} />{flag_type === 'add_tag' ? 'Add Tag' : 'Add Group'}</button>

                                                <div>
                                                    <div style={{ borderRadius: '5px', backgroundColor: '#181828', padding: '10px', position: 'absolute', top: '60px', zIndex: 1, boxShadow: 'rgba(0, 0, 0, 0.35) 0px 5px 15px', display: tag_btn ? 'block' : 'none', width: '300px' }}>
                                                        <div style={{ position: 'relative' }}>

                                                            <ArrowDropUpIcon style={{ fontSize: '50px', color: '#181828', margin: 0, position: 'absolute', top: '-37px' }} />
                                                            <div style={{ display: 'flex', justifyContent: 'flex-end', flexDirection: 'column', alignItems: 'flex-end' }}>
                                                                <div style={{ backgroundColor: '#e32747', borderRadius: '50%', padding: '2px', display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '10px' }}>
                                                                    <CloseIcon style={{ fontSize: '12px', color: 'white' }} onClick={() => {
                                                                        settag_btn(false)
                                                                    }} />
                                                                </div>
                                                            </div>

                                                            <div>
                                                                {

                                                                    tag_list.length === 0 ?
                                                                        <div>
                                                                            <p style={{ color: 'grey', fontSize: '12px', margin: 0, marginRight: '10px', cursor: 'pointer', padding: '5px', textAlign: 'center' }}>{flag_type === 'add_tag' ? 'NO Tags' : 'No Groups'}</p>
                                                                        </div>
                                                                        :
                                                                        tag_list.map((value, num) => (
                                                                            <div onClick={() => {
                                                                                const axios = require('axios');
                                                                                let count = 0
                                                                                let fulldata = []
                                                                                let ids = []
                                                                                selectedcameras.map((val, i) => {

                                                                                    let config = {
                                                                                        method: 'put',
                                                                                        maxBodyLength: Infinity,
                                                                                        url: api.CAMERA_CREATION + val._id,
                                                                                        headers: {
                                                                                            'Content-Type': 'application/json'
                                                                                        },
                                                                                        data: flag_type === 'add_tag' ? { camera_tags: [...val.camera_tags, { name: value.tag_name, id: value._id }] } : { camera_groups: [...val.camera_groups, { name: value.group_name, id: value._id }] }
                                                                                    };

                                                                                    axios.request(config)
                                                                                        .then((response) => {
                                                                                            console.log(JSON.stringify(response.data));
                                                                                            fulldata.push(response.data)
                                                                                            ids.push(response.data._id)
                                                                                            count = count + 1
                                                                                            flag_type === 'add_tag' ? selectedcameras[i].camera_tags = [...val.camera_tags, { name: value.tag_name, id: value._id }] : selectedcameras[i].camera_groups = [...val.camera_groups, { name: value.group_name, id: value._id }]

                                                                                            if (count === selectedcameras.length) {

                                                                                                let config = {
                                                                                                    method: 'put',
                                                                                                    maxBodyLength: Infinity,
                                                                                                    url: flag_type === 'add_tag' ? api.TAG_API_CREATE + value._id : api.GROUP_API_CREATE + value._id,
                                                                                                    headers: {
                                                                                                        'Content-Type': 'application/json'
                                                                                                    },
                                                                                                    data: flag_type === 'add_tag' ? { tags: [...value.tags, ...ids] } : { groups: [...value.groups, ...ids] }
                                                                                                };

                                                                                                axios.request(config)
                                                                                                    .then((response) => {
                                                                                                        console.log(JSON.stringify(response.data));
                                                                                                        get_tag_list()
                                                                                                        settag_list_names((old) => {
                                                                                                            return [...old, val]
                                                                                                        })
                                                                                                        dispatch({ type: SELECTED_CAMERAS, value: fulldata })
                                                                                                    })
                                                                                                    .catch((error) => {
                                                                                                        console.log(error);
                                                                                                    })
                                                                                            }


                                                                                        })
                                                                                        .catch((error) => {
                                                                                            console.log(error);
                                                                                        })
                                                                                })
                                                                            }}>
                                                                                <p style={{ color: 'white', fontSize: '12px', margin: 0, marginRight: '10px', cursor: 'pointer', padding: '5px' }}>{flag_type === 'add_tag' ? value.tag_name : value.group_name}</p>
                                                                            </div>
                                                                        ))
                                                                }

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div></Col>
                                        <Col xl={6} lg={6} md={6} sm={12} xs={12}>
                                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end' }}>
                                                <CloseIcon style={{ color: 'black' }} onClick={() => handleClose1()} />
                                            </div>
                                        </Col>

                                    </Row>

                                    <Row style={{ padding: '10px', alignItems: 'center' }}>
                                        <Col>
                                            <hr></hr>
                                        </Col>
                                        <Col xl={12} lg={12} md={12} sm={12} xs={12} style={{ display: 'flex' }}>

                                            {
                                                tag_list_names.map((val) => (
                                                    <p style={{ backgroundColor: '#e6e8eb', color: 'black', padding: '5px', borderRadius: '20px', border: '1px solid gray', marginRight: '20px', display: 'inline-block', fontSize: '15px' }}> {val.name} <CloseIcon style={{ color: 'black', fontSize: '15px' }} onClick={() => {
                                                        const axios = require('axios');
                                                        let count = 0
                                                        let fulldata = []
                                                        let arr = []
                                                        let ids = val.tags
                                                        tag_list_names.map((tag_list) => {
                                                            if (val.id !== tag_list.id) {
                                                                arr.push(tag_list)
                                                            }
                                                        })


                                                        selectedcameras.map((tags, i) => {

                                                            let config = {
                                                                method: 'put',
                                                                maxBodyLength: Infinity,
                                                                url: api.CAMERA_CREATION + tags._id,
                                                                headers: {
                                                                    'Content-Type': 'application/json'
                                                                },
                                                                data: flag_type === 'add_tag' ? { camera_tags: arr } : { camera_groups: arr }
                                                            };

                                                            axios.request(config)
                                                                .then((response) => {
                                                                    console.log(response.data);
                                                                    fulldata.push(response.data)
                                                                    let newdata = []
                                                                    ids.map((val) => {
                                                                        if (val !== response.data._id) {
                                                                            newdata.push(val)
                                                                        }
                                                                    })
                                                                    ids = newdata
                                                                    count = count + 1
                                                                    flag_type === 'add_tag' ? selectedcameras[i].camera_tags = arr : selectedcameras[i].camera_groups = arr
                                                                    if (count === selectedcameras.length) {

                                                                        let config = {
                                                                            method: 'put',
                                                                            maxBodyLength: Infinity,
                                                                            url: flag_type === 'add_tag' ? api.TAG_API_CREATE + val.id : api.GROUP_API_CREATE + val.id,
                                                                            headers: {
                                                                                'Content-Type': 'application/json'
                                                                            },
                                                                            data: flag_type === 'add_tag' ? { tags: ids } : { groups: ids }
                                                                        };

                                                                        axios.request(config)
                                                                            .then((response) => {
                                                                                console.log(JSON.stringify(response.data));
                                                                                get_tag_list()
                                                                                settag_list_names((old) => {
                                                                                    return [...old, val]
                                                                                })
                                                                                dispatch({ type: SELECTED_CAMERAS, value: fulldata })
                                                                            })
                                                                            .catch((error) => {
                                                                                console.log(error);
                                                                            })
                                                                    }


                                                                })
                                                                .catch((error) => {
                                                                    console.log(error);
                                                                })
                                                        })
                                                    }} /></p>
                                                ))
                                            }
                                        </Col>
                                    </Row>

                                    <Row style={{ padding: '10px', alignItems: 'center' }}>
                                        <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                            <table style={{ width: '100%', backgroundColor: 'white' }}>
                                                <tr style={{ backgroundColor: '#e6e8eb', color: 'black' }}>
                                                    <th style={{ padding: '15px' }}>Cameras</th>
                                                    <th style={{ padding: '15px' }}>Cameras name</th>
                                                    <th style={{ padding: '15px' }}>Owner name</th>
                                                    <th style={{ padding: '15px' }}>Permission level</th>
                                                    <th style={{ padding: '15px' }}>Status</th>
                                                    {/* <th style={{ padding: '15px' }}>MAC address</th> */}
                                                    {/* <th style={{ padding: '15px' }}>Cloud Adapter ID</th> */}
                                                    <th style={{ padding: '15px' }}>Cloud recording</th>
                                                    <th style={{ padding: '15px' }}>Recording mode</th>
                                                    <th style={{ padding: '15px' }}>Recorded video quality</th>
                                                    <th style={{ padding: '15px' }}>Analytics</th>
                                                    <th style={{ padding: '15px' }}>Device id</th>
                                                    <th style={{ padding: '15px' }}>Tags</th>
                                                </tr>
                                                {
                                                    selectedcameras.map((val, i) => (
                                                        <tr style={{ borderBottom: '1px solid grey', color: 'black' }}>
                                                            <td style={{ padding: '15px' }}><img width={150} height={100} src='https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Image_created_with_a_mobile_phone.png/1200px-Image_created_with_a_mobile_phone.png'></img></td>
                                                            <td style={{ padding: '15px' }}>{val.camera_gereral_name}</td>
                                                            <td style={{ padding: '15px' }}>{val.camera_username}</td>
                                                            <td style={{ padding: '15px', color: 'red' }}>Read-only</td>
                                                            <td style={{ padding: '15px', color: '#1ee01e' }}>Online</td>
                                                            {/* <td style={{ padding: '15px' }}>10:12:fb:09:21:f5</td> */}
                                                            {/* <td style={{ padding: '15px' }}>CAgxrx</td> */}
                                                            <td style={{ padding: '15px' }}>On</td>
                                                            <td style={{ padding: '15px' }}>Motion triggered</td>
                                                            <td style={{ padding: '15px' }}>720P</td>
                                                            <td style={{ padding: '15px' }}>On</td>
                                                            <td style={{ padding: '15px' }}>{val.device_id}</td>
                                                            <td style={{ padding: '15px' }}>{val.camera_gereral_name}</td>
                                                        </tr>
                                                    ))
                                                }
                                            </table>

                                        </Col>
                                    </Row>


                                </div>
                            </div>
                        </Col>
                    </Row>

                </div>
            </Modal >


            <Row>
                <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                    <div >

                        <div style={{ backgroundColor: 'white', borderRadius: '5px', paddingTop: '10px' }}>
                            <Row style={{ padding: '10px', alignItems: 'center' }}>

                                <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                                        <div>
                                            <input type='text' placeholder='Search' style={{ backgroundColor: '#e6e8eb', color: 'black', padding: '10px', borderRadius: '20px', border: '1px solid gray', marginRight: '20px' }}></input>

                                            <button style={{ backgroundColor: '#e6e8eb', color: 'black', padding: '10px', borderRadius: '20px', border: '1px solid gray', }} onClick={() => {
                                            }}> <TuneOutlinedIcon style={{ marginRight: '10px' }} />Filter</button>
                                        </div>

                                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                                            <p style={{ color: 'black', fontSize: '20px', margin: 0, marginRight: '10px' }}>{selectedcameras.length} / {cameras.length} Selected</p>
                                            <div style={{ position: 'relative' }}>
                                                <button style={{ backgroundColor: actionClick ? '#181828' : '#e6e8eb', color: actionClick ? 'white' : 'black', padding: '10px', borderRadius: '20px', border: 'none', }} onClick={() => {
                                                    setactionClick(!actionClick)
                                                }}>Action</button>

                                                <div style={{ display: actionClick ? 'block' : 'none' }}>
                                                    <ArrowDropUpIcon style={{ fontSize: '50px', color: '#181828', margin: 0, position: 'absolute', top: 32, left: 15 }} />

                                                    <div style={{ position: 'absolute', top: 60, bottom: 0, left: -230, right: 0, width: '300px', zIndex: 2 }}>
                                                        <div style={{ boxShadow: 'rgba(100, 100, 111, 0.2) 0px 7px 29px 0px', borderRadius: '5px', backgroundColor: '#181828' }}>
                                                            <p style={{ color: 'white', fontSize: '15px', margin: 0, marginRight: '10px', cursor: 'pointer', padding: '15px' }}>Edit settings</p>
                                                            <div style={{ display: 'flex', justifyContent: 'center' }}>
                                                                <div style={{ height: '1px', width: '90%', backgroundColor: 'white' }}></div>
                                                            </div>
                                                            <p style={{ color: 'white', fontSize: '15px', margin: 0, marginRight: '10px', cursor: 'pointer', padding: '15px' }} onClick={() => { flag_type = 'add_tag'; get_tag_list() }}>Add tags</p>
                                                            <div style={{ display: 'flex', justifyContent: 'center' }}>
                                                                <div style={{ height: '1px', width: '90%', backgroundColor: 'white' }}></div>
                                                            </div>
                                                            <p style={{ color: 'white', fontSize: '15px', margin: 0, marginRight: '10px', cursor: 'pointer', padding: '15px' }} onClick={() => { flag_type = 'delete_tag'; get_tag_full_list() }}>Delete tags</p>
                                                            <div style={{ display: 'flex', justifyContent: 'center' }}>
                                                                <div style={{ height: '1px', width: '90%', backgroundColor: 'white' }}></div>
                                                            </div>
                                                            <p style={{ color: 'white', fontSize: '15px', margin: 0, marginRight: '10px', cursor: 'pointer', padding: '15px' }} onClick={() => { flag_type = 'add_group'; get_tag_list() }}>Create group</p>
                                                            <div style={{ display: 'flex', justifyContent: 'center' }}>
                                                                <div style={{ height: '1px', width: '90%', backgroundColor: 'white' }}></div>
                                                            </div>
                                                            <p style={{ color: 'white', fontSize: '15px', margin: 0, marginRight: '10px', cursor: 'pointer', padding: '15px' }} onClick={() => { flag_type = 'delete_group'; get_tag_full_list() }}>Delete Group</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </Col>

                            </Row>

                            <Row style={{ padding: '10px', alignItems: 'center', }}>

                                <Col xl={12} lg={12} md={12} sm={12} xs={12} style={{ overflowX: 'scroll' }}>
                                    <table style={{ width: '100%', backgroundColor: 'white' }}>
                                        <tr style={{ backgroundColor: '#e6e8eb', color: 'black' }}>
                                            <th style={{ padding: '15px' }}><input type='checkbox' checked={selectedcameras.length === cameras.length ? true : false} onClick={(e) => {
                                                let check = document.getElementsByClassName('check')

                                                if (e.target.checked === true) {
                                                    for (let i = 0; i < check.length; i++) {
                                                        check[i].checked = true
                                                    }
                                                    setselectedcameras(cameras)
                                                    dispatch({ type: SELECTED_CAMERAS, value: cameras })
                                                } else {
                                                    for (let i = 0; i < check.length; i++) {
                                                        check[i].checked = false
                                                    }
                                                    setselectedcameras([])
                                                    dispatch({ type: SELECTED_CAMERAS, value: [] })
                                                }

                                            }}></input></th>
                                            <th style={{ padding: '15px' }}>Cameras</th>
                                            <th style={{ padding: '15px' }}>Cameras name</th>
                                            <th style={{ padding: '15px' }}>Owner name</th>
                                            <th style={{ padding: '15px' }}>Permission level</th>
                                            <th style={{ padding: '15px' }}>Status</th>
                                            {/* <th style={{ padding: '15px' }}>MAC address</th> */}
                                            {/* <th style={{ padding: '15px' }}>Cloud Adapter ID</th> */}
                                            <th style={{ padding: '15px' }}>Cloud recording</th>
                                            <th style={{ padding: '15px' }}>Recording mode</th>
                                            <th style={{ padding: '15px' }}>Recorded video quality</th>
                                            <th style={{ padding: '15px' }}>Analytics</th>
                                            <th style={{ padding: '15px' }}>Device id</th>
                                            <th style={{ padding: '15px' }}>Tags</th>
                                        </tr>
                                        {
                                            cameras.map((val, i) => (
                                                <tr style={{ borderBottom: '1px solid grey', color: 'black' }}>
                                                    <th style={{ padding: '15px' }}><input className='check' checked={selectedcameras[i] === undefined || selectedcameras[i]._id !== val._id ? false : true} type='checkbox' onClick={(e) => {
                                                        if (e.target.checked === true) {
                                                            setselectedcameras((old) => {
                                                                dispatch({ type: SELECTED_CAMERAS, value: [...old, val] })
                                                                return [...old, val]
                                                            })
                                                        } else {
                                                            let arr = []
                                                            selectedcameras.map((data) => {
                                                                if (val._id !== data._id) {
                                                                    arr.push(data)
                                                                }
                                                            })
                                                            setselectedcameras(arr)
                                                            dispatch({ type: SELECTED_CAMERAS, value: arr })
                                                        }

                                                    }}></input></th>
                                                    <td style={{ padding: '15px' }}><img width={150} height={100} src='https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Image_created_with_a_mobile_phone.png/1200px-Image_created_with_a_mobile_phone.png'></img></td>
                                                    <td style={{ padding: '15px' }}>{val.camera_gereral_name}</td>
                                                    <td style={{ padding: '15px' }}>{val.camera_username}</td>
                                                    <td style={{ padding: '15px', color: 'red' }}>Read-only</td>
                                                    <td style={{ padding: '15px', color: '#1ee01e' }}>Online</td>
                                                    {/* <td style={{ padding: '15px' }}>10:12:fb:09:21:f5</td> */}
                                                    {/* <td style={{ padding: '15px' }}>CAgxrx</td> */}
                                                    <td style={{ padding: '15px' }}>On</td>
                                                    <td style={{ padding: '15px' }}>Motion triggered</td>
                                                    <td style={{ padding: '15px' }}>720P</td>
                                                    <td style={{ padding: '15px' }}>On</td>
                                                    <td style={{ padding: '15px' }}>{val.device_id}</td>
                                                    <td style={{ padding: '15px' }}>{val.camera_gereral_name}</td>
                                                </tr>
                                            ))
                                        }
                                    </table>

                                </Col>

                            </Row>
                        </div>
                    </div>
                </Col>
            </Row>
        </div >
    )
}
