import React, { useState } from 'react'
import ArrowLeftIcon from '@mui/icons-material/ArrowLeft';
import ArrowRightIcon from '@mui/icons-material/ArrowRight';

export default function DateComponent({ year, month, date, type, parentFunction }) {

    const [currentfullyear, setcurrentfullyear] = useState(year);
    const [currentMonth, setcurrentMonth] = useState(month - 1);
    const [currentDate, setcurrentDate] = useState(date);
    const [flagDate, setflagDate] = useState(true);
    const [dateobject, setdateobject] = useState({
        'date': currentDate,
        'month': currentMonth,
        'year': currentfullyear
    });

    let montharray = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    let currentMonthLastDate = new Date(currentfullyear, currentMonth + 1, 0).getDate()
    let currentMonthFirstDay = new Date(currentfullyear, currentMonth, 1).getDay()
    let currentMonthLastDay = new Date(currentfullyear, currentMonth, currentMonthLastDate).getDay()
    let previousMonthLastDate = new Date(currentfullyear, currentMonth - 1, 0).getDate()
    let previousMonthLastDay = new Date(currentfullyear, currentMonth - 1, 0).getDay()
    let nextMonthLastDate = new Date(currentfullyear, currentMonth + 1, 0)
    let nextMonthLastDay = new Date(currentfullyear, currentMonth + 1, 0).getDay()
    // console.log(currentMonthFirstDay);
    // console.log(previousMonthLastDay);
    // console.log(nextMonthLastDay);

    let fulldates = []
    calPreviousMonth()
    function calPreviousMonth() {
        if (currentMonthFirstDay !== 0) {
            for (let index = previousMonthLastDate; index > previousMonthLastDate - currentMonthFirstDay; index--) {
                fulldates.push(
                    <div style={{ width: '68px', marginBottom: '10px', display: 'flex', justifyContent: 'center' }}><p style={{ fontWeight: 'bolder', margin: 0, cursor: 'pointer', cursor: 'pointer', display: 'inline-block', backgroundColor: '#e6e8eb', paddingLeft: '8px', paddingRight: '8px', paddingTop: '3px', paddingBottom: '3px', borderRadius: '50%', color: 'white' }}>{index}</p></div>
                )

            }
        }
    }
    fulldates = fulldates.reverse()

    for (let index = 0; index < currentMonthLastDate; index++) {
        if (index + 1 === currentDate && dateobject.month === currentMonth && dateobject.year === currentfullyear) {
            fulldates.push(
                <div style={{ width: '68px', marginBottom: '10px', display: 'flex', justifyContent: 'center' }}>
                    <p id={`date${index}`} style={{ fontWeight: 'bolder', margin: 0, cursor: 'pointer', cursor: 'pointer', display: 'inline-block', backgroundColor: '#e32747', paddingLeft: '8px', paddingRight: '8px', paddingTop: '3px', paddingBottom: '3px', borderRadius: '50%', color: 'white' }} onClick={() => {
                        dateobject.date = index + 1
                        dateobject.month = currentMonth
                        dateobject.year = currentfullyear
                        parentFunction(index + 1, currentMonth, currentfullyear)
                        setcurrentDate(index + 1)
                        parentFunction(currentfullyear, currentMonth, index + 1, type)
                    }}>{index + 1}</p></div>
            )
        } else {
            fulldates.push(
                <div style={{ width: '68px', marginBottom: '10px', display: 'flex', justifyContent: 'center' }}>
                    <p id={`date${index}`} style={{ fontWeight: 'bolder', margin: 0, cursor: 'pointer', cursor: 'pointer', display: 'inline-block', paddingLeft: '8px', paddingRight: '8px', paddingTop: '3px', paddingBottom: '3px', color: 'black' }} onClick={() => {
                        dateobject.date = index + 1
                        dateobject.month = currentMonth
                        dateobject.year = currentfullyear
                        parentFunction(index + 1, currentMonth, currentfullyear)
                        setcurrentDate(index + 1)
                        parentFunction(currentfullyear, currentMonth, index + 1, type)
                    }} onMouseEnter={() => {
                        let ele = document.getElementById(`date${index}`)
                        ele.style.backgroundColor = '#e32747'
                        ele.style.paddingLeft = '8px'
                        ele.style.paddingRight = '8px'
                        ele.style.paddingTop = '3px'
                        ele.style.paddingBottom = '3px'
                        ele.style.borderRadius = '50%'
                        ele.style.color = 'white'
                    }} onMouseLeave={() => {
                        let ele = document.getElementById(`date${index}`)
                        ele.style.backgroundColor = 'white'
                        ele.style.paddingLeft = '8px'
                        ele.style.paddingRight = '8px'
                        ele.style.paddingTop = '3px'
                        ele.style.paddingBottom = '3px'
                        ele.style.borderRadius = '50%'
                        ele.style.color = '#00008b'
                    }}>{index + 1}</p></div>
            )
        }
    }

    calNextMonth()
    function calNextMonth() {
        if (currentMonthLastDay !== 6) {
            for (let index = 0; index < 6 - currentMonthLastDay; index++) {
                fulldates.push(
                    <div style={{ width: '68px', marginBottom: '10px', display: 'flex', justifyContent: 'center' }}><p style={{ fontWeight: 'bolder', margin: 0, cursor: 'pointer', cursor: 'pointer', display: 'inline-block', backgroundColor: '#e6e8eb', paddingLeft: '8px', paddingRight: '8px', paddingTop: '3px', paddingBottom: '3px', borderRadius: '50%', color: 'white' }}>{index + 1}</p></div>
                )

            }
        }
    }

    return (
        <div>
            <div style={{ width: '500px', backgroundColor: 'white', padding: '10px', borderRadius: '5px', border: '1px solid black' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: 'black' }}>
                    <p style={{ fontWeight: 'bolder', fontSize: '20px', margin: 0 }}>{montharray[currentMonth]} {currentfullyear}</p>
                    <div style={{ display: 'flex' }}>
                        <ArrowLeftIcon style={{ fontSize: '30px', margin: 0, cursor: 'pointer' }} onClick={() => {
                            if (currentMonth - 1 < 0) {
                                setcurrentfullyear(currentfullyear - 1)
                                setcurrentMonth(11)
                            } else {
                                setcurrentMonth(currentMonth - 1)
                            }
                        }} />
                        <ArrowRightIcon style={{ fontSize: '30px', margin: 0, cursor: 'pointer' }} onClick={() => {
                            if (currentMonth + 1 > 11) {
                                setcurrentfullyear(currentfullyear + 1)
                                setcurrentMonth(0)
                            } else {
                                setcurrentMonth(currentMonth + 1)
                            }
                        }} />
                    </div>
                </div>
                <hr></hr>

                <div style={{ display: 'flex', marginTop: '20px', color: '#e32747' }}>
                    <p style={{ fontWeight: 'bolder', margin: 0, marginBottom: '30px', width: '68px', textAlign: 'center' }}>Sun</p>
                    <p style={{ fontWeight: 'bolder', margin: 0, marginBottom: '30px', width: '68px', textAlign: 'center' }}>Mon</p>
                    <p style={{ fontWeight: 'bolder', margin: 0, marginBottom: '30px', width: '68px', textAlign: 'center' }}>Tue</p>
                    <p style={{ fontWeight: 'bolder', margin: 0, marginBottom: '30px', width: '68px', textAlign: 'center' }}>Wed</p>
                    <p style={{ fontWeight: 'bolder', margin: 0, marginBottom: '30px', width: '68px', textAlign: 'center' }}>Thu</p>
                    <p style={{ fontWeight: 'bolder', margin: 0, marginBottom: '30px', width: '68px', textAlign: 'center' }}>Fri</p>
                    <p style={{ fontWeight: 'bolder', margin: 0, marginBottom: '30px', width: '68px', textAlign: 'center' }}>Sat</p>
                </div>

                <div style={{ display: 'flex', flexWrap: 'wrap' }}>
                    {
                        fulldates.map((val, i) => (
                            val
                        ))
                    }
                </div>
            </div>
        </div>
    )
}
