import React, { useEffect, useState, useContext } from 'react'
import {
    Row,
    Col,
    Card,
    Table,
    Tabs,
    Tab,
    Container,
    Button,
} from "react-bootstrap";
import './style.css'
import CircularProgress from '@mui/material/CircularProgress';
import HideImageOutlinedIcon from '@mui/icons-material/HideImageOutlined';
import DirectionsRunIcon from '@mui/icons-material/DirectionsRun';
import ArrowCircleDownIcon from '@mui/icons-material/ArrowCircleDown';
import DeleteOutlineOutlinedIcon from '@mui/icons-material/DeleteOutlineOutlined';
import ReplayOutlinedIcon from '@mui/icons-material/ReplayOutlined';
import ArrowDropDownOutlinedIcon from '@mui/icons-material/ArrowDropDownOutlined';
import Modal from '@mui/material/Modal';
import CloseIcon from '@mui/icons-material/Close';
import VideocamIcon from '@mui/icons-material/Videocam';
import PlayCircleFilledOutlinedIcon from '@mui/icons-material/PlayCircleFilledOutlined';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import TroubleshootIcon from '@mui/icons-material/Troubleshoot';
import ArrowDropUpIcon from '@mui/icons-material/ArrowDropUp';
import TuneOutlinedIcon from '@mui/icons-material/TuneOutlined';
import { Context } from './CameraLiveView'
import PlaylistAddCheckOutlinedIcon from '@mui/icons-material/PlaylistAddCheckOutlined';
import DoneOutlinedIcon from '@mui/icons-material/DoneOutlined';
import CloudOffRoundedIcon from '@mui/icons-material/CloudOffRounded';
import { PAGE, STARTDATE, STARTTIME, ENDDATE, ENDTIME, APPLY, SELECT, SELECTED_CAMERAS } from '../../store/actions'
import { useDispatch, useSelector } from 'react-redux';
import * as api from '../Configurations/Api_Details'
import DateComponent from './DateComponent';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import axios from 'axios';
import EventMenu from './EventMenu';


import { S3 } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import AWS from "aws-sdk";

import { CreateBucketCommand, S3Client, GetObjectCommand, ListBucketsCommand, DeleteBucketCommand, ListObjectsCommand, DeleteObjectCommand } from "@aws-sdk/client-s3";


var moment = require("moment");
let adjbtn = false;
let analytics_obj = []
let analytics_num = {}
let finalflag = false
export default function Events({ data1, res, aditional_info, camera_name }) {
    console.log(data1);
    const userData = JSON.parse(localStorage.getItem("userData"))


    const digitalOceanSpaces = 'https://tentovision.sgp1.digitaloceanspaces.com'
    const bucketName = 'tentovision'

    let data = []
    const [data2, setdata2] = useState([])
    let [ana, setana] = useState(false)
    const { page, startdate, starttime, enddate, endtime, apply, select, selected_cameras } = useSelector((state) => state)
    const dispatch = useDispatch()
    const [viewstart_date, setviewstart_date] = useState(false);
    const [viewend_date, setviewend_date] = useState(false);
    let split_start_date = startdate.split('-')
    let split_end_date = enddate.split('-')
    const [start_dateFullYear, setstart_dateFullYear] = useState(split_start_date[0]);
    const [start_dateMonth, setstart_dateMonth] = useState(split_start_date[1]);
    const [start_dateDate, setstart_dateDate] = useState(split_start_date[2]);
    const [end_dateFullYear, setend_dateFullYear] = useState(split_end_date[0]);
    const [end_dateMonth, setend_dateMonth] = useState(split_end_date[1]);
    const [end_dateDate, setend_dateDate] = useState(split_end_date[2]);
    // const { value, dispatch } = useContext(Context)
    const [smallVideo, setsmallVideo] = useState('')
    const [date, setdate] = useState('')
    const [iv, setiv] = useState(false)
    const [colcount, setcolcount] = useState(40)
    const [colflag, setcolflag] = useState(true)
    const [open, setOpen] = React.useState(false);
    const [open1, setOpen1] = React.useState(false);
    let [finaldata, setfinaldata] = useState([])
    let [finaldate, setfinaldate] = useState('')
    const [clickbtn1, setclickbtn1] = useState(false)
    const [clickbtn2, setclickbtn2] = useState(false)
    const [clickbtn3, setclickbtn3] = useState(false)
    const [btn1, setbtn1] = useState('')
    const [ready, setready] = useState(false)
    const [url, seturl] = useState('')
    const [progress, setprogress] = useState(0)
    const [size, setSize] = useState({ left: 20, right: 50, width: 300 });
    const [moved, setmoved] = useState({ left: 10, top: 10 });
    const [outerdiv, setouterdiv] = useState({ width: '100%', height: '700px' });
    const [count, setcount] = useState(false);
    const [cameras, setcameras] = useState([]);
    const [cameras1, setcameras1] = useState([]);
    const [cameras_view, setcameras_view] = useState([]);
    const [cameras_view1, setcameras_view1] = useState([]);
    const [cameras_view2, setcameras_view2] = useState([]);
    const [selectedcameras, setselectedcameras] = useState([]);
    let [selected_video, setselected_video] = useState([])
    let [selectedanalytics, setselectedanalytics] = useState([])
    let [newres, setnewres] = useState(false)
    const [toggle, settoggle] = useState(true)
    const [online_status, setonline_status] = useState(false)
    const [camera_tag, setcamera_tag] = useState(false)
    const [camera_group, setcamera_group] = useState(false)
    const [camera_box, setcamera_box] = useState(false)
    const [filter, setfilter] = useState(false)
    const [get_group_full_data, setget_group_full_data] = useState([])
    const [get_group_full_data_sort, setget_group_full_data_sort] = useState([])
    const [get_group_full_data_sort1, setget_group_full_data_sort1] = useState([])
    const [get_tag_full_data, setget_tag_full_data] = useState([])
    const [get_tag_full_data_sort, setget_tag_full_data_sort] = useState([])
    const [get_tag_full_data_sort1, setget_tag_full_data_sort1] = useState([])
    const [camera_serach, setcamera_serach] = useState([])
    const [camera_serach1, setcamera_serach1] = useState([])
    const [tag_serach, settag_serach] = useState([])
    const [group_serach, setgroup_serach] = useState([])
    let numToggle = []

    const [camera_checkbox, setcamera_checkbox] = useState([])
    const [tag_checkbox, settag_checkbox] = useState([])
    const [group_checkbox, setgroup_checkbox] = useState([])
    const [full_camera_search, setfull_camera_search] = useState('')
    const [camera_search, setcamera_search] = useState('')
    const [tag_search, settag_search] = useState('')
    const [group_search, setgroup_search] = useState('')
    const [video_uri, setvideo_uri] = useState('')
    const [image_uri, setimage_uri] = useState('')
    const [image_arr, setimage_arr] = useState([])



    useEffect(() => {
        finalflag = false
    }, [apply])

    let overview = false

    if (select === false) {
        selected_video = []
    }

    if (selectedanalytics.length === 0) {
        data = data1
        newres = false
    } else {
        let arr = []
        function dup(arr, val_id) {
            let count = -1
            if (arr.length !== 0) {
                for (let i = 0; i < arr.length; i++) {
                    if (arr[i]._id === val_id) {
                        count = 1
                        break
                    } else {
                        count = 0
                    }
                }
            } else {
                count = 0
            }
            return count
        }
        data1.map((val) => {
            selectedanalytics.map((ana) => {

                if (val.objects.length !== 0 && val.objects[`${ana}`] !== undefined) {
                    let duplicate = dup(arr, val._id)
                    if (duplicate === 0) {
                        arr.push(val)
                    }
                }
            })
        })

        data = arr
        if (arr.length === 0) {
            newres = true
        } else {
            newres = true
        }
        console.log(arr);
    }

    const [image, setimage] = useState('')
    // const [startdate, setstartdate] = useState(value)
    // const [starttime, setstarttime] = useState('00:00')
    // const [endtime, setendtime] = useState(`${date1[2]}:${date1[3]}`)
    // const [enddate, setenddate] = useState(date1[1])


    const style = {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        boxShadow: 24,
    };

    useEffect(() => {

        analytics_obj = []
        analytics_num = {}

        window.addEventListener('scroll', handleScrollToElement)
        data1.map((val) => {
            if (analytics_obj.length !== 0) {
                Object.keys(val.objects).map((obj) => {
                    let count1 = 0

                    for (let i = 0; i < analytics_obj.length; i++) {
                        if (obj === analytics_obj[i]) {
                            count1 = -1
                            analytics_num[obj] = analytics_num[obj] + 1
                            break
                        } else {
                            count1 = 1
                        }
                    }

                    if (count1 === 1) {
                        analytics_obj.push(obj)
                        analytics_num = { ...analytics_num, [obj]: 1 }
                    }

                })
            } else {
                Object.keys(val.objects).map((obj) => {
                    analytics_obj.push(obj)
                    analytics_num = { ...analytics_num, [obj]: 1 }
                })
            }
        })


        // Object.keys(smallVideo.objects).map((data, i) => (
        //     <Col xl={2} lg={2} md={2} sm={6} xs={6}>
        //         <div style={{ marginRight: '40px' }}>
        //             <p style={{ color: 'black', fontWeight: 'bolder', fontSize: '20px', marginBottom: '3px' }}>{data}</p>
        //             <p style={{ color: 'gray', fontSize: '18px', }}>{Math.round(smallVideo.objects[`${data}`] * 100)}%</p>
        //         </div>
        //     </Col>
        // ))
        finalflag = true
        setfinaldata([])
        setfinaldate('')
        setcolflag(true)
        setcolcount(40)
        setselectedanalytics([])
        return () => {
            window.removeEventListener("scroll", handleScrollToElement);
        };
    }, [data1])

    useEffect(() => {
        dispatch({ type: SELECTED_CAMERAS, value: [] })
        const axios = require('axios');
        let data = JSON.stringify({
            "user_id": userData._id
        });

        let config = {
            method: 'post',
            maxBodyLength: Infinity,
            url: api.LIST_CAMERA_USER_ID,
            headers: {
                'Content-Type': 'application/json'
            },
            data: data
        };

        axios.request(config)
            .then((response) => {
                console.log(JSON.stringify(response.data));
                setcameras(response.data)
                setcameras1(response.data)
                setcameras_view(response.data)
                setcameras_view1(response.data)
                setcameras_view2(response.data)
                setselectedcameras(response.data)
                dispatch({ type: SELECTED_CAMERAS, value: response.data })
                dispatch({ type: APPLY, value: !apply })


            })
            .catch((error) => {
                console.log(error);
            })
    }, [])



    // const convertvideo = async (uri) => {
    //     if (ready === true) {
    //         ffmpeg.FS('writeFile', 'test.avi', await fetchFile(uri));
    //         await ffmpeg.run('-i', 'test.avi', '-vcodec', 'h264', 'test.mp4');
    //         const data = ffmpeg.FS('readFile', 'test.mp4');
    //         const url = URL.createObjectURL(new Blob([data.buffer], { type: 'video/mp4' }));
    //         console.log(url);
    //         seturl(url)
    //         setsmallVideo({ ...smallVideo, video_url: url })
    //         setready(false)
    //     }
    //     // console.log(uri);
    // }

    // useEffect(() => {
    //     getdata(startdate,enddate)

    //     window.addEventListener('scroll', handleScrollToElement)

    //     return () => {
    //         window.removeEventListener("scroll", handleScrollToElement);
    //     };

    // }, [apply])

    // function getdata(startdate,enddate) {
    //     let pathName = window.location.pathname;
    //     let arr = pathName.split('/')

    //     setdata([])

    //     const axios = require('axios');
    //     let data = JSON.stringify({
    //         "device_id": "T0001",
    //         "camera_name": `${arr[arr.length - 1]}`,
    //         "start_date": startdate,
    //         "end_date": enddate
    //     });

    //     let config = {
    //         method: 'post',
    //         maxBodyLength: Infinity,
    //         url: 'http://tentovision.cloudjiffy.net/analytics_api_list_by_date/',
    //         headers: {
    //             'Content-Type': 'application/json'
    //         },
    //         data: data
    //     };

    //     axios.request(config)
    //         .then((response) => {
    //             // console.log(JSON.stringify(response.data.data));
    //             console.log(JSON.stringify(response.data.data));
    //             // let arr1 = []
    //             // let arr = []

    //             setfinaldata([])
    //             setfinaldate('')
    //             setdata(response.data.data)
    //             setcolflag(false)
    //             // response.data.data.map((data, j) => {

    //             //   if (arr.length != 0) {
    //             //     arr.map((val) => {
    //             //       let count = 0
    //             //       if (data.date != val) {
    //             //         count = count + 1
    //             //       } else {
    //             //         count = count - 1
    //             //       }

    //             //       if (count === arr.length) {
    //             //         arr.push(data.date)
    //             //       }
    //             //     })

    //             //   } else {
    //             //     arr.push(data.date)
    //             //   }


    //             // })

    //             // response.data.data.map((data, j) => {
    //             //   arr.map((val, i) => {
    //             //     if (data.date === val) {

    //             //       if (arr1[i] === undefined) {
    //             //         let arr = []
    //             //         arr.push(data)
    //             //         arr1[i] = arr
    //             //       } else {
    //             //         arr1[i].push(data)
    //             //       }
    //             //     }
    //             //   })
    //             // })
    //             // setdata(arr1)
    //             // setarr(arr1)
    //         })
    //         .catch((error) => {
    //             // let div = document.getElementById('videotech')
    //             // div.style.display = 'block'
    //             console.log(error);
    //         })
    // }

    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    const handleOpen1 = () => setOpen1(true);
    const handleClose1 = () => {
        setOpen1(false)
        setcamera_box(false)
        setcamera_tag(false)
        setcamera_group(false)
        setonline_status(false)

    };

    const handleScrollToElement = (event) => {
        // console.log(window.pageYOffset);
        // console.log(window.innerHeight);
        // console.log(main.clientHeight);
        let main = document.getElementById('main')

        if ((window.pageYOffset + window.innerHeight) >= main.clientHeight) {
            setcolcount((pre) => {
                return pre + 40
            })
            setcolflag(true)
        }
        getOffset()
        // console.log(main.scrollHeight);
    }

    // (colcount <= data.length ? colcount : data.length)
    // (colcount === 40 ? 0 : colcount - 40)

    async function final_datafunction() {
        let finaldate1 = finaldate
        let datearr = []

        for (let index = 0; index < data.length; index++) {
            if (datearr.length != 0) {
                let flag = false
                for (let index1 = 0; index1 < datearr.length; index1++) {
                    if (datearr[index1].date == data[index].date) {
                        flag = false
                        datearr[index1].value = [...datearr[index1].value, data[index]]
                        break
                    } else {
                        flag = true
                    }
                }

                if (flag) {
                    datearr.push({ date: data[index].date, value: [data[index]] })
                }
            } else {
                datearr.push({ date: data[index].date, value: [data[index]] })
            }

        }

        let data1 = []
        datearr.map((val) => {
            data1 = [...data1, ...val.value]
        })

        for (let i = (colcount === 40 ? 0 : colcount - 40); i < (colcount <= data1.length ? colcount : data1.length); i++) {
            console.log(i);

            let dat = getimageurifunction('AKIA3CYTPKNZWMDIHN5F', '5YuMuo8u/tOTiEp7V7Zi1jM4Xtp5qPLRY1DRImEg', 'tentovision', data1[i])

            console.log(dat);
            if (finaldata.length > 1 && i > 1) {

                if (data1[i].date != data1[i - 1].date) {
                    finaldata.push(
                        <Col xl={12} lg={12} md={12} sm={12} xs={12} key={i}>
                            <h2 style={{ color: 'grey', fontFamily: 'Poppins-SemiBold', fontSize: 20 }}>{moment(data1[i].date).format('dddd, MMMM D YYYY')}</h2>
                        </Col>
                    )
                }
            } else if (finaldata.length == 1 || finaldata.length == 0) {
                finaldata.push(
                    <Col xl={12} lg={12} md={12} sm={12} xs={12} key={i}>
                        <h2 style={{ color: 'grey', fontFamily: 'Poppins-SemiBold', fontSize: 20 }}>{moment(data1[i].date).format('dddd, MMMM D YYYY')}</h2>
                    </Col>
                )
            }


            if (true) {
                finaldata.push(
                    <Col xl={3} lg={6} md={6} sm={12} xs={12} key={data1[i]._id} style={{ backgroundColor: 'white', paddingLeft: '5px', paddingTop: '5px', paddingRight: 0 }} >



                        <div style={{ backgroundColor: 'black', position: 'relative', width: '100%', height: '100%', cursor: 'pointer', }} onMouseEnter={() => {

                            if (document.getElementById(`tech${i}`).style.display != 'block') {

                                getinstanturifunction('AKIA3CYTPKNZWMDIHN5F', '5YuMuo8u/tOTiEp7V7Zi1jM4Xtp5qPLRY1DRImEg', 'tentovision', data1[i].video_key, i)

                            }


                        }} onMouseLeave={() => {
                            let img = document.getElementById(`img${i}`)
                            img.style.display = 'block'

                            let vid = document.getElementById(`vid${i}`)
                            vid.style.display = 'none'

                        }} onClick={() => {
                            //    window.history.replaceState(null, null, "/Home/Home/"+data)
                            //    window.location.reload();
                            console.log(data1[i]);
                            if (select != true) {
                                setsmallVideo(data1[i])
                                console.log(data1[i])
                                console.log({ ...data1[i], video_url: '' });
                                const moment = require('moment')
                                let now = moment(data1[i].date)
                                setdate(now.format('dddd, MMMM D YYYY'))
                                geturifunction('AKIA3CYTPKNZWMDIHN5F', '5YuMuo8u/tOTiEp7V7Zi1jM4Xtp5qPLRY1DRImEg', 'tentovision', data1[i].video_key, data1[i]
                                )
                                handleOpen()
                                // load(data[i])
                            } else {
                                let count = 0
                                for (let j = 0; j < selected_video.length; j++) {
                                    if (selected_video[j]._id === data1[i]._id) {
                                        let div = document.getElementById(`blur${i}`)
                                        div.style.display = 'block'

                                        let div1 = document.getElementById(`blurdiv${i}`)
                                        div1.style.display = 'none'

                                        selected_video.splice(j, 1)
                                        setcount((old) => !old)
                                        count = count - 1
                                    } else {
                                        count = count + 1
                                    }
                                }

                                if (count === selected_video.length) {
                                    let div = document.getElementById(`blur${i}`)
                                    div.style.display = 'none'

                                    let div1 = document.getElementById(`blurdiv${i}`)
                                    div1.style.display = 'block'

                                    selected_video.push(data1[i])
                                    setsmallVideo(data1[i])
                                }
                            }
                            console.log(selected_video);

                        }}>

                            <div style={{ display: select === true ? 'block' : 'none' }}>
                                <div id={`blur${i}`} style={{ display: select === true ? 'block' : 'none', position: 'absolute', backgroundColor: '#c9cbcb', top: 0, left: 0, right: 0, bottom: 0, height: '100%', width: '100%', opacity: 0.8, zIndex: 1 }}>
                                </div>
                            </div>

                            <div style={{ display: select === true ? 'block' : 'none' }}>
                                <div id={`blurdiv${i}`} style={{ display: select === true ? 'none' : 'block', position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, }}>
                                    <div style={{ width: '100%', height: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                        <p style={{ backgroundColor: 'black', color: 'white', padding: '5px', fontWeight: 'bold', borderRadius: '5px' }}><DoneOutlinedIcon />Selected</p>
                                    </div>
                                </div>
                            </div>

                            <video crossorigin="anonymous" loop id={`vid${i}`} width={'100%'} height={'100%'} style={{ lineHeight: 0, display: 'none', objectFit: 'cover' }} onPlay={() => {

                                let div3 = document.getElementById(`div2${i}`)
                                div3.style.display = 'none'

                            }}

                                onWaiting={() => {

                                    let div3 = document.getElementById(`div2${i}`)
                                    div3.style.display = 'block'
                                }}

                                onPlaying={() => {

                                    let div3 = document.getElementById(`div2${i}`)
                                    div3.style.display = 'none'
                                }}

                                onPause={() => {

                                    let div3 = document.getElementById(`div2${i}`)
                                    div3.style.display = 'none'
                                }}

                                onError={() => {

                                    let div3 = document.getElementById(`div2${i}`)
                                    div3.style.display = 'none'

                                }}></video>

                            <div id={`div2${i}`} style={{ display: 'none', position: 'absolute', top: '83%', width: '100%' }}>
                                <div style={{ display: 'flex', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.5)', width: '100%', padding: '5px' }}>
                                    <CircularProgress size={'15px'} style={{ color: 'white' }} />
                                    <p style={{ color: 'white', marginLeft: '10px', marginBottom: 0 }}>Loading</p>
                                </div>
                            </div>

                            <img crossorigin="anonymous" id={`img${i}`} src={image_arr[i]} width={'100%'} style={{ lineHeight: 0, display: 'block' }} onError={() => {
                                let tech = document.getElementById(`tech${i}`)
                                tech.style.display = 'block'
                            }}
                            // onLoad={() => {
                            //     let loadimg = document.getElementById(`loadimg${i}`)
                            //     loadimg.style.display = 'none'
                            // }}
                            ></img>


                            {/* <div id={`loadimg${i}`} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, height: '100%px', width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', }}>
                                <CircularProgress size={'30px'} style={{ color: 'white' }} />
                            </div> */}

                            <div id={`tech${i}`} style={{ display: 'none' }}>
                                <div style={{ position: 'absolute', bottom: 0, top: 0, left: 0, right: 0, width: '100%', height: '100%', backgroundColor: 'black', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
                                    <HideImageOutlinedIcon style={{ color: 'gray' }} />
                                    <p style={{ color: 'white', margin: '0px' }}>No thumbnail</p>
                                    <p style={{ color: 'white', margin: '0px', fontSize: '10px' }}>Try again later!</p>
                                </div>
                            </div>

                            <div style={{ position: 'absolute', backgroundColor: 'rgba(0,0,0,0.7)', top: 5, left: 5, right: 0, bottom: 0, height: '28px', width: '80px', padding: '5px', borderRadius: '5px' }}>
                                <p id={`date${i}`} style={{ color: 'white', fontWeight: 'bolder' }}>{data1[i].time}</p>
                            </div>


                        </div>

                        {/* {videoFlag === 0 ?
                  <div style={{ position: 'absolute', bottom: 0, top: 0, left: 0, right: 0, width: '100%', height: '100%', backgroundColor: 'black', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
                    <VideocamOffOutlinedIcon style={{ color: 'gray' }} />
                    <p style={{ color: 'white' }}>No internet</p>
                  </div> : ''} */}
                    </Col >
                )
            }
            finaldate1 = data1[i].date
        }
        overview = true
        setcolflag(false)
        setfinaldate(finaldate1)
    }


    if (data != '' && data !== undefined && colflag === true) {
        final_datafunction()
    }

    let camera_list = cameras_view.map((val, i) => {

        let chk = ""
        for (let i = 0; i < selectedcameras.length; i++) {
            if (selectedcameras[i]._id === val._id) {
                chk = true
                break
            } else {
                chk = false
            }
        }

        return (
            <tr style={{ borderBottom: '1px solid grey', color: 'black' }}>
                <th style={{ padding: '15px' }}>
                    {/* <input className='check' checked={chk} type='checkbox' onClick={(e) => {
                    if (e.target.checked === true) {
                        setselectedcameras((old) => {
                            dispatch({ type: SELECTED_CAMERAS, value: [...old, val] })
                            dispatch({ type: APPLY, value: !apply })
                            return [...old, val]
                        })
                    } else {
                        let arr = []
                        selectedcameras.map((data) => {
                            if (val._id !== data._id) {
                                arr.push(data)
                            }
                        })
                        setselectedcameras(arr)
                        dispatch({ type: SELECTED_CAMERAS, value: arr })
                        dispatch({ type: APPLY, value: !apply })
                    }

                }}></input> */}

                    <div>

                        <div id={`chk${i}`} className='check' title={`${chk}`} style={{ backgroundColor: chk == true ? '#42cf10' : '#a8a4a4', width: '3rem', height: '1.5rem', borderRadius: '15px', display: 'flex', justifyContent: chk == true ? 'flex-end' : 'flex-start', alignItems: 'center', padding: '2px' }} onClick={() => {
                            // settoggle(!toggle)

                            let ele = document.getElementById(`chk${i}`)

                            let toggle = ele.getAttribute("title") === 'true' ? false : true
                            let arr = []

                            if (toggle === true) {
                                arr = [...selectedcameras, val]
                                setselectedcameras((old) => {
                                    dispatch({ type: SELECTED_CAMERAS, value: [...old, val] })
                                    dispatch({ type: APPLY, value: !apply })
                                    return [...old, val]
                                })
                            } else {

                                selectedcameras.map((data) => {
                                    if (val._id !== data._id) {
                                        arr.push(data)
                                    }
                                })
                                setselectedcameras(arr)
                                dispatch({ type: SELECTED_CAMERAS, value: arr })
                                dispatch({ type: APPLY, value: !apply })
                            }

                            if (arr.length === cameras.length) {
                                settoggle(true)
                            } else {
                                settoggle(false)
                            }
                        }}>
                            <div style={{ backgroundColor: 'white', width: '1.3rem', height: '1.3rem', borderRadius: '50%' }}></div>
                        </div>
                    </div>
                </th>
                <td style={{ padding: '15px' }}><img width={150} height={100} src={`${val.camera_url}?${new Date()}`}></img></td>
                <td style={{ padding: '15px' }}>{val.camera_gereral_name}</td>
                <td style={{ padding: '15px' }}>{val.camera_gereral_name}</td>
                <td style={{ padding: '15px' }}>360 days</td>
            </tr>
        )
    })

    if (clickbtn1 === true) {
        if (btn1 === 'day') {
            setbtn1('')
            let btn = document.getElementById('day')
            btn.style.backgroundColor = '#f0f0f0'
            btn.style.color = 'black'
            let btn1 = document.getElementById('analytics')
            btn1.style.backgroundColor = '#f0f0f0'
            btn1.style.color = 'black'
        } else if (btn1 === '' || btn1 === 'analytics') {
            setbtn1('day')
            let btn = document.getElementById('day')
            btn.style.backgroundColor = '#e32747'
            btn.style.color = 'white'

            let btn1 = document.getElementById('analytics')
            btn1.style.backgroundColor = '#f0f0f0'
            btn1.style.color = 'black'
        }
        setclickbtn1(false)
    } else if (clickbtn2 === true) {
        if (btn1 === 'analytics') {
            setbtn1('')
            let btn = document.getElementById('day')
            btn.style.backgroundColor = '#f0f0f0'
            btn.style.color = 'black'
            let btn1 = document.getElementById('analytics')
            btn1.style.backgroundColor = '#f0f0f0'
            btn1.style.color = 'black'
        } else if (btn1 === '' || btn1 === 'day') {
            setbtn1('analytics')
            let btn = document.getElementById('day')
            btn.style.backgroundColor = '#f0f0f0'
            btn.style.color = 'black'

            let btn1 = document.getElementById('analytics')
            btn1.style.backgroundColor = '#e32747'
            btn1.style.color = 'white'
        }
        setclickbtn2(false)
    }

    function bulk_download_delete() {
        return (
            <div id='downdel' style={{ display: 'flex', alignItems: 'center' }}>
                <button id='analytics' style={{ backgroundColor: '#e6e8eb', color: 'black', padding: '10px', borderRadius: '50%', border: '1px solid gray', marginRight: '20px' }}><ArrowCircleDownIcon style={{ fontSize: '30px' }} onClick={() => {
                    selected_video.map((val) => {
                        const blob = new Blob([val.video_url], { type: 'video/mp4' })
                        const link = document.createElement('a')
                        link.href = URL.createObjectURL(blob)
                        link.download = val.video_url
                        link.click()
                        URL.revokeObjectURL(link.href)
                    })
                }} /></button>

                <button id='analytics' style={{ backgroundColor: '#e6e8eb', color: 'black', padding: '10px', borderRadius: '50%', border: '1px solid gray' }}><DeleteOutlineOutlinedIcon style={{ fontSize: '30px' }} onClick={() => {

                    const spacesEndpoint = new AWS.Endpoint('sgp1.digitaloceanspaces.com/');
                    const s3 = new AWS.S3({
                        endpoint: spacesEndpoint,
                        accessKeyId: "7GNWRGQS5347V5X7O4LV",
                        secretAccessKey: 'RNMZe1dhsFiOOA6uNa8y684V+u9ZgIbL3ENfd6Lzt8M'
                    });

                    selected_video.map((val) => {
                        let sp = val.video_url.split("/")

                        const params = {
                            Bucket: bucketName,
                            Key: `${sp[4]}/${sp[5]}/${sp[6]}/${sp[7]}`
                        };

                        s3.deleteObject(params, function (deleteErr, data) {
                            if (deleteErr) {
                                console.log("Error: " + deleteErr);
                            }
                            else {
                                console.log('Successfully deleted the item');
                            }
                        })
                        // .on('build', request => {
                        //     console.log(request.httpRequest.headers);
                        //     request.httpRequest.headers.Host = digitalOceanSpaces;
                        //     //    request.httpRequest.headers['Content-Length'] = blob.size;
                        //     request.httpRequest.headers['Content-Type'] = 'Access-Control-Allow-Headers';
                        //     request.httpRequest.headers['x-amz-acl'] = 'public-read';
                        //     setsave(false)
                        // })
                        // .send((err) => {
                        //     if (err) {
                        //         console.log(err);
                        //         // errorCallback();
                        //     }
                        //     else {

                        //         const imageUrl = digitalOceanSpaces + "/" + blob.name
                        //         const Url = digitalOceanSpaces + "/" + blob.name

                        //         console.log(Url)
                        //         progress.style.display = 'none'
                        //         savebtn.style.display = 'block'
                        //         setsave(true)
                        //         console.log(imageUrl)
                        //         fun(imageUrl)

                        //     }
                        // });
                    })



                    // const blob = dataURItoBlob(drawing1);
                    // blob.name = JSON.stringify(Date.now())
                    // console.log(blob);
                    // const params = {
                    //     Body: blob,
                    //     Bucket: bucketName,
                    //     Key: blob.name
                    // };
                }} /></button>
            </div>
        )
    }

    function getOffset() {
        let el = document.getElementById('events')
        let ele = document.getElementById('filter')
        const rect = el.getBoundingClientRect();
        const rect2 = ele.getBoundingClientRect();

        if (rect.top === 0) {
            el.style.boxShadow = 'rgba(0, 0, 0, 0.45) 0px 25px 20px -20px'
            el.style.backgroundColor = '#1b0182'
        } else if (rect.top != 0) {
            el.style.boxShadow = 'none'
            el.style.backgroundColor = '#e6e8eb'
        }

        if (rect2.top === 0) {
            ele.style.boxShadow = 'rgba(0, 0, 0, 0.45) 0px 25px 20px -20px'
            ele.style.backgroundColor = '#1b0182'
        } else if (rect2.top != 0) {
            ele.style.boxShadow = 'none'
            ele.style.backgroundColor = '#e6e8eb'
        }
    }


    const handlerLeft = (mouseDownEvent) => {

        const startSize = size;
        const startPosition = { x: mouseDownEvent.pageX, y: mouseDownEvent.pageY };
        function onMouseMove(mouseMoveEvent) {
            let left1 = startSize.left - startPosition.x + mouseMoveEvent.pageX

            if (left1 > startSize.left) {
                setSize(currentSize => ({
                    left: left1,
                    right: currentSize.right,
                    width: startSize.width - (mouseMoveEvent.x - startPosition.x)
                }));
            }
            else {
                console.log('kjkjhjk');
                console.log(startPosition.x - mouseMoveEvent.x);
                setSize(currentSize => ({
                    left: left1,
                    right: currentSize.right,
                    width: startPosition.x - mouseMoveEvent.x + startSize.width
                }));
            }
        }
        function onMouseUp() {
            document.body.removeEventListener("mousemove", onMouseMove);
            // uncomment the following line if not using `{ once: true }`
            // document.body.removeEventListener("mouseup", onMouseUp);
        }

        document.body.addEventListener("mousemove", onMouseMove);
        document.body.addEventListener("mouseup", onMouseUp, { once: true });
    };

    const handlerRight = (mouseDownEvent) => {

        const startSize = size;
        const startPosition = { x: mouseDownEvent.pageX, y: mouseDownEvent.pageY };
        function onMouseMove(mouseMoveEvent) {
            let right1 = startSize.right - startPosition.x + mouseMoveEvent.pageX
            setSize(currentSize => ({
                left: currentSize.left,
                right: right1,
                width: mouseMoveEvent.x - startPosition.x + startSize.width
            }));
        }
        function onMouseUp() {
            document.body.removeEventListener("mousemove", onMouseMove);
            // uncomment the following line if not using `{ once: true }`
            // document.body.removeEventListener("mouseup", onMouseUp);
        }

        document.body.addEventListener("mousemove", onMouseMove);
        document.body.addEventListener("mouseup", onMouseUp, { once: true });
    };

    const movediv = (mouseDownEvent) => {
        const startPosition = { left: mouseDownEvent.pageX, top: mouseDownEvent.pageY };

        function onMouseMove(mouseMoveEvent) {
            const startSize = moved;
            // console.log(mouseMoveEvent.pageX - startPosition.left + moved.left,);
            // console.log(mouseMoveEvent.pageY - startPosition.top + moved.top);

            let val = {
                left: mouseMoveEvent.pageX - startPosition.left + moved.left,
                top: mouseMoveEvent.pageY - startPosition.top + moved.top
            }
            // console.log(upperdivWidth, size.x , (val.left + size.x)+3 );
            // console.log(mouseMoveEvent.pageY - startPosition.top + moved.top);
            var boun = document.getElementById("upperdiv").offsetWidth - document.getElementById("elem").offsetWidth;
            var boun1 = document.getElementById("upperdiv").offsetHeight - document.getElementById("elem").offsetHeight;
            if (val.left < boun && val.top < boun1)
                setmoved(currentSize => ({
                    left: val.left > 0 ? val.left : 0,
                    top: val.top > 0 ? val.top : 0
                }));

        }
        function onMouseUp() {
            document.body.removeEventListener("mousemove", onMouseMove);
            // uncomment the following line if not using `{ once: true }`
            // document.body.removeEventListener("mouseup", onMouseUp);
        }

        document.body.addEventListener("mousemove", onMouseMove);
        document.body.addEventListener("mouseup", onMouseUp, { once: true });

    };

    function initialdate(year, month, date, type) {
        if (type === 'start_date') {
            dispatch({ type: STARTDATE, value: `${year}-${month < 10 ? `0${month + 1}` : month + 1}-${date < 10 ? `0${date}` : date}` })
            setstart_dateFullYear(year)
            setstart_dateMonth(month < 10 ? `0${month + 1}` : month + 1)
            setstart_dateDate(date < 10 ? `0${date}` : date)
            setviewstart_date(!viewstart_date)
        } else if (type === 'end_date') {
            dispatch({ type: ENDDATE, value: `${year}-${month < 10 ? `0${month + 1}` : month + 1}-${date < 10 ? `0${date}` : date}` })
            setend_dateFullYear(year)
            setend_dateMonth(month < 10 ? `0${month}` : month)
            setend_dateDate(date < 10 ? `0${date}` : date)
            setviewend_date(!viewend_date)
        }
    }

    function get_tag_full_list() {
        const axios = require('axios');
        let data = JSON.stringify({
            "user_id": userData._id
        });

        let config = {
            method: 'post',
            maxBodyLength: Infinity,
            url: api.TAG_API_LIST,
            headers: {
                'Content-Type': 'application/json'
            },
            data: data
        };

        axios.request(config)
            .then((response) => {
                console.log(response.data)
                setget_tag_full_data(response.data)
                setget_tag_full_data_sort(response.data)
                setget_tag_full_data_sort1(response.data)
            })
            .catch((error) => {
                console.log(error);
            })
    }

    function get_group_full_list() {
        const axios = require('axios');
        let data = JSON.stringify({
            "user_id": userData._id
        });

        let config = {
            method: 'post',
            maxBodyLength: Infinity,
            url: api.GROUP_API_LIST,
            headers: {
                'Content-Type': 'application/json'
            },
            data: data
        };


        axios.request(config)
            .then((response) => {
                console.log(response.data)
                setget_group_full_data(response.data)
                setget_group_full_data_sort(response.data)
                setget_group_full_data_sort1(response.data)
            })
            .catch((error) => {
                console.log(error);
            })
    }

    function tagelsefunction(val, type) {
        let new_camera_list = cameras_view
        let flagcount = 0
        let flagcount1 = 0
        let flagcount2 = 0

        let group_value = []
        let camera_value = []

        let check = document.getElementsByClassName('tagCheckbox')
        for (let i = 0; i < check.length; i++) {
            if (check[i].checked === false) {
                flagcount = flagcount + 1
            }
        }

        let check1 = document.getElementsByClassName('groupCheckbox')
        for (let i = 0; i < check1.length; i++) {
            if (check1[i].checked === false) {
                flagcount1 = flagcount1 + 1
            } else {
                group_value.push({ name: get_group_full_data_sort[i].group_name, ind: i })
            }
        }

        let check2 = document.getElementsByClassName('cameraCheckbox')
        for (let i = 0; i < check2.length; i++) {
            if (check2[i].checked === false) {
                flagcount2 = flagcount2 + 1
            } else {
                camera_value.push({ name: cameras[i].camera_gereral_name, ind: i })
            }
        }

        if (check.length != flagcount) {

            if (val.tags.length !== 0) {
                for (let index = 0; index < val.tags.length; index++) {
                    let flag = false
                    let obj = []
                    for (let index1 = 0; index1 < new_camera_list.length; index1++) {
                        if (new_camera_list[index1]._id === val.tags[index]) {
                            if (check1.length != flagcount1) {
                                group_value.map((group) => {
                                    get_group_full_data_sort[group.ind].groups.map((groupdata) => {
                                        cameras_view.map((cameradata) => {
                                            if (groupdata === cameradata._id) {
                                                obj.push(cameradata)
                                            }
                                        })
                                    })
                                })
                            } else {
                                flag = false
                            }
                        } else {
                            flag = true
                            obj.push(new_camera_list[index1])

                        }
                    }

                    console.log(obj);
                    new_camera_list = obj

                }
            } else {
                new_camera_list = cameras_view
            }
        } else {
            if (check1.length != flagcount1 || check2.length != flagcount2) {
                if (val.tags.length !== 0) {

                    if (check.length == flagcount) {
                        let arr = []
                        for (let index = 0; index < cameras_view.length; index++) {
                            let flag = true
                            let obj = {}
                            for (let index1 = 0; index1 < val.tags.length; index1++) {
                                if (cameras_view[index]._id == val.tags[index1]) {
                                    flag = false
                                    break
                                } else {
                                    flag = true
                                    obj = cameras_view[index]
                                }
                            }

                            if (flag == true) {
                                arr.push(obj)
                            }

                        }

                        group_value.map((group) => {
                            get_group_full_data_sort[group.ind].groups.map((groupdata) => {
                                cameras.map((cameradata) => {
                                    if (groupdata === cameradata._id) {
                                        arr.push(cameradata)
                                    }
                                })
                            })
                        })


                        camera_value.map((group, i) => {
                            if (group.name == cameras[group.ind].camera_gereral_name) {
                                arr.push(cameras[group.ind])
                            }
                        })

                        const uniqueArray = [...new Set(arr)];
                        new_camera_list = uniqueArray


                    } else {
                        for (let index = 0; index < val.tags.length; index++) {
                            let flag = false
                            let obj = []
                            for (let index1 = 0; index1 < new_camera_list.length; index1++) {

                                if (new_camera_list[index1]._id === val.tags[index]) {
                                    if (check1.length != flagcount1) {
                                        group_value.map((group) => {
                                            get_group_full_data_sort[group.ind].groups.map((groupdata) => {
                                                cameras_view.map((cameradata) => {
                                                    if (groupdata === cameradata._id) {
                                                        obj.push(cameradata)
                                                    }
                                                })
                                            })
                                        })
                                    } else {
                                        flag = false
                                    }

                                    if (check2.length != flagcount2) {
                                        camera_value.map((group, i) => {
                                            obj.push(cameras_view[group.ind])
                                        })
                                    } else {
                                        flag = false
                                    }
                                } else {
                                    flag = true
                                    obj.push(new_camera_list[index1])

                                }
                            }


                            new_camera_list = obj

                        }
                    }

                    const uniqueArray = [...new Set(new_camera_list)];
                    new_camera_list = uniqueArray
                    console.log(new_camera_list);


                } else {

                    new_camera_list = cameras_view
                }
            } else {
                setget_tag_full_data_sort(get_tag_full_data)
                setget_tag_full_data_sort1(get_tag_full_data)
                setget_group_full_data_sort(get_group_full_data)
                setget_group_full_data_sort1(get_group_full_data)
                new_camera_list = cameras
            }

        }

        let camcnk = []
        tag_checkbox.map((cam) => {
            if (cam !== val._id) {
                camcnk.push(cam)
            }
        })

        settag_checkbox(camcnk)

        if (type == 'regular') {
            setcameras_view(new_camera_list)
            setcameras_view2(new_camera_list)
            setselectedcameras(new_camera_list)
            dispatch({ type: SELECTED_CAMERAS, value: new_camera_list })
            dispatch({ type: APPLY, value: !apply })
            setfinaldata([])
            setfinaldate('')
            setcolflag(true)
            setcolcount(40)
            setclickbtn2(true)
        }
    }

    function groupelsefunction(val, type) {
        let new_camera_list = cameras_view
        let flagcount = 0
        let flagcount1 = 0
        let flagcount2 = 0

        let group_value = []
        let camera_value = []

        let check = document.getElementsByClassName('groupsCheckbox')
        for (let i = 0; i < check.length; i++) {
            if (check[i].checked === false) {
                flagcount = flagcount + 1
            }
        }

        let check1 = document.getElementsByClassName('tagCheckbox')
        for (let i = 0; i < check1.length; i++) {
            if (check1[i].checked === false) {
                flagcount1 = flagcount1 + 1
            } else {
                group_value.push({ name: get_tag_full_data_sort[i].tag_name, ind: i })
            }
        }

        let check2 = document.getElementsByClassName('cameraCheckbox')
        for (let i = 0; i < check2.length; i++) {
            if (check2[i].checked === false) {
                flagcount2 = flagcount2 + 1
            } else {
                camera_value.push({ name: cameras[i].camera_gereral_name, ind: i })
            }
        }

        console.log(check.length != flagcount);

        if (check.length != flagcount) {
            if (val.tags.length !== 0) {
                for (let index = 0; index < val.tags.length; index++) {
                    let flag = false
                    let obj = []
                    for (let index1 = 0; index1 < new_camera_list.length; index1++) {
                        if (new_camera_list[index1]._id === val.tags[index]) {
                            if (check1.length != flagcount1) {
                                group_value.map((group) => {
                                    get_tag_full_data_sort[group].groups.map((groupdata) => {
                                        cameras_view.map((cameradata) => {
                                            if (groupdata === cameradata._id) {
                                                obj.push(cameradata)
                                            }
                                        })
                                    })
                                })
                            } else {
                                flag = false
                            }
                        } else {
                            flag = true
                            obj.push(new_camera_list[index1])

                        }
                    }


                    new_camera_list = obj

                }

            } else {
                new_camera_list = cameras_view
            }
        } else {
            if (check1.length != flagcount1 || check2.length != flagcount2) {
                if (val.groups.length !== 0) {
                    if (check.length == flagcount) {
                        let arr = []
                        for (let index = 0; index < cameras_view.length; index++) {
                            let flag = true
                            let obj = {}
                            for (let index1 = 0; index1 < val.groups.length; index1++) {
                                if (cameras_view[index]._id == val.groups[index1]) {
                                    flag = false
                                    break
                                } else {
                                    flag = true
                                    obj = cameras_view[index]
                                }
                            }

                            if (flag == true) {
                                arr.push(obj)
                            }

                        }

                        group_value.map((group) => {
                            get_tag_full_data_sort[group.ind].tags.map((groupdata) => {
                                cameras.map((cameradata) => {
                                    if (groupdata === cameradata._id) {
                                        arr.push(cameradata)
                                    }
                                })
                            })
                        })


                        camera_value.map((group, i) => {
                            if (group.name == cameras[group.ind].camera_gereral_name) {
                                arr.push(cameras[group.ind])
                            }
                        })

                        const uniqueArray = [...new Set(arr)];
                        new_camera_list = uniqueArray


                    } else {
                        for (let index = 0; index < val.groups.length; index++) {
                            let flag = false
                            let obj = []
                            for (let index1 = 0; index1 < new_camera_list.length; index1++) {
                                if (new_camera_list[index1]._id === val.groups[index]) {
                                    if (check1.length != flagcount1) {
                                        group_value.map((group) => {
                                            get_tag_full_data_sort[group].groups.map((groupdata) => {
                                                cameras_view.map((cameradata) => {
                                                    if (groupdata === cameradata._id) {
                                                        obj.push(cameradata)
                                                    }
                                                })
                                            })
                                        })
                                    } else {
                                        flag = false
                                    }

                                    if (check2.length != flagcount2) {
                                        camera_value.map((group) => {
                                            obj.push(cameras_view[group])
                                        })
                                    } else {
                                        flag = false
                                    }
                                } else {
                                    flag = true
                                    obj.push(new_camera_list[index1])

                                }
                            }


                            new_camera_list = obj

                        }
                    }
                    const uniqueArray = [...new Set(new_camera_list)];
                    new_camera_list = uniqueArray
                } else {
                    new_camera_list = cameras_view
                }
            } else {
                setget_tag_full_data_sort(get_tag_full_data)
                setget_tag_full_data_sort1(get_tag_full_data)
                setget_group_full_data_sort(get_group_full_data)
                setget_group_full_data_sort1(get_group_full_data)
                new_camera_list = cameras
            }
        }

        let camcnk = []
        group_checkbox.map((cam) => {
            if (cam !== val._id) {
                camcnk.push(cam)
            }
        })

        setgroup_checkbox(camcnk)

        if (type == 'regular') {
            setcameras_view(new_camera_list)
            setcameras_view2(new_camera_list)
            setselectedcameras(new_camera_list)
            dispatch({ type: SELECTED_CAMERAS, value: new_camera_list })
            dispatch({ type: APPLY, value: !apply })
            setfinaldata([])
            setfinaldate('')
            setcolflag(true)
            setcolcount(40)
            setclickbtn2(true)
        }
    }

    function searchfunction(event, data, type) {
        let str = event
        let arr = []

        if (event != '') {
            for (let i = 0; i < data.length; i++) {
                let username = type == 'camera_search' ? data[i].camera_gereral_name : type == 'camera_search1' ? data[i].camera_gereral_name : type == 'tag_search' ? data[i].tag_name : type == 'group_search' ? data[i].group_name : ''
                for (let j = 0; j < str.length; j++) {

                    for (let k = 0; k < username.length; k++) {
                        if (str[j].toUpperCase() === username[k].toUpperCase()) {
                            let wrd = ''
                            for (let l = k; l < k + str.length; l++) {
                                wrd = wrd + username[l]
                            }
                            if (str.toUpperCase() === wrd.toUpperCase()) {
                                arr.push(data[i])
                                break
                            }
                        }
                    }

                }
            }
        }

        if (arr.length != 0) {
            if (type == 'camera_search') {
                setcameras_view(arr)
            } else if (type == 'camera_search1') {
                setcameras(arr)
            } else if (type == 'tag_search') {
                setget_tag_full_data_sort(arr)
            } else if (type == 'group_search') {
                setget_group_full_data_sort(arr)
            }

        } else {
            if (type == 'camera_search') {
                setcameras_view([])
            } else if (type == 'camera_search1') {
                setcameras([])
            } else if (type == 'tag_search') {
                setget_tag_full_data_sort([])
            } else if (type == 'group_search') {
                setget_group_full_data_sort([])
            }
        }
    }


    async function geturifunction(accessKeyId, secretAccessKey, Bucket, Key, data) {
        const s3Client = new S3Client({
            region: "ap-south-1",
            credentials: {
                accessKeyId: accessKeyId,
                secretAccessKey: secretAccessKey,
            },
        });

        const video_command = new GetObjectCommand({
            Bucket: Bucket,
            Key: Key,
        });

        const image_command = new GetObjectCommand({
            Bucket: Bucket,
            Key: data.uri,
        });

        const url = await getSignedUrl(s3Client, video_command, { expiresIn: 3600 })
        const image_url = await getSignedUrl(s3Client, image_command)
        setvideo_uri(url)
        setimage_uri(image_url)
        console.log(url);
    }

    async function getimageurifunction(accessKeyId, secretAccessKey, Bucket, data, i) {
        const s3Client = new S3Client({
            region: "ap-south-1",
            credentials: {
                accessKeyId: accessKeyId,
                secretAccessKey: secretAccessKey,
            },
        });

        const image_command = new GetObjectCommand({
            Bucket: Bucket,
            Key: data.uri,
        });

        const image_url = await getSignedUrl(s3Client, image_command)
        return image_url
    }

    async function getinstanturifunction(accessKeyId, secretAccessKey, Bucket, Key, i) {

        if (finalflag) {
            const s3Client = new S3Client({
                region: "ap-south-1",
                credentials: {
                    accessKeyId: accessKeyId,
                    secretAccessKey: secretAccessKey,
                },
            });

            const video_command = new GetObjectCommand({
                Bucket: Bucket,
                Key: Key,
            });

            const url = await getSignedUrl(s3Client, video_command, { expiresIn: 3600 })

            let img = document.getElementById(`img${i}`)
            img.style.display = 'none'

            let vid = document.getElementById(`vid${i}`)
            vid.style.display = 'block'
            try {
                vid.src = url;
                vid.play();
            } catch (e) {
                console.log(e);
            }
        }
    }

    return (
        <>

            {/* <div>
                <video style={{ width: '100%', height: '100%' }} crossorigin="anonymous" src="https://sgp1.digitaloceanspaces.com/tentovision/JN-01/2023-07-10/Conference_Room/17:37:11.mp4" width={'100%'} height={'100%'} controls></video>
            </div>

            <div style={{ position: 'relative', width: '100%', height: '40px', backgroundColor: 'red' }}>
                <div style={{ position: 'absolute', height: '40px', backgroundColor: 'green', left: `${size.left}px`, width: `${size.width}px` }}>
                    <button style={{ position: 'absolute', height: '40px', right: '100%' }} onMouseDown={handlerLeft}></button>
                    <button style={{ position: 'absolute', height: '40px', left: '100%' }} onMouseDown={handlerRight}></button>
                </div>
            </div> */}

            <div>
                <Modal
                    open={open1}
                    onClose={handleClose1}
                    aria-labelledby="modal-modal-title"
                    aria-describedby="modal-modal-description"
                    style={{ marginLeft: 'auto', marginRight: 'auto', height: 550, width: '90%', top: 20 }}
                >
                    <div>
                        <Row>
                            <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                <div >

                                    <div style={{ backgroundColor: 'white', borderRadius: '5px', paddingTop: '10px', height: 550, maxHeight: 550, overflowY: 'scroll' }}>
                                        <Row style={{ padding: '10px', alignItems: 'center' }}>

                                            <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end' }}>
                                                    <CloseIcon style={{ color: 'black' }} onClick={() => handleClose1()} />
                                                </div>
                                            </Col>

                                        </Row>
                                        <Row style={{ padding: '10px', alignItems: 'center' }}>

                                            <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                                                    <div>
                                                        <input type='text' placeholder='Search' style={{ backgroundColor: '#e6e8eb', color: 'black', padding: '10px', borderRadius: '20px', border: '1px solid gray', marginRight: '20px' }} onChange={(e) => {
                                                            if (e.target.value !== '') {
                                                                if (full_camera_search == '') {
                                                                    setcameras_view2(cameras_view2)
                                                                }
                                                                searchfunction(e.target.value, cameras_view2, 'camera_search')
                                                                setfull_camera_search(e.target.value)
                                                            } else {
                                                                setcameras_view(cameras_view2)
                                                            }
                                                        }}></input>

                                                        <button style={{ marginTop: page === 1 ? '10px' : '', backgroundColor: filter ? '#e22747' : '#e6e8eb', color: filter ? 'white' : 'black', padding: '10px', borderRadius: '20px', border: '1px solid gray', }} onClick={() => {
                                                            setfilter(!filter)
                                                            get_tag_full_list()
                                                            get_group_full_list()
                                                        }}> <TuneOutlinedIcon style={{ marginRight: '10px' }} />Filter</button>
                                                    </div>

                                                    <div>
                                                        <p style={{ color: 'black', fontSize: '20px', margin: 0 }}><span style={{ color: 'white', backgroundColor: '#1b0182', borderRadius: '50%', paddingLeft: '10px', paddingRight: '10px', paddingTop: '3px', paddingBottom: '3px' }}>{selectedcameras.length}</span> / {cameras.length} Cameras Selected</p>
                                                    </div>
                                                </div>
                                            </Col>

                                        </Row>

                                        {
                                            filter ?
                                                <Row style={{ padding: '10px' }}>
                                                    <Col xl={12} lg={12} md={12} sm={12} xs={12} style={{ display: 'flex' }}>
                                                        <div style={{ position: 'relative' }}>
                                                            <button className='eventbtn' id='cameras' onClick={() => {
                                                                setcamera_box(!camera_box)
                                                                setcamera_tag(false)
                                                                setcamera_group(false)
                                                                setonline_status(false)


                                                            }} style={{ display: 'flex', backgroundColor: camera_box ? '#e22747' : '#e6e8eb', color: camera_box ? 'white' : 'black' }}> <AccessTimeIcon style={{ marginRight: '10px' }} />Cameras </button>

                                                            <div id='status' style={{ borderRadius: '5px', backgroundColor: '#181828', padding: '10px', position: 'absolute', top: '60px', zIndex: 1, boxShadow: 'rgba(0, 0, 0, 0.35) 0px 5px 15px', display: camera_box ? 'block' : 'none' }}>
                                                                <div style={{ position: 'relative' }}>

                                                                    <ArrowDropUpIcon style={{ fontSize: '50px', color: '#181828', margin: 0, position: 'absolute', top: '-37px' }} />
                                                                    <div style={{ display: 'flex', justifyContent: 'flex-end', flexDirection: 'column', alignItems: 'flex-end' }}>
                                                                        <div style={{ backgroundColor: '#e32747', borderRadius: '50%', padding: '2px', display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '10px' }}>
                                                                            <CloseIcon style={{ fontSize: '12px', color: 'white' }} onClick={() => {
                                                                                setcamera_box(!camera_box)
                                                                                setcamera_tag(false)
                                                                                setcamera_group(false)
                                                                                setonline_status(false)
                                                                            }} />
                                                                        </div>
                                                                        <div>
                                                                            <input type='text' placeholder='Search' style={{ backgroundColor: '#e6e8eb', color: 'black', padding: '10px', borderRadius: '20px', border: '1px solid gray', marginBottom: '5px', width: '100%', height: '40px' }} onChange={(e) => {
                                                                                if (e.target.value !== '') {
                                                                                    searchfunction(e.target.value, cameras1, 'camera_search1')
                                                                                    setcamera_search(e.target.value)
                                                                                } else {
                                                                                    setcameras(cameras1)
                                                                                }
                                                                            }}></input>
                                                                        </div>

                                                                        {
                                                                            cameras.length !== 0 ?
                                                                                <p style={{ margin: 0, color: 'white', cursor: 'pointer' }} onClick={() => {
                                                                                    let check = document.getElementsByClassName('tagCheckbox')
                                                                                    for (let i = 0; i < check.length; i++) {
                                                                                        check[i].checked = false
                                                                                    }

                                                                                    let group = document.getElementsByClassName('groupCheckbox')
                                                                                    for (let i = 0; i < group.length; i++) {
                                                                                        group[i].checked = false
                                                                                    }

                                                                                    let camera = document.getElementsByClassName('cameraCheckbox')
                                                                                    for (let i = 0; i < camera.length; i++) {
                                                                                        camera[i].checked = false
                                                                                    }
                                                                                    setget_tag_full_data_sort(get_tag_full_data)
                                                                                    setget_tag_full_data_sort1(get_tag_full_data)
                                                                                    setget_group_full_data_sort(get_group_full_data)
                                                                                    setget_group_full_data_sort1(get_group_full_data)
                                                                                    setcameras_view(cameras)
                                                                                    setcameras_view2(cameras)
                                                                                    setselectedcameras(cameras)
                                                                                    dispatch({ type: SELECTED_CAMERAS, value: cameras })
                                                                                    dispatch({ type: APPLY, value: !apply })
                                                                                    setfinaldata([])
                                                                                    setfinaldate('')
                                                                                    setcolflag(true)
                                                                                    setcolcount(40)
                                                                                    setclickbtn2(true)
                                                                                    setcamera_box(!camera_box)
                                                                                }}>Clear all</p>
                                                                                : ''
                                                                        }
                                                                    </div>

                                                                    <div className='lower_alerts' style={{ maxHeight: '200px', overflowY: 'scroll' }}>
                                                                        {
                                                                            cameras.length !== 0 ?
                                                                                cameras.map((val, k) => {
                                                                                    let typ = false
                                                                                    camera_checkbox.map((id) => {
                                                                                        if (id == val._id) {
                                                                                            typ = true
                                                                                        }
                                                                                    })
                                                                                    return (
                                                                                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px' }}>
                                                                                            <p style={{ margin: 0, color: 'white', width: '200px' }}>{val.camera_gereral_name}<span style={{ color: 'white', borderRadius: '50%', backgroundColor: '#a8a4a4', marginLeft: '10px', paddingLeft: '8px', paddingRight: '8px', paddingTop: '3px', paddingBottom: '3px' }}>{1}</span></p>
                                                                                            <input className='cameraCheckbox' checked={typ ? true : false} type="checkbox" onClick={(e) => {

                                                                                                let flagcount = 0
                                                                                                let flagcount1 = 0
                                                                                                let flagcount2 = 0

                                                                                                let group_value = []
                                                                                                let tag_value = []

                                                                                                let check = document.getElementsByClassName('tagCheckbox')
                                                                                                for (let i = 0; i < check.length; i++) {
                                                                                                    if (check[i].checked === false) {
                                                                                                        flagcount = flagcount + 1
                                                                                                    } else {
                                                                                                        tag_value.push(i)
                                                                                                    }
                                                                                                }

                                                                                                let check1 = document.getElementsByClassName('groupCheckbox')
                                                                                                for (let i = 0; i < check1.length; i++) {
                                                                                                    if (check1[i].checked === false) {
                                                                                                        flagcount1 = flagcount1 + 1
                                                                                                    } else {
                                                                                                        group_value.push(i)
                                                                                                    }
                                                                                                }


                                                                                                let check2 = []

                                                                                                if (camera_search == '') {
                                                                                                    check2 = document.getElementsByClassName('cameraCheckbox')
                                                                                                    for (let i = 0; i < check2.length; i++) {
                                                                                                        if (i != k && check2[i].checked === false) {
                                                                                                            flagcount2 = flagcount2 + 1
                                                                                                        }
                                                                                                    }
                                                                                                } else {
                                                                                                    check2 = camera_checkbox
                                                                                                    check2.push(1)
                                                                                                }



                                                                                                if (e.target.checked === true) {
                                                                                                    let new_camera_tag = []
                                                                                                    let new_camera_group = []
                                                                                                    let newcamera = []


                                                                                                    if (check2.length > flagcount2) {
                                                                                                        if (val.camera_tags.length !== 0) {

                                                                                                            for (let index = 0; index < val.camera_tags.length; index++) {
                                                                                                                let flag = false
                                                                                                                let obj = ''

                                                                                                                for (let index1 = 0; index1 < get_tag_full_data.length; index1++) {


                                                                                                                    if (get_tag_full_data[index1]._id === val.camera_tags[index].id) {
                                                                                                                        flag = true
                                                                                                                        obj = get_tag_full_data[index1]
                                                                                                                        break
                                                                                                                    } else {
                                                                                                                        flag = false
                                                                                                                    }
                                                                                                                }

                                                                                                                if (flag === true) {
                                                                                                                    new_camera_tag.push(obj)
                                                                                                                }
                                                                                                            }



                                                                                                            if (flagcount2 <= check2.length - 2) {
                                                                                                                new_camera_tag = [...get_tag_full_data_sort, ...new_camera_tag]
                                                                                                            }

                                                                                                            const uniqueArray = [...new Set(new_camera_tag)];
                                                                                                            new_camera_tag = uniqueArray


                                                                                                        } else {
                                                                                                            if (check2.length == flagcount2) {
                                                                                                                new_camera_tag = []
                                                                                                            } else {
                                                                                                                if (check.length == flagcount) {
                                                                                                                    new_camera_tag = []
                                                                                                                } else {
                                                                                                                    new_camera_tag = get_tag_full_data_sort
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    } else {
                                                                                                        new_camera_tag = get_tag_full_data
                                                                                                    }

                                                                                                    if (check2.length > flagcount2) {
                                                                                                        if (val.camera_groups.length !== 0) {
                                                                                                            for (let index = 0; index < val.camera_groups.length; index++) {
                                                                                                                let flag = false
                                                                                                                let obj = ''

                                                                                                                for (let index1 = 0; index1 < get_group_full_data.length; index1++) {

                                                                                                                    if (get_group_full_data[index1]._id === val.camera_groups[index].id) {
                                                                                                                        flag = true
                                                                                                                        obj = get_group_full_data[index1]
                                                                                                                        break
                                                                                                                    } else {
                                                                                                                        flag = false
                                                                                                                    }
                                                                                                                }

                                                                                                                if (flag === true) {
                                                                                                                    new_camera_group.push(obj)
                                                                                                                }


                                                                                                            }

                                                                                                            if (flagcount2 <= check2.length - 2) {
                                                                                                                new_camera_group = [...get_group_full_data_sort, ...new_camera_group]
                                                                                                            }
                                                                                                            const uniqueArray = [...new Set(new_camera_group)];
                                                                                                            new_camera_group = uniqueArray

                                                                                                        } else {
                                                                                                            if (check2.length == flagcount2) {
                                                                                                                new_camera_group = []
                                                                                                            } else {
                                                                                                                if (check.length == flagcount) {
                                                                                                                    new_camera_group = []
                                                                                                                } else {
                                                                                                                    new_camera_group = get_group_full_data_sort
                                                                                                                }

                                                                                                            }

                                                                                                        }
                                                                                                    } else {
                                                                                                        new_camera_group = get_group_full_data
                                                                                                    }


                                                                                                    if (check2.length - 1 != flagcount2) {
                                                                                                        for (let index1 = 0; index1 < cameras_view.length; index1++) {

                                                                                                            if (cameras_view[index1]._id === val._id) {
                                                                                                                break
                                                                                                            } else {
                                                                                                                newcamera.push(val)
                                                                                                            }
                                                                                                        }


                                                                                                        newcamera = [...cameras_view, ...newcamera]
                                                                                                        const uniqueArray = [...new Set(newcamera)];
                                                                                                        newcamera = uniqueArray
                                                                                                    } else {
                                                                                                        newcamera = [val]
                                                                                                    }


                                                                                                    setcamera_checkbox([...camera_checkbox, val._id])
                                                                                                    setget_tag_full_data_sort(new_camera_tag)
                                                                                                    setget_tag_full_data_sort1(new_camera_tag)
                                                                                                    setget_group_full_data_sort(new_camera_group)
                                                                                                    setget_group_full_data_sort1(new_camera_group)
                                                                                                    setcameras_view(newcamera)
                                                                                                    setcameras_view2(newcamera)
                                                                                                    setselectedcameras(newcamera)
                                                                                                    dispatch({ type: SELECTED_CAMERAS, value: newcamera })
                                                                                                    dispatch({ type: APPLY, value: !apply })
                                                                                                    setfinaldata([])
                                                                                                    setfinaldate('')
                                                                                                    setcolflag(true)
                                                                                                    setcolcount(40)
                                                                                                    setclickbtn2(true)
                                                                                                } else {
                                                                                                    let new_camera_list = cameras_view


                                                                                                    if (check2.length != flagcount2) {

                                                                                                        let arr = []
                                                                                                        let tag = []
                                                                                                        let group = []
                                                                                                        cameras_view.map((cam) => {
                                                                                                            if (cam._id !== val._id) {
                                                                                                                arr.push(cam)
                                                                                                            }
                                                                                                        })

                                                                                                        new_camera_list = arr


                                                                                                        if (check1.length == flagcount1) {
                                                                                                            arr.map((ele) => {
                                                                                                                get_group_full_data_sort.map((ele3) => {
                                                                                                                    ele3.groups.map((ele4, i) => {
                                                                                                                        if (ele._id == ele4) {
                                                                                                                            group.push(ele3)
                                                                                                                        }
                                                                                                                    })
                                                                                                                })
                                                                                                            })

                                                                                                            const groups = [...new Set(group)];
                                                                                                            setget_group_full_data_sort(groups)
                                                                                                            setget_group_full_data_sort1(groups)
                                                                                                        }

                                                                                                        if (check1.length != flagcount1) {
                                                                                                            new_camera_list = cameras_view
                                                                                                        }

                                                                                                        if (check.length == flagcount) {
                                                                                                            arr.map((ele) => {
                                                                                                                get_tag_full_data_sort.map((ele3) => {
                                                                                                                    ele3.tags.map((ele4, i) => {
                                                                                                                        if (ele._id == ele4) {
                                                                                                                            console.log();
                                                                                                                            tag.push(ele3)
                                                                                                                        }
                                                                                                                    })
                                                                                                                })
                                                                                                            })

                                                                                                            const tags = [...new Set(tag)];

                                                                                                            setget_tag_full_data_sort(tags)
                                                                                                            setget_tag_full_data_sort1(tags)
                                                                                                        }

                                                                                                        if (check.length != flagcount) {
                                                                                                            new_camera_list = cameras_view
                                                                                                        }

                                                                                                    } else {
                                                                                                        if (check1.length != flagcount1 || check.length != flagcount) {

                                                                                                            let flag = false
                                                                                                            let obj = []
                                                                                                            if (check1.length != flagcount1) {
                                                                                                                group_value.map((group) => {
                                                                                                                    get_group_full_data_sort[group].groups.map((groupdata) => {
                                                                                                                        cameras_view.map((cameradata) => {
                                                                                                                            if (groupdata === cameradata._id) {
                                                                                                                                obj.push(cameradata)
                                                                                                                            }
                                                                                                                        })
                                                                                                                    })
                                                                                                                })
                                                                                                            } else {
                                                                                                                flag = false
                                                                                                            }

                                                                                                            if (check.length != flagcount) {
                                                                                                                tag_value.map((group) => {
                                                                                                                    get_tag_full_data_sort[group].tags.map((groupdata) => {
                                                                                                                        cameras_view.map((cameradata) => {
                                                                                                                            if (groupdata === cameradata._id) {
                                                                                                                                obj.push(cameradata)
                                                                                                                            }
                                                                                                                        })
                                                                                                                    })
                                                                                                                })
                                                                                                            } else {
                                                                                                                flag = false
                                                                                                            }


                                                                                                            new_camera_list = obj
                                                                                                            const uniqueArray = [...new Set(new_camera_list)];
                                                                                                            new_camera_list = uniqueArray
                                                                                                        } else {

                                                                                                            new_camera_list = cameras
                                                                                                            setget_tag_full_data_sort(get_tag_full_data)
                                                                                                            setget_tag_full_data_sort1(get_tag_full_data)
                                                                                                            setget_group_full_data_sort(get_group_full_data)
                                                                                                            setget_group_full_data_sort1(get_group_full_data)
                                                                                                        }

                                                                                                    }

                                                                                                    let camcnk = []
                                                                                                    camera_checkbox.map((cam) => {
                                                                                                        if (cam !== val._id) {
                                                                                                            camcnk.push(cam)
                                                                                                        }
                                                                                                    })

                                                                                                    setcamera_checkbox(camcnk)
                                                                                                    setcameras_view(new_camera_list)
                                                                                                    setcameras_view2(new_camera_list)
                                                                                                    setselectedcameras(new_camera_list)
                                                                                                    dispatch({ type: SELECTED_CAMERAS, value: new_camera_list })
                                                                                                    dispatch({ type: APPLY, value: !apply })
                                                                                                    setfinaldata([])
                                                                                                    setfinaldate('')
                                                                                                    setcolflag(true)
                                                                                                    setcolcount(40)
                                                                                                    setclickbtn2(true)
                                                                                                }
                                                                                            }}></input>
                                                                                        </div>
                                                                                    )
                                                                                })
                                                                                :
                                                                                <p style={{ margin: 0, color: 'grey', width: '200px', textAlign: 'center' }}>No Cameras</p>
                                                                        }
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div style={{ position: 'relative' }}>
                                                            <button className='eventbtn' id='cameras' onClick={() => {
                                                                setonline_status(!online_status)
                                                                setcamera_box(false)
                                                                setcamera_tag(false)
                                                                setcamera_group(false)

                                                            }} style={{ display: 'flex', backgroundColor: online_status ? '#e22747' : '#e6e8eb', color: online_status ? 'white' : 'black' }}> <AccessTimeIcon style={{ marginRight: '10px' }} />Status </button>

                                                            <div id='status' style={{ borderRadius: '5px', backgroundColor: '#181828', padding: '10px', position: 'absolute', top: '60px', zIndex: 1, boxShadow: 'rgba(0, 0, 0, 0.35) 0px 5px 15px', display: online_status ? 'block' : 'none' }}>
                                                                <div style={{ position: 'relative' }}>

                                                                    <ArrowDropUpIcon style={{ fontSize: '50px', color: '#181828', margin: 0, position: 'absolute', top: '-37px' }} />
                                                                    <div style={{ display: 'flex', justifyContent: 'flex-end', flexDirection: 'column', alignItems: 'flex-end' }}>
                                                                        <div style={{ backgroundColor: '#e32747', borderRadius: '50%', padding: '2px', display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '10px' }}>
                                                                            <CloseIcon style={{ fontSize: '12px', color: 'white' }} onClick={() => {
                                                                                setonline_status(!online_status)
                                                                                setcamera_box(false)
                                                                                setcamera_tag(false)
                                                                                setcamera_group(false)
                                                                            }} />
                                                                        </div>
                                                                    </div>

                                                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px' }}>
                                                                        <p style={{ margin: 0, color: 'white', width: '200px' }}>Online<span style={{ color: 'white', borderRadius: '50%', backgroundColor: '#a8a4a4', marginLeft: '10px', paddingLeft: '8px', paddingRight: '8px', paddingTop: '3px', paddingBottom: '3px' }}>{selectedcameras.length}</span></p>
                                                                        <input className='onlineCheckbox' type="checkbox" onClick={(e) => {
                                                                            if (e.target.checked === true) {
                                                                                // let arr = []
                                                                                // data.map((val) => {
                                                                                //     if (val.objects.length !== 0 && val.objects.person !== undefined) {
                                                                                //         arr.push(val)
                                                                                //     }
                                                                                // })
                                                                                // setdata2(arr)
                                                                                // console.log(arr);
                                                                                let active = []
                                                                                cameras.map((val) => {
                                                                                    if (val.Active === 1) {
                                                                                        active.push(val)
                                                                                    }
                                                                                })
                                                                                // setcameras_view(active)
                                                                                // setselectedcameras(active)
                                                                                // dispatch({ type: SELECTED_CAMERAS, value: active })
                                                                                // dispatch({ type: APPLY, value: !apply })
                                                                                // console.log([...selectedanalytics, val]);
                                                                            } else {
                                                                                // setcameras_view(cameras)
                                                                                // setselectedcameras(cameras)
                                                                                // dispatch({ type: SELECTED_CAMERAS, value: cameras })
                                                                                // dispatch({ type: APPLY, value: !apply })
                                                                            }
                                                                        }}></input>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div style={{ position: 'relative' }}>
                                                            <button className='eventbtn' id='cameras' onClick={() => {
                                                                setcamera_tag(!camera_tag)
                                                                setonline_status(false)
                                                                setcamera_box(false)
                                                                setcamera_group(false)

                                                            }} style={{ display: 'flex', backgroundColor: camera_tag ? '#e22747' : '#e6e8eb', color: camera_tag ? 'white' : 'black' }}> <AccessTimeIcon style={{ marginRight: '10px' }} />Tags <div style={{ backgroundColor: '#e32747', padding: '3px', borderRadius: '50%', height: '25px', width: '25px', marginLeft: '10px' }}><p style={{ color: 'white' }}>{get_tag_full_data_sort.length}</p></div> <ArrowDropDownIcon style={{ marginLeft: '0px' }} /></button>

                                                            <div>
                                                                <div style={{ borderRadius: '5px', backgroundColor: '#181828', padding: '10px', position: 'absolute', top: '60px', zIndex: 1, boxShadow: 'rgba(0, 0, 0, 0.35) 0px 5px 15px', display: camera_tag ? 'block' : 'none' }}>
                                                                    <div style={{ position: 'relative' }}>

                                                                        <ArrowDropUpIcon style={{ fontSize: '50px', color: '#181828', margin: 0, position: 'absolute', top: '-37px' }} />
                                                                        <div style={{ display: 'flex', justifyContent: 'flex-end', flexDirection: 'column', alignItems: 'flex-end' }}>
                                                                            <div style={{ backgroundColor: '#e32747', borderRadius: '50%', padding: '2px', display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '10px' }}>
                                                                                <CloseIcon style={{ fontSize: '12px', color: 'white' }} onClick={() => {
                                                                                    setcamera_tag(!camera_tag)
                                                                                    setonline_status(false)
                                                                                    setcamera_box(false)
                                                                                    setcamera_group(false)
                                                                                }} />
                                                                            </div>

                                                                            <div>
                                                                                <input type='text' placeholder='Search' style={{ backgroundColor: '#e6e8eb', color: 'black', padding: '10px', borderRadius: '20px', border: '1px solid gray', marginBottom: '5px', width: '100%', height: '40px' }} onChange={(e) => {
                                                                                    if (e.target.value !== '') {
                                                                                        if (tag_search == '') {
                                                                                            setget_tag_full_data_sort1(get_tag_full_data_sort)
                                                                                        }
                                                                                        searchfunction(e.target.value, get_tag_full_data_sort1, 'tag_search')
                                                                                        settag_search(e.target.value)
                                                                                    } else {
                                                                                        setget_tag_full_data_sort(get_tag_full_data_sort1)
                                                                                    }
                                                                                }}></input>
                                                                            </div>


                                                                            {
                                                                                get_tag_full_data_sort.length !== 0 ?
                                                                                    <p style={{ margin: 0, color: 'white', cursor: 'pointer' }} onClick={() => {
                                                                                        let tag_value = []
                                                                                        let check = document.getElementsByClassName('tagCheckbox')
                                                                                        for (let i = 0; i < check.length; i++) {
                                                                                            if (check[i].checked == true) {
                                                                                                tag_value.push(get_tag_full_data_sort[i])
                                                                                            }
                                                                                            check[i].checked = false
                                                                                        }

                                                                                        tag_value.map((val) => {
                                                                                            tagelsefunction(val, 'once')
                                                                                        })

                                                                                        dispatch({ type: APPLY, value: !apply })
                                                                                        setcamera_tag(!camera_tag)
                                                                                    }}>Clear all</p>
                                                                                    : ''
                                                                            }

                                                                        </div>

                                                                        <div className='lower_alerts' style={{ maxHeight: '200px', overflowY: 'scroll' }}>
                                                                            {
                                                                                get_tag_full_data_sort.length !== 0 ?
                                                                                    get_tag_full_data_sort.map((val, k) => {
                                                                                        let typ = false
                                                                                        tag_checkbox.map((id) => {
                                                                                            if (id == val._id) {
                                                                                                typ = true
                                                                                            }
                                                                                        })
                                                                                        return (
                                                                                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px' }}>
                                                                                                <p style={{ margin: 0, color: 'white', width: '200px' }}>{val.tag_name.charAt(0).toUpperCase() + val.tag_name.slice(1)}<span style={{ color: 'white', borderRadius: '50%', backgroundColor: '#a8a4a4', marginLeft: '10px', paddingLeft: '8px', paddingRight: '8px', paddingTop: '3px', paddingBottom: '3px' }}>{val.tags.length}</span></p>
                                                                                                <input className='tagCheckbox' checked={typ ? true : false} type="checkbox" onClick={(e) => {


                                                                                                    if (e.target.checked === true) {

                                                                                                        const axios = require('axios');
                                                                                                        let data = JSON.stringify({
                                                                                                            "tag_id": val._id
                                                                                                        });

                                                                                                        let config = {
                                                                                                            method: 'post',
                                                                                                            maxBodyLength: Infinity,
                                                                                                            url: api.TAG_API_LIST_ALL_ID,
                                                                                                            headers: {
                                                                                                                'Content-Type': 'application/json'
                                                                                                            },
                                                                                                            data: data
                                                                                                        };


                                                                                                        axios.request(config)
                                                                                                            .then((response) => {
                                                                                                                let new_camera_list = []
                                                                                                                let flagcount = 0
                                                                                                                let flagcount1 = 0
                                                                                                                let flagcount2 = 0

                                                                                                                let check = []

                                                                                                                if (tag_search == '') {
                                                                                                                    check = document.getElementsByClassName('tagCheckbox')
                                                                                                                    for (let i = 0; i < check.length; i++) {
                                                                                                                        if (i != k && check[i].checked === false) {
                                                                                                                            flagcount = flagcount + 1
                                                                                                                        }
                                                                                                                    }
                                                                                                                } else {
                                                                                                                    check = camera_checkbox
                                                                                                                    check.push(1)
                                                                                                                }

                                                                                                                let check1 = document.getElementsByClassName('groupCheckbox')
                                                                                                                for (let i = 0; i < check1.length; i++) {
                                                                                                                    if (check1[i].checked === false) {
                                                                                                                        flagcount1 = flagcount1 + 1
                                                                                                                    }
                                                                                                                }

                                                                                                                let check2 = document.getElementsByClassName('cameraCheckbox')
                                                                                                                for (let i = 0; i < check2.length; i++) {
                                                                                                                    if (check2[i].checked === false) {
                                                                                                                        flagcount2 = flagcount2 + 1
                                                                                                                    }
                                                                                                                }

                                                                                                                console.log(check.length, flagcount);
                                                                                                                if (check.length > flagcount) {
                                                                                                                    if (response.data.length !== 0) {
                                                                                                                        if (check.length - 1 == flagcount) {
                                                                                                                            if (check1.length == flagcount1 && check2.length == flagcount2) {

                                                                                                                                new_camera_list = response.data
                                                                                                                            } else {
                                                                                                                                let data = [...cameras_view, ...response.data]
                                                                                                                                for (let index = 0; index < data.length; index++) {
                                                                                                                                    let flag = true
                                                                                                                                    let obj = ''
                                                                                                                                    for (let index1 = 0; index1 < cameras_view.length; index1++) {
                                                                                                                                        if (cameras_view[index1]._id === data[index]._id) {
                                                                                                                                            flag = false
                                                                                                                                            break
                                                                                                                                        } else {
                                                                                                                                            flag = true
                                                                                                                                            obj = data[index]
                                                                                                                                        }
                                                                                                                                    }

                                                                                                                                    if (flag === true) {
                                                                                                                                        new_camera_list.push(obj)
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                new_camera_list = [...cameras_view, ...new_camera_list]
                                                                                                                            }

                                                                                                                        } else {
                                                                                                                            let data = [...cameras_view, ...response.data]
                                                                                                                            for (let index = 0; index < data.length; index++) {
                                                                                                                                let flag = true
                                                                                                                                let obj = ''
                                                                                                                                for (let index1 = 0; index1 < cameras_view.length; index1++) {
                                                                                                                                    if (cameras_view[index1]._id === data[index]._id) {
                                                                                                                                        flag = false
                                                                                                                                        break
                                                                                                                                    } else {
                                                                                                                                        flag = true
                                                                                                                                        obj = data[index]
                                                                                                                                    }
                                                                                                                                }

                                                                                                                                if (flag === true) {
                                                                                                                                    new_camera_list.push(obj)
                                                                                                                                }
                                                                                                                            }
                                                                                                                            new_camera_list = [...cameras_view, ...new_camera_list]
                                                                                                                        }

                                                                                                                    } else {

                                                                                                                        new_camera_list = cameras_view
                                                                                                                    }
                                                                                                                } else {
                                                                                                                    new_camera_list = cameras
                                                                                                                }

                                                                                                                settag_checkbox([...tag_checkbox, val._id])
                                                                                                                setcameras_view(new_camera_list)
                                                                                                                setcameras_view2(new_camera_list)
                                                                                                                setselectedcameras(new_camera_list)
                                                                                                                dispatch({ type: SELECTED_CAMERAS, value: new_camera_list })
                                                                                                                dispatch({ type: APPLY, value: !apply })
                                                                                                                setfinaldata([])
                                                                                                                setfinaldate('')
                                                                                                                setcolflag(true)
                                                                                                                setcolcount(40)
                                                                                                                setclickbtn2(true)
                                                                                                            })
                                                                                                            .catch((error) => {
                                                                                                                console.log(error);
                                                                                                            })

                                                                                                        // console.log([...selectedanalytics, val]);
                                                                                                    } else {
                                                                                                        tagelsefunction(val, 'regular')
                                                                                                    }
                                                                                                }
                                                                                                }></input>
                                                                                            </div>
                                                                                        )
                                                                                    })
                                                                                    :
                                                                                    <p style={{ margin: 0, color: 'grey', width: '200px', textAlign: 'center' }}>No Tags</p>
                                                                            }
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div style={{ position: 'relative' }}>
                                                            <button className='eventbtn' id='cameras' onClick={() => {
                                                                setcamera_group(!camera_group)
                                                                setcamera_tag(false)
                                                                setonline_status(false)
                                                                setcamera_box(false)

                                                            }} style={{ display: 'flex', backgroundColor: camera_group ? '#e22747' : '#e6e8eb', color: camera_group ? 'white' : 'black' }}> <AccessTimeIcon style={{ marginRight: '10px' }} />Groups <div style={{ backgroundColor: '#e32747', padding: '3px', borderRadius: '50%', height: '25px', width: '25px', marginLeft: '10px' }}><p style={{ color: 'white' }}>{get_group_full_data.length}</p></div> <ArrowDropDownIcon style={{ marginLeft: '0px' }} /></button>

                                                            <div>
                                                                <div style={{ borderRadius: '5px', backgroundColor: '#181828', padding: '10px', position: 'absolute', top: '60px', zIndex: 1, boxShadow: 'rgba(0, 0, 0, 0.35) 0px 5px 15px', display: camera_group ? 'block' : 'none' }}>
                                                                    <div style={{ position: 'relative' }}>

                                                                        <ArrowDropUpIcon style={{ fontSize: '50px', color: '#181828', margin: 0, position: 'absolute', top: '-37px' }} />
                                                                        <div style={{ display: 'flex', justifyContent: 'flex-end', flexDirection: 'column', alignItems: 'flex-end' }}>
                                                                            <div style={{ backgroundColor: '#e32747', borderRadius: '50%', padding: '2px', display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '10px' }}>
                                                                                <CloseIcon style={{ fontSize: '12px', color: 'white' }} onClick={() => {
                                                                                    setcamera_group(!camera_group)
                                                                                    setcamera_tag(false)
                                                                                    setonline_status(false)
                                                                                    setcamera_box(false)
                                                                                }} />
                                                                            </div>

                                                                            <div>
                                                                                <input type='text' placeholder='Search' style={{ backgroundColor: '#e6e8eb', color: 'black', padding: '10px', borderRadius: '20px', border: '1px solid gray', marginBottom: '5px', width: '100%', height: '40px' }} onChange={(e) => {
                                                                                    if (e.target.value !== '') {
                                                                                        if (group_search == '') {
                                                                                            setget_group_full_data_sort1(get_group_full_data_sort)
                                                                                        }
                                                                                        searchfunction(e.target.value, get_group_full_data_sort1, 'group_search')
                                                                                        setgroup_search(e.target.value)
                                                                                    } else {
                                                                                        setget_group_full_data_sort(get_group_full_data_sort1)
                                                                                    }
                                                                                }}></input>
                                                                            </div>
                                                                            {
                                                                                get_group_full_data_sort.length !== 0 ?
                                                                                    <p style={{ margin: 0, color: 'white', cursor: 'pointer' }} onClick={() => {
                                                                                        let group_value = []
                                                                                        let check = document.getElementsByClassName('groupCheckbox')
                                                                                        for (let i = 0; i < check.length; i++) {
                                                                                            if (check[i].checked == true) {
                                                                                                group_value.push(get_group_full_data_sort[i])
                                                                                            }
                                                                                            check[i].checked = false
                                                                                        }

                                                                                        group_value.map((val) => {
                                                                                            groupelsefunction(val, 'once')
                                                                                        })

                                                                                        dispatch({ type: APPLY, value: !apply })
                                                                                        setcamera_group(!camera_group)
                                                                                    }}>Clear all</p>
                                                                                    : ''
                                                                            }

                                                                        </div>

                                                                        <div className='lower_alerts' style={{ maxHeight: '200px', overflowY: 'scroll' }}>
                                                                            {
                                                                                get_group_full_data_sort.length !== 0 ?
                                                                                    get_group_full_data_sort.map((val, k) => {
                                                                                        let typ = false
                                                                                        group_checkbox.map((id) => {
                                                                                            if (id == val._id) {
                                                                                                typ = true
                                                                                            }
                                                                                        })
                                                                                        return (
                                                                                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px' }}>
                                                                                                <p style={{ margin: 0, color: 'white', width: '200px' }}>{val.group_name.charAt(0).toUpperCase() + val.group_name.slice(1)}<span style={{ color: 'white', borderRadius: '50%', backgroundColor: '#a8a4a4', marginLeft: '10px', paddingLeft: '8px', paddingRight: '8px', paddingTop: '3px', paddingBottom: '3px' }}>{val.groups.length}</span></p>
                                                                                                <input className='groupCheckbox' checked={typ ? true : false} type="checkbox" onClick={(e) => {
                                                                                                    if (e.target.checked === true) {
                                                                                                        const axios = require('axios');
                                                                                                        let data = JSON.stringify({
                                                                                                            "group_id": val._id
                                                                                                        });

                                                                                                        let config = {
                                                                                                            method: 'post',
                                                                                                            maxBodyLength: Infinity,
                                                                                                            url: api.GROUP_API_LIST_ALL_ID,
                                                                                                            headers: {
                                                                                                                'Content-Type': 'application/json'
                                                                                                            },
                                                                                                            data: data
                                                                                                        };


                                                                                                        axios.request(config)
                                                                                                            .then((response) => {
                                                                                                                console.log(response.data)
                                                                                                                let new_camera_list = []
                                                                                                                let flagcount = 0
                                                                                                                let flagcount1 = 0
                                                                                                                let flagcount2 = 0

                                                                                                                let check = document.getElementsByClassName('tagCheckbox')
                                                                                                                for (let i = 0; i < check.length; i++) {
                                                                                                                    if (check[i].checked === false) {
                                                                                                                        flagcount = flagcount + 1
                                                                                                                    }
                                                                                                                }

                                                                                                                let check1 = []

                                                                                                                if (group_search == '') {
                                                                                                                    check1 = document.getElementsByClassName('groupCheckbox')
                                                                                                                    for (let i = 0; i < check1.length; i++) {
                                                                                                                        if (i != k && check1[i].checked === false) {
                                                                                                                            flagcount1 = flagcount1 + 1
                                                                                                                        }
                                                                                                                    }
                                                                                                                } else {
                                                                                                                    check1 = camera_checkbox
                                                                                                                    check1.push(1)
                                                                                                                }

                                                                                                                let check2 = document.getElementsByClassName('cameraCheckbox')
                                                                                                                for (let i = 0; i < check2.length; i++) {
                                                                                                                    if (check2[i].checked === false) {
                                                                                                                        flagcount2 = flagcount2 + 1
                                                                                                                    }
                                                                                                                }

                                                                                                                if (check.length > flagcount) {
                                                                                                                    if (response.data.length !== 0) {
                                                                                                                        if (check.length - 1 == flagcount) {
                                                                                                                            if (check1.length == flagcount1 && check2.length == flagcount2) {

                                                                                                                                new_camera_list = response.data
                                                                                                                            } else {
                                                                                                                                let data = [...cameras_view, ...response.data]
                                                                                                                                for (let index = 0; index < data.length; index++) {
                                                                                                                                    let flag = true
                                                                                                                                    let obj = ''
                                                                                                                                    for (let index1 = 0; index1 < cameras_view.length; index1++) {
                                                                                                                                        if (cameras_view[index1]._id === data[index]._id) {
                                                                                                                                            flag = false
                                                                                                                                            break
                                                                                                                                        } else {
                                                                                                                                            flag = true
                                                                                                                                            obj = data[index]
                                                                                                                                        }
                                                                                                                                    }

                                                                                                                                    if (flag === true) {
                                                                                                                                        new_camera_list.push(obj)
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                new_camera_list = [...cameras_view, ...new_camera_list]
                                                                                                                            }

                                                                                                                        } else {
                                                                                                                            let data = [...cameras_view, ...response.data]
                                                                                                                            for (let index = 0; index < data.length; index++) {
                                                                                                                                let flag = true
                                                                                                                                let obj = ''
                                                                                                                                for (let index1 = 0; index1 < cameras_view.length; index1++) {
                                                                                                                                    if (cameras_view[index1]._id === data[index]._id) {
                                                                                                                                        flag = false
                                                                                                                                        break
                                                                                                                                    } else {
                                                                                                                                        flag = true
                                                                                                                                        obj = data[index]
                                                                                                                                    }
                                                                                                                                }

                                                                                                                                if (flag === true) {
                                                                                                                                    new_camera_list.push(obj)
                                                                                                                                }
                                                                                                                            }
                                                                                                                            new_camera_list = [...cameras_view, ...new_camera_list]
                                                                                                                        }

                                                                                                                    } else {

                                                                                                                        new_camera_list = cameras_view
                                                                                                                    }
                                                                                                                } else {

                                                                                                                    new_camera_list = cameras
                                                                                                                }

                                                                                                                settag_checkbox([...group_checkbox, val._id])
                                                                                                                setcameras_view(new_camera_list)
                                                                                                                setcameras_view2(new_camera_list)
                                                                                                                setselectedcameras(new_camera_list)
                                                                                                                dispatch({ type: SELECTED_CAMERAS, value: new_camera_list })
                                                                                                                dispatch({ type: APPLY, value: !apply })
                                                                                                                setfinaldata([])
                                                                                                                setfinaldate('')
                                                                                                                setcolflag(true)
                                                                                                                setcolcount(40)
                                                                                                                setclickbtn2(true)
                                                                                                            })
                                                                                                            .catch((error) => {
                                                                                                                console.log(error);
                                                                                                            })

                                                                                                        // console.log([...selectedanalytics, val]);
                                                                                                    } else {

                                                                                                        groupelsefunction(val, 'regular')
                                                                                                    }
                                                                                                }}></input>
                                                                                            </div>
                                                                                        )
                                                                                    })
                                                                                    :
                                                                                    <p style={{ margin: 0, color: 'grey', width: '200px', textAlign: 'center' }}>No Groups</p>
                                                                            }
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </Col>
                                                </Row>
                                                : ''
                                        }

                                        <Row style={{ padding: '10px', minHeight: '100px' }}>

                                            <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                                <table style={{ width: '100%' }}>
                                                    <tr style={{ backgroundColor: '#e6e8eb', color: 'black' }}>
                                                        <th style={{ padding: '15px' }}>
                                                            {/* <input type='checkbox' checked={selectedcameras.length === cameras.length ? true : false} onClick={(e) => {
                                                            let check = document.getElementsByClassName('check')

                                                            if (e.target.checked === true) {
                                                                for (let i = 0; i < check.length; i++) {
                                                                    check[i].checked = true
                                                                }
                                                                setselectedcameras(cameras)
                                                                dispatch({ type: SELECTED_CAMERAS, value: cameras })
                                                                dispatch({ type: APPLY, value: !apply })
                                                            } else {
                                                                for (let i = 0; i < check.length; i++) {
                                                                    check[i].checked = false
                                                                }
                                                                setselectedcameras([])
                                                                dispatch({ type: SELECTED_CAMERAS, value: [] })
                                                                dispatch({ type: APPLY, value: !apply })
                                                            }

                                                        }}></input> */}

                                                            <div>

                                                                <div style={{ backgroundColor: toggle == true ? '#42cf10' : '#a8a4a4', width: '3rem', height: '1.5rem', borderRadius: '15px', display: 'flex', justifyContent: toggle == true ? 'flex-end' : 'flex-start', alignItems: 'center', padding: '2px' }} onClick={() => {
                                                                    settoggle(!toggle)

                                                                    let check = document.getElementsByClassName('check')
                                                                    if (toggle === false) {
                                                                        console.log(check);
                                                                        // for (let i = 0; i < check.length; i++) {
                                                                        //     check[i].style.backgroundColor = '#42cf10'
                                                                        //     check[i].style.justifyContent = 'flex-end'
                                                                        // }
                                                                        setselectedcameras(cameras)
                                                                        dispatch({ type: SELECTED_CAMERAS, value: cameras })
                                                                        dispatch({ type: APPLY, value: !apply })
                                                                    } else {
                                                                        console.log(check);
                                                                        // for (let i = 0; i < check.length; i++) {
                                                                        //     check[i].style.backgroundColor = '#a8a4a4'
                                                                        //     check[i].style.justifyContent = 'flex-start'
                                                                        // }
                                                                        setselectedcameras([])
                                                                        dispatch({ type: SELECTED_CAMERAS, value: [] })
                                                                        dispatch({ type: APPLY, value: !apply })
                                                                    }
                                                                }}>
                                                                    <div style={{ backgroundColor: 'white', width: '1.3rem', height: '1.3rem', borderRadius: '50%' }}></div>
                                                                </div>
                                                            </div>

                                                        </th>
                                                        <th style={{ padding: '15px' }}>Cameras</th>
                                                        <th style={{ padding: '15px' }}>Cameras name</th>
                                                        <th style={{ padding: '15px' }}>Tags</th>
                                                        <th style={{ padding: '15px' }}>Cloud storage duration</th>
                                                    </tr>
                                                    {
                                                        camera_list
                                                    }
                                                </table>

                                            </Col>

                                        </Row>
                                    </div>
                                </div>
                            </Col>
                        </Row>
                    </div>
                </Modal >
            </div >


            <div>
                <Modal
                    open={open}
                    onClose={handleClose}
                    aria-labelledby="modal-modal-title"
                    aria-describedby="modal-modal-description"
                    style={{ marginLeft: 'auto', marginRight: 'auto', height: 550, width: '100%', top: 20, }}
                >
                    <Row>
                        <Col xl={6} lg={6} md={6} sm={12} xs={12} style={style}>
                            <div className='lower_alerts' style={{ backgroundColor: 'white', borderRadius: '5px', height: 550, maxHeight: 550, overflowY: 'scroll', overflowX: 'hidden' }}>
                                <div style={{ backgroundColor: '#181828', padding: '20px', display: 'flex', justifyContent: 'space-between' }}>
                                    <p style={{ color: 'white', fontSize: '20px', margin: 0 }}>{`${smallVideo.time} ${date}`}</p>
                                    <CloseIcon style={{ color: 'white' }} onClick={() => handleClose()} />
                                </div>

                                <div style={{ backgroundColor: "black", alignItems: 'center' }}>
                                    <img crossorigin="anonymous" style={{ display: iv === false ? 'none' : 'block' }} width="100%" height="100%" src={image_uri}></img>
                                    <div style={{ display: iv === false ? 'block' : 'none', }}>
                                        {/* smallVideo.video_url */}
                                        <video id={'vid1'} width="100%" height="100%" style={{ display: 'block' }} controls={true} autoPlay={true} src={video_uri} ></video>
                                        {/* <CircularProgress variant="determinate" value={progress} /> */}
                                    </div>
                                </div>

                                <div >

                                    <div>
                                        <Row style={{ padding: '10px', alignItems: 'center' }}>

                                            <Col xl={8} lg={8} md={1} sm={12} xs={12}>
                                                <div style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                                                    <VideocamIcon style={{ color: 'gray', fontSize: '40px' }} />
                                                    <p style={{ color: 'black', margin: 0, marginLeft: '5px', fontSize: '18px', marginRight: '20px' }}>{smallVideo.camera_name}</p>
                                                    <DirectionsRunIcon style={{ color: 'gray', fontSize: '40px' }} />
                                                    <p style={{ color: 'black', margin: 0, marginLeft: '5px', fontSize: '18px' }}>{smallVideo != '' && smallVideo.objects != '' ? Math.round(smallVideo.objects.person * 100) : ''}</p>
                                                </div>
                                            </Col>

                                            <Col xl={1} lg={1} md={1} sm={3} xs={3}>
                                                <div style={{ position: 'relative', width: '100%' }}>
                                                    <div id='view' style={{ backgroundColor: 'black', position: 'absolute', top: -50, width: 200, padding: '10px', borderRadius: '15px', display: 'none' }}>
                                                        <div style={{ position: 'relative' }}>
                                                            <p style={{ color: 'white', fontWeight: 'bolder', margin: 0 }}>View high resulation still</p>
                                                            <ArrowDropDownOutlinedIcon style={{ color: 'black', position: 'absolute', fontSize: '40px', top: 13 }} />
                                                        </div>
                                                    </div>

                                                    <div style={{ display: iv === false ? 'none' : 'block', position: 'relative' }} onClick={() => {
                                                        setiv(!iv)
                                                    }}>
                                                        <p style={{ color: 'white', fontWeight: 'bolder', margin: 0 }}>Play event video</p>
                                                        <PlayCircleFilledOutlinedIcon style={{ color: 'black', position: 'absolute', fontSize: '40px', top: 13 }} />
                                                    </div>

                                                    <div style={{ display: iv === false ? 'block' : 'none' }}>
                                                        <img crossorigin="anonymous" src={smallVideo.uri} width={50} height={30} onMouseOver={() => {
                                                            let div = document.getElementById('view')
                                                            div.style.display = 'block'
                                                        }} onMouseOut={() => {
                                                            let div = document.getElementById('view')
                                                            div.style.display = 'none'
                                                        }} onClick={() => {
                                                            setiv(!iv)
                                                        }}></img>
                                                    </div>
                                                </div>
                                            </Col>

                                            <Col xl={1} lg={1} md={1} sm={3} xs={3}>
                                                <div style={{ position: 'relative' }}>
                                                    <div id='down' style={{ backgroundColor: 'black', position: 'absolute', top: -50, width: 80, padding: '10px', borderRadius: '15px', display: 'none' }}>
                                                        <div style={{ position: 'relative' }}>
                                                            <p style={{ color: 'white', fontWeight: 'bolder', margin: 0 }}>Dowload</p>
                                                            <ArrowDropDownOutlinedIcon style={{ color: 'black', position: 'absolute', fontSize: '40px', top: 13 }} />
                                                        </div>
                                                    </div>
                                                    <ArrowCircleDownIcon style={{ color: 'black', fontSize: '35px' }} onMouseOver={() => {
                                                        let div = document.getElementById('down')
                                                        div.style.display = 'block'
                                                    }} onMouseOut={() => {
                                                        let div = document.getElementById('down')
                                                        div.style.display = 'none'
                                                    }} onClick={() => {
                                                        const blob = new Blob([smallVideo.video_url], { type: 'video/mp4' })
                                                        const link = document.createElement('a')
                                                        link.href = URL.createObjectURL(blob)
                                                        link.download = smallVideo.video_url
                                                        link.click()
                                                        URL.revokeObjectURL(link.href)
                                                    }} />
                                                </div>
                                            </Col>

                                            <Col xl={1} lg={1} md={1} sm={3} xs={3}>
                                                <div style={{ position: 'relative' }}>
                                                    <div id='del' style={{ backgroundColor: 'black', position: 'absolute', top: -50, width: 70, padding: '10px', borderRadius: '15px', display: 'none' }}>
                                                        <div style={{ position: 'relative' }}>
                                                            <p style={{ color: 'white', fontWeight: 'bolder', margin: 0 }}>Delete</p>
                                                            <ArrowDropDownOutlinedIcon style={{ color: 'black', position: 'absolute', fontSize: '40px', top: 13 }} />
                                                        </div>
                                                    </div>
                                                    <DeleteOutlineOutlinedIcon style={{ color: 'black', fontSize: '35px', }} onMouseOver={() => {
                                                        let div = document.getElementById('del')
                                                        div.style.display = 'block'
                                                    }} onMouseOut={() => {
                                                        let div = document.getElementById('del')
                                                        div.style.display = 'none'
                                                    }} />
                                                </div>
                                            </Col>

                                            <Col xl={1} lg={1} md={1} sm={3} xs={3}>
                                                <div style={{ position: 'relative' }}>
                                                    <div id='rep' style={{ backgroundColor: 'black', position: 'absolute', top: -50, width: 370, padding: '10px', borderRadius: '15px', display: 'none' }}>
                                                        <div style={{ position: 'relative' }}>
                                                            <p style={{ color: 'white', fontWeight: 'bolder', margin: 0 }}>View this time frame across multiple cameras</p>
                                                            <ArrowDropDownOutlinedIcon style={{ color: 'black', position: 'absolute', fontSize: '40px', top: 13 }} />
                                                        </div>
                                                    </div>
                                                    <ReplayOutlinedIcon style={{ color: 'black', fontSize: '35px' }} onMouseOver={() => {
                                                        let div = document.getElementById('rep')
                                                        div.style.display = 'block'
                                                    }} onMouseOut={() => {
                                                        let div = document.getElementById('rep')
                                                        div.style.display = 'none'
                                                    }} />
                                                </div>
                                            </Col>
                                        </Row>
                                    </div>
                                </div>

                                <div style={{ marginLeft: '30px', marginTop: '40px' }}>

                                    <Row>
                                        <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                            <p style={{ color: 'black', fontSize: '20px' }}>Analytics</p>
                                        </Col>

                                        {
                                            smallVideo != '' ?
                                                smallVideo.objects.length != 0 ?
                                                    // smallVideo.objects.map((val) => (
                                                    //     Object.keys(val).map((data, i) => (
                                                    //         <Col xl={2} lg={2} md={2} sm={6} xs={6}>
                                                    //             <div style={{ marginRight: '40px' }}>
                                                    //                 <p style={{ color: 'black', fontWeight: 'bolder', fontSize: '20px', marginBottom: '3px' }}>{data}</p>
                                                    //                 <p style={{ color: 'gray', fontSize: '18px', }}>{val.data}</p>
                                                    //             </div>
                                                    //         </Col>
                                                    //     ))
                                                    // ))

                                                    Object.keys(smallVideo.objects).map((data, i) => (
                                                        <div style={{ marginRight: '40px' }}>
                                                            <p style={{ color: 'black', fontWeight: 'bolder', fontSize: '20px', marginBottom: '3px' }}>{data}</p>
                                                            <p style={{ color: 'gray', fontSize: '18px', }}>{Math.round(smallVideo.objects[`${data}`] * 100)}%</p>
                                                        </div>
                                                    ))

                                                    :
                                                    <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                                        <div style={{ marginBottom: '20px' }}>
                                                            <p style={{ color: 'gray', fontWeight: 'bolder', fontSize: '20px', marginBottom: '3px' }}>No analytics found!</p>
                                                        </div>
                                                    </Col>

                                                : ''
                                        }

                                    </Row>
                                </div>
                            </div>
                        </Col>
                    </Row>
                </Modal>
            </div>

            <Col xl={12} lg={12} md={12} sm={12} xs={12} style={{ display: page === 1 ? 'block' : 'none' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <p style={{ color: 'black', fontWeight: 'bolder', fontSize: '20px' }}>Filters</p>
                    <CloseIcon style={{ color: 'black' }} onClick={() => {
                        dispatch({ type: PAGE, value: 0 })
                    }} />
                </div>
            </Col>



            <Col xl={12} lg={12} md={12} sm={12} xs={12} id='events' style={{ display: page === 1 || window.screen.width > 990 ? 'block' : 'none', backgroundColor: '#e6e8eb', position: 'sticky', top: 0, zIndex: 2 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <div style={{ display: select === false ? 'block' : 'none' }}>
                        <div id='eventsDiv' style={{ display: 'flex', marginLeft: page === 1 ? '0px' : '10px', marginTop: '20px', marginBottom: '20px' }}>

                            <div className='eventsDiv1' style={{ display: aditional_info === true ? 'block' : 'none' }}>
                                <div style={{ position: 'relative' }}>
                                    <button className='eventbtn' id='cameras' onClick={() => {
                                        setclickbtn3(true)
                                        handleOpen1()

                                    }} style={{ display: 'flex' }}> <AccessTimeIcon style={{ marginRight: '10px' }} />Cameras <div style={{ backgroundColor: '#e32747', padding: '3px', borderRadius: '50%', height: '25px', width: '25px', marginLeft: '10px' }}><p style={{ color: 'white' }}>{selectedcameras.length}</p></div> <ArrowDropDownIcon style={{ marginLeft: '0px' }} /></button>
                                </div>
                            </div>

                            <div className='eventsDiv1' style={{ position: 'relative' }}>
                                {/* <button className='eventbtn' id='day' onClick={() => {
                                    setclickbtn1(true)

                                }}> <AccessTimeIcon style={{ marginRight: '10px' }} />{`${startdate} (${starttime}) - ${enddate} (${endtime})`} <ArrowDropDownIcon style={{ marginLeft: '10px' }} /></button> */}

                                <button className='eventbtn' id='day' onClick={() => {
                                    setclickbtn1(true)

                                }}> <AccessTimeIcon style={{ marginRight: '10px' }} />{`${startdate} - ${enddate}`} <ArrowDropDownIcon style={{ marginLeft: '10px' }} /></button>

                                <div>
                                    <div style={{ width: page === 1 ? '350px' : '500px', borderRadius: '5px', backgroundColor: '#181828', padding: '10px', position: 'absolute', top: page === 1 ? '80px' : '60px', zIndex: 1, boxShadow: 'rgba(0, 0, 0, 0.35) 0px 5px 15px', display: btn1 === 'day' ? 'block' : 'none' }}>
                                        <div style={{ position: 'relative' }}>

                                            <ArrowDropUpIcon style={{ fontSize: '50px', color: '#181828', margin: 0, position: 'absolute', top: '-37px', left: 0 }} />
                                            <div style={{ display: 'flex', justifyContent: 'flex-end', flexDirection: 'column', alignItems: 'flex-end' }}>
                                                <div style={{ backgroundColor: '#e32747', borderRadius: '50%', padding: '2px', display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '10px' }}>
                                                    <CloseIcon style={{ fontSize: '12px', color: 'white' }} onClick={() => {
                                                        setclickbtn1(true)
                                                    }} />
                                                </div>
                                            </div>
                                            <div style={{ display: page === 1 ? 'none' : 'block' }}>
                                                <div style={{ display: 'flex', padding: '10px', flexDirection: 'column' }}>
                                                    <p style={{ margin: 0, color: 'white', fontWeight: 'bolder', marginBottom: '5px' }}>Start Date</p>
                                                    <div style={{ position: 'relative' }}>
                                                        <div style={{ backgroundColor: '#f4f7fa', borderRadius: '5px', padding: '10px', display: 'flex', justifyContent: 'space-between' }}>
                                                            <p style={{ fontWeight: 'bolder', margin: 0, color: '#181828' }}>{`${start_dateFullYear}-${start_dateMonth}-${start_dateDate}`}</p>
                                                            <CalendarMonthIcon style={{ cursor: 'pointer', color: '#181828' }} onClick={() => {
                                                                setviewstart_date(!viewstart_date)
                                                            }} />
                                                        </div>

                                                        <div style={{ position: 'absolute', zIndex: 2, top: '50px', display: viewstart_date === true ? 'block' : 'none' }}>
                                                            <DateComponent year={start_dateFullYear} month={Number(start_dateMonth)} date={Number(start_dateDate)} type={'start_date'} parentFunction={initialdate} />
                                                        </div>
                                                    </div>
                                                    {/* <input type="date" value={startdate} style={{ padding: '10px', borderRadius: '5px' }} onChange={(e) => {

                                                        dispatch({ type: STARTDATE, value: e.target.value })
                                                    }}></input>
                                                    <input type="time" value={starttime} style={{ padding: '10px', borderRadius: '5px' }} onChange={(e) => {

                                                        dispatch({ type: STARTTIME, value: e.target.value })
                                                    }}></input> */}
                                                </div>

                                                <div style={{ display: 'flex', padding: '10px', flexDirection: 'column' }}>
                                                    <p style={{ margin: 0, color: 'white', fontWeight: 'bolder', marginBottom: '5px' }}>End Date</p>
                                                    <div style={{ position: 'relative' }}>
                                                        <div style={{ backgroundColor: '#f4f7fa', borderRadius: '5px', padding: '10px', display: 'flex', justifyContent: 'space-between' }}>
                                                            <p style={{ fontWeight: 'bolder', margin: 0, color: '#181828' }}>{`${end_dateFullYear}-${end_dateMonth}-${end_dateDate}`}</p>
                                                            <CalendarMonthIcon style={{ cursor: 'pointer', color: '#181828' }} onClick={() => {
                                                                setviewend_date(!viewend_date)
                                                            }} />
                                                        </div>

                                                        <div style={{ position: 'absolute', zIndex: 2, top: '50px', display: viewend_date === true ? 'block' : 'none' }}>
                                                            <DateComponent year={end_dateFullYear} month={Number(end_dateMonth)} date={Number(end_dateDate)} type={'end_date'} parentFunction={initialdate} />
                                                        </div>
                                                    </div>
                                                    {/* <input type="date" value={enddate} style={{ padding: '10px', borderRadius: '5px' }} onChange={(e) => {
                                                        dispatch({ type: ENDDATE, value: e.target.value })
                                                    }}></input>
                                                    <input type="time" value={endtime} style={{ padding: '10px', borderRadius: '5px' }} onChange={(e) => {
                                                        dispatch({ type: ENDTIME, value: e.target.value })
                                                    }}></input> */}
                                                </div>

                                                <div style={{ display: 'flex', justifyContent: 'flex-end', paddingRight: '10px' }}>
                                                    <button className="my-2" style={{ backgroundColor: '#e32747', color: 'white', borderRadius: '5px', border: 'none', padding: '5px' }} onClick={() => {
                                                        setclickbtn1(true)
                                                        if (aditional_info) {
                                                            document.getElementById('day').innerText = `${startdate} (${starttime}) - ${enddate} (${endtime})`
                                                        } else {
                                                            document.getElementById('day').innerText = 'Select Date and Time'
                                                        }
                                                        dispatch({ type: APPLY, value: !apply })
                                                    }}>Apply</button>
                                                </div>
                                            </div>

                                            <div style={{ display: page === 1 ? 'block' : 'none', paddingRight: '10px' }}>

                                                <Row>
                                                    <Col xl={12} lg={12} md={12} sm={12} xs={12} style={{ display: 'flex', alignItems: 'center' }}>
                                                        <p style={{ margin: 0, color: 'white', fontWeight: 'bolder' }}>Start Date</p>
                                                    </Col>

                                                    <Col xl={12} lg={12} md={12} sm={12} xs={12} style={{ padding: '3px' }}>
                                                        <div style={{ position: 'relative' }}>
                                                            <div style={{ backgroundColor: '#f4f7fa', borderRadius: '5px', padding: '10px', display: 'flex', justifyContent: 'space-between' }}>
                                                                <p style={{ fontWeight: 'bolder', margin: 0, color: '#181828' }}>{`${start_dateFullYear}-${start_dateMonth}-${start_dateDate}`}</p>
                                                                <CalendarMonthIcon style={{ cursor: 'pointer', color: '#181828' }} onClick={() => {
                                                                    setviewstart_date(!viewstart_date)
                                                                }} />
                                                            </div>

                                                            <div style={{ position: 'absolute', zIndex: 2, top: '90px', display: viewstart_date === true ? 'block' : 'none' }}>
                                                                <DateComponent year={start_dateFullYear} month={Number(start_dateMonth)} date={Number(start_dateDate)} type={'start_date'} parentFunction={initialdate} />
                                                            </div>
                                                        </div>
                                                    </Col>
                                                </Row>

                                                {/* <Row>
                                                    <Col xl={12} lg={12} md={12} sm={5} xs={5} style={{ display: 'flex', alignItems: 'center' }}>
                                                        <p style={{ margin: 0, color: 'white', fontWeight: 'bolder' }}>Start Date</p>
                                                    </Col>

                                                    <Col xl={12} lg={12} md={12} sm={7} xs={7} style={{ padding: '3px' }}>
                                                        <input type="date" value={startdate} style={{ padding: '5px', borderRadius: '5px', width: '100%' }} onChange={(e) => {
                                                            dispatch({ type: STARTDATE, value: e.target.value })
                                                        }}></input>
                                                    </Col>
                                                </Row> */}

                                                {/* <Row>
                                                    <Col xl={12} lg={12} md={12} sm={5} xs={5} style={{ display: 'flex', alignItems: 'center' }}>
                                                        <p style={{ margin: 0, color: 'white', fontWeight: 'bolder' }}>Start Time</p>
                                                    </Col>

                                                    <Col xl={12} lg={12} md={12} sm={7} xs={7} style={{ padding: '3px' }}>
                                                        <input type="time" value={starttime} style={{ padding: '5px', borderRadius: '5px', width: '100%' }} onChange={(e) => {
                                                            dispatch({ type: STARTTIME, value: e.target.value })
                                                        }}></input>
                                                    </Col>
                                                </Row> */}

                                                <Row>
                                                    <Col xl={12} lg={12} md={12} sm={12} xs={12} style={{ display: 'flex', alignItems: 'center' }}>
                                                        <p style={{ fontWeight: 'bolder', fontSize: '16px' }}>END DATE</p>
                                                    </Col>

                                                    <Col xl={12} lg={12} md={12} sm={12} xs={12} style={{ padding: '3px' }}>
                                                        <div style={{ position: 'relative' }}>
                                                            <div style={{ backgroundColor: '#f4f7fa', borderRadius: '5px', padding: '10px', display: 'flex', justifyContent: 'space-between' }}>
                                                                <p style={{ fontWeight: 'bolder', margin: 0, color: '#181828' }}>{`${end_dateFullYear}-${end_dateMonth}-${end_dateDate}`}</p>
                                                                <CalendarMonthIcon style={{ cursor: 'pointer', color: '#181828' }} onClick={() => {
                                                                    setviewend_date(!viewend_date)
                                                                }} />
                                                            </div>

                                                            <div style={{ position: 'absolute', zIndex: 2, top: '90px', display: viewend_date === true ? 'block' : 'none' }}>
                                                                <DateComponent year={end_dateFullYear} month={Number(end_dateMonth)} date={Number(end_dateDate)} type={'end_date'} parentFunction={initialdate} />
                                                            </div>
                                                        </div>
                                                    </Col>
                                                </Row>

                                                {/* <Row>
                                                    <Col xl={12} lg={12} md={12} sm={5} xs={5} style={{ display: 'flex', alignItems: 'center' }}>
                                                        <p style={{ margin: 0, color: 'white', fontWeight: 'bolder' }}>End Date</p>
                                                    </Col>

                                                    <Col xl={12} lg={12} md={12} sm={7} xs={7} style={{ padding: '3px' }}>
                                                        <input type="date" value={enddate} style={{ padding: '5px', borderRadius: '5px', width: '100%' }} onChange={(e) => {
                                                            dispatch({ type: ENDDATE, value: e.target.value })
                                                        }}></input>
                                                    </Col>
                                                </Row> */}

                                                {/* <Row>
                                                    <Col xl={12} lg={12} md={12} sm={5} xs={5} style={{ display: 'flex', alignItems: 'center' }}>
                                                        <p style={{ margin: 0, color: 'white', fontWeight: 'bolder' }}>End Time</p>
                                                    </Col>

                                                    <Col xl={12} lg={12} md={12} sm={7} xs={7} style={{ padding: '3px' }}>
                                                        <input type="time" value={endtime} style={{ padding: '5px', borderRadius: '5px', width: '100%' }} onChange={(e) => {
                                                            dispatch({ type: ENDTIME, value: e.target.value })
                                                        }}></input>
                                                    </Col>
                                                </Row> */}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className='eventsDiv1' style={{ position: 'relative' }}>
                                <button className='eventbtn' id='analytics' onClick={() => {
                                    setclickbtn2(true)
                                }} style={{ display: 'flex' }}> <TroubleshootIcon style={{ marginRight: '10px' }} />Analytics <div style={{ backgroundColor: '#e32747', padding: '3px', borderRadius: '50%', height: '25px', width: '25px', marginLeft: '10px' }}><p style={{ color: 'white' }}>{selectedanalytics.length}</p></div><ArrowDropDownIcon style={{ marginLeft: '10px' }} /></button>

                                <div>
                                    <div style={{ borderRadius: '5px', backgroundColor: '#181828', padding: '10px', position: 'absolute', top: '60px', zIndex: 1, boxShadow: 'rgba(0, 0, 0, 0.35) 0px 5px 15px', display: btn1 === 'analytics' ? 'block' : 'none' }}>
                                        <div style={{ position: 'relative' }}>

                                            <ArrowDropUpIcon style={{ fontSize: '50px', color: '#181828', margin: 0, position: 'absolute', top: '-37px' }} />
                                            <div style={{ display: 'flex', justifyContent: 'flex-end', flexDirection: 'column', alignItems: 'flex-end' }}>
                                                <div style={{ backgroundColor: '#e32747', borderRadius: '50%', padding: '2px', display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '10px' }}>
                                                    <CloseIcon style={{ fontSize: '12px', color: 'white' }} onClick={() => {
                                                        setclickbtn2(true)
                                                    }} />
                                                </div>
                                                <p style={{ margin: 0, color: 'white', cursor: 'pointer' }} onClick={() => {
                                                    let check = document.getElementsByClassName('analyticCheckbox')
                                                    for (let i = 0; i < check.length; i++) {
                                                        check[i].checked = false
                                                    }
                                                    setselectedanalytics([])
                                                    setfinaldata([])
                                                    setfinaldate('')
                                                    setcolflag(true)
                                                    setcolcount(40)
                                                    setclickbtn2(true)
                                                }}>Clear all</p>
                                            </div>

                                            {
                                                analytics_obj.map((val) => (
                                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px' }}>
                                                        <p style={{ margin: 0, color: 'white', width: '200px' }}>{val.charAt(0).toUpperCase() + val.slice(1)}<span style={{ color: 'white', borderRadius: '50%', backgroundColor: '#a8a4a4', marginLeft: '10px', paddingLeft: '8px', paddingRight: '8px', paddingTop: '3px', paddingBottom: '3px' }}>{analytics_num[val]}</span></p>
                                                        <input className='analyticCheckbox' type="checkbox" onClick={(e) => {
                                                            if (e.target.checked === true) {
                                                                // let arr = []
                                                                // data.map((val) => {
                                                                //     if (val.objects.length !== 0 && val.objects.person !== undefined) {
                                                                //         arr.push(val)
                                                                //     }
                                                                // })
                                                                // setdata2(arr)
                                                                // console.log(arr);
                                                                setselectedanalytics([...selectedanalytics, val])
                                                                setfinaldata([])
                                                                setfinaldate('')
                                                                setcolflag(true)
                                                                setcolcount(40)
                                                                setclickbtn2(true)
                                                                // console.log([...selectedanalytics, val]);
                                                            } else {
                                                                let arr = []
                                                                for (let i = 0; i < selectedanalytics.length; i++) {
                                                                    if (selectedanalytics[i] !== val) {
                                                                        arr.push(selectedanalytics[i])
                                                                    }
                                                                }
                                                                setselectedanalytics(arr)
                                                                setfinaldata([])
                                                                setfinaldate('')
                                                                setcolflag(true)
                                                                setcolcount(40)
                                                                setclickbtn2(true)
                                                            }
                                                        }}></input>
                                                    </div>
                                                ))
                                            }
                                            {/* <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px' }}>
                                                <p style={{ margin: 0, color: 'white', width: '200px' }}>Person</p>
                                                <input className='analyticCheckbox' type="checkbox" onClick={(e) => {
                                                    if (e.target.checked === true) {
                                                        // let arr = []
                                                        // data.map((val) => {
                                                        //     if (val.objects.length !== 0 && val.objects.person !== undefined) {
                                                        //         arr.push(val)
                                                        //     }
                                                        // })
                                                        // setdata2(arr)
                                                        // console.log(arr);
                                                        setselectedanalytics([...selectedanalytics, 'person'])
                                                        setfinaldata([])
                                                        setfinaldate('')
                                                        setcolflag(true)
                                                        setcolcount(40)
                                                        setclickbtn2(true)
                                                        console.log([...selectedanalytics, 'person']);
                                                    } else {
                                                        let arr = []
                                                        for (let i = 0; i < selectedanalytics.length; i++) {
                                                            if (selectedanalytics[i] !== 'person') {
                                                                arr.push(selectedanalytics[i])
                                                            }
                                                        }
                                                        setselectedanalytics(arr)
                                                        setfinaldata([])
                                                        setfinaldate('')
                                                        setcolflag(true)
                                                        setcolcount(40)
                                                        setclickbtn2(true)
                                                    }
                                                }}></input>
                                            </div>

                                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px' }}>
                                                <p style={{ margin: 0, color: 'white', width: '200px' }}>Car</p>
                                                <input className='analyticCheckbox' type="checkbox" onClick={(e) => {
                                                    if (e.target.checked === true) {
                                                        // let arr = []
                                                        // data.map((val) => {
                                                        //     if (val.objects.length !== 0 && val.objects.person !== undefined) {
                                                        //         arr.push(val)
                                                        //     }
                                                        // })
                                                        // setdata2(arr)
                                                        // console.log(arr);
                                                        setselectedanalytics([...selectedanalytics, 'car'])
                                                        setfinaldata([])
                                                        setfinaldate('')
                                                        setcolflag(true)
                                                        setcolcount(40)
                                                        setclickbtn2(true)
                                                        console.log([...selectedanalytics, 'car']);
                                                    } else {
                                                        let arr = []
                                                        for (let i = 0; i < selectedanalytics.length; i++) {
                                                            if (selectedanalytics[i] !== 'car') {
                                                                arr.push(selectedanalytics[i])
                                                            }
                                                        }
                                                        setselectedanalytics(arr)
                                                        setfinaldata([])
                                                        setfinaldate('')
                                                        setcolflag(true)
                                                        setcolcount(40)
                                                        setclickbtn2(true)
                                                    }
                                                }}></input>
                                            </div>

                                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px' }}>
                                                <p style={{ margin: 0, color: 'white', width: '200px' }}>Cat</p>
                                                <input className='analyticCheckbox' type="checkbox" onClick={(e) => {
                                                    if (e.target.checked === true) {
                                                        // let arr = []
                                                        // data.map((val) => {
                                                        //     if (val.objects.length !== 0 && val.objects.person !== undefined) {
                                                        //         arr.push(val)
                                                        //     }
                                                        // })
                                                        // setdata2(arr)
                                                        // console.log(arr);
                                                        setselectedanalytics([...selectedanalytics, 'cat'])
                                                        setfinaldata([])
                                                        setfinaldate('')
                                                        setcolflag(true)
                                                        setcolcount(40)
                                                        setclickbtn2(true)
                                                        console.log([...selectedanalytics, 'cat']);
                                                    } else {
                                                        let arr = []
                                                        for (let i = 0; i < selectedanalytics.length; i++) {
                                                            if (selectedanalytics[i] !== 'cat') {
                                                                arr.push(selectedanalytics[i])
                                                            }
                                                        }
                                                        setselectedanalytics(arr)
                                                        setfinaldata([])
                                                        setfinaldate('')
                                                        setcolflag(true)
                                                        setcolcount(40)
                                                        setclickbtn2(true)
                                                    }
                                                }}></input>
                                            </div>

                                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px' }}>
                                                <p style={{ margin: 0, color: 'white', width: '200px' }}>dog</p>
                                                <input className='analyticCheckbox' type="checkbox" onClick={(e) => {
                                                    if (e.target.checked === true) {
                                                        // let arr = []
                                                        // data.map((val) => {
                                                        //     if (val.objects.length !== 0 && val.objects.person !== undefined) {
                                                        //         arr.push(val)
                                                        //     }
                                                        // })
                                                        // setdata2(arr)
                                                        // console.log(arr);
                                                        setselectedanalytics([...selectedanalytics, 'dog'])
                                                        setfinaldata([])
                                                        setfinaldate('')
                                                        setcolflag(true)
                                                        setcolcount(40)
                                                        setclickbtn2(true)
                                                        console.log([...selectedanalytics, 'dog']);
                                                    } else {
                                                        let arr = []
                                                        for (let i = 0; i < selectedanalytics.length; i++) {
                                                            if (selectedanalytics[i] !== 'dog') {
                                                                arr.push(selectedanalytics[i])
                                                            }
                                                        }
                                                        setselectedanalytics(arr)
                                                        setfinaldata([])
                                                        setfinaldate('')
                                                        setcolflag(true)
                                                        setcolcount(40)
                                                        setclickbtn2(true)
                                                    }
                                                }}></input>
                                            </div> */}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <Col xl={12} lg={12} md={12} sm={12} xs={12} style={{ display: page === 1 ? 'block' : 'none' }}>
                            <hr style={{ borderTop: '1px solid gray' }}></hr>

                            <div style={{ display: 'flex', justifyContent: 'center' }}>
                                <button style={{ backgroundColor: '#181828', color: 'white', padding: '10px', borderRadius: '15px', border: 'none' }} onClick={() => {
                                    dispatch({ type: PAGE, value: 0 })
                                    dispatch({ type: APPLY, value: !apply })
                                }}>Apply</button>
                            </div>
                        </Col>
                    </div>

                    <div className='eventsDiv3' style={{ display: 'flex', justifyContent: 'space-between', width: select ? '100%' : '' }}>
                        <div style={{ display: select === false ? 'none' : 'block', marginTop: '20px', marginBottom: '20px', paddingLeft: '10px', color: 'black' }}>
                            {bulk_download_delete()}
                        </div>

                        <div style={{ marginTop: '20px', paddingRight: '10px', marginBottom: '20px' }}>
                            <button id='analytics' style={{ backgroundColor: '#e6e8eb', color: 'black', padding: '10px', borderRadius: '20px', border: '1px solid gray' }} onClick={() => {
                                dispatch({ type: SELECT, value: !select })
                                setfinaldata([])
                                setfinaldate('')
                                setcolflag(true)
                                setcolcount(40)
                            }}>{select === false ? <span><PlaylistAddCheckOutlinedIcon style={{ marginRight: '10px' }} />Select</span> : <span style={{ display: 'flex' }}>Done<div style={{ backgroundColor: '#e32747', padding: '3px', borderRadius: '50%', height: '25px', width: '25px', marginLeft: '3px' }}><p style={{ color: 'white' }}>{selected_video.length}</p></div></span>}</button>

                        </div>
                    </div>
                </div>
            </Col>

            <Col xl={12} lg={12} md={12} sm={12} xs={12} id='filter' style={{ display: page === 1 || window.screen.width > 990 ? 'none' : 'block', backgroundColor: '#e6e8eb', marginTop: '20px', marginBottom: '20px', position: 'sticky', top: 0, zIndex: 2 }}>
                <div style={{ padding: '10px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <div style={{ display: select === false ? 'block' : 'none' }}>
                            <button style={{ backgroundColor: '#e6e8eb', color: 'black', padding: '10px', borderRadius: '20px', border: '1px solid gray', marginRight: '20px' }} onClick={() => {
                                dispatch({ type: PAGE, value: 1 })
                            }}> <TuneOutlinedIcon style={{ marginRight: '10px' }} />Filter</button>
                        </div>

                        <div style={{ display: select === false ? 'none' : 'block', color: 'black' }}>
                            {bulk_download_delete()}
                        </div>

                        <button style={{ backgroundColor: '#e6e8eb', color: 'black', padding: '10px', borderRadius: '20px', border: '1px solid gray' }} onClick={() => {
                            dispatch({ type: SELECT, value: !select })
                            setfinaldata([])
                            setfinaldate('')
                            setcolflag(true)
                            setcolcount(40)
                        }}>{select === false ? <span><PlaylistAddCheckOutlinedIcon style={{ marginRight: '10px' }} />Select</span> : <span style={{ display: 'flex' }}>Done<div style={{ backgroundColor: '#e32747', padding: '3px', borderRadius: '50%', height: '25px', width: '25px', marginLeft: '3px' }}><p style={{ color: 'white' }}>{selected_video.length}</p></div></span>}</button>
                    </div>
                </div>
            </Col>

            <Row id='main'>
                {
                    page === 1 ?
                        ''
                        :
                        data != '' ?
                            finaldata.map((component) => {
                                return (
                                    component
                                )
                            })
                            :
                            <Col xl={12} lg={12} md={12} sm={12} xs={12} style={{ backgroundColor: '#e6e8eb' }}>
                                {
                                    res === 'empty response' || newres === true ?
                                        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', padding: '10px', borderTop: '1px solid grey' }}>
                                            <CloudOffRoundedIcon size={'50px'} style={{ color: '#e32747' }} />
                                            <h5 style={{ color: '#e32747', fontWeight: 'bold', margin: 0 }}>No videos found!</h5>
                                        </div>
                                        :
                                        <div style={{ width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
                                            <CircularProgress size={'30px'} style={{ color: 'blue' }} />
                                            <p>Please Wait...</p>
                                        </div>
                                }
                            </Col>


                }

            </Row>



        </>
    )
}
