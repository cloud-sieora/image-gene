import React, { useEffect, useState } from 'react'
import EventMenu from '../EventMenu'
import {
  Row,
  Col,
  Card,
  Table,
  Tabs,
  Tab,
  Container,
  Button,
} from "react-bootstrap";
import Events from '../Events'
import { useDispatch, useSelector } from 'react-redux';
import * as api from '../../Configurations/Api_Details'

export default function Index() {
  const { page, startdate, starttime, enddate, endtime, apply, select, selected_cameras } = useSelector((state) => state)
  const [cameraName, setcameraName] = useState('')
  const [res, setres] = useState('')
  const [data, setdata] = useState([])

  useEffect(() => {
    getdata()
    setres('')
    let pathName = window.location.pathname;
    let arr = pathName.split('/')
    setcameraName(arr[arr.length - 1])
  }, [apply])

  function getdata() {
    setdata([])
    let data1 = []
    let count = 0
    const axios = require('axios');

    if (selected_cameras.length !== 0) {
      for (let i = 0; i < selected_cameras.length; i++) {
        let data = JSON.stringify({
          "camera_id": selected_cameras[i]._id,
          "camera_name": selected_cameras[i].camera_gereral_name,
          // startdate
          "start_date": startdate,
          // enddate
          "end_date": enddate,
        });

        let config = {
          method: 'post',
          maxBodyLength: Infinity,
          url: api.ANALYTICS_LIST,
          headers: {
            'Content-Type': 'application/json'
          },
          data: data
        }

        axios.request(config)
          .then((response) => {
            console.log(response.data.data);
            count = count + 1
            data1 = [...data1, ...response.data.data]
            if (selected_cameras.length === count) {
              finalFun()
            }
            // setdata(response.data.data)
            // if (response.data.data.length === 0) {
            //   setres('empty response')
            // } else {
            //   setres('')
            // }
          })
          .catch((error) => {
            console.log(error);
          })
      };
    } else {
      setres('empty response')
    }

    const finalFun = () => {
      if (data1.length === 0) {
        setres('empty response')
      } else {
        setres('')
      }
      setdata(data1)
    }
  }
  return (
    <div id='main'>
      <Row style={{ padding: '10px' }}>
        <Events data1={data} res={res} aditional_info={true} />
      </Row>
    </div>
  )
}
