
import React, { useEffect, useRef, useState } from 'react';
import {
    Row,
    Col,
    Card,
    Table,
    Tabs,
    Tab,
    Container,
    Button,
} from "react-bootstrap";
import Grid from '@mui/material/Grid';
import Modal from '@mui/material/Modal';
import CloseIcon from '@mui/icons-material/Close';
import TuneOutlinedIcon from '@mui/icons-material/TuneOutlined';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import CircularProgress from '@mui/material/CircularProgress';
import * as api from '../../Configurations/Api_Details'
import Mask from './Mask';

const DrawRectangle = () => {


    const userData = JSON.parse(localStorage.getItem("userData"))
    const [cameras, setcameras] = useState([]);
    const [selectedcameras, setselectedcameras] = useState([]);
    const [toggle, settoggle] = useState(false)
    const [image, setimage] = useState([])
    const [image_edited, setimage_edited] = useState([])
    const [open1, setOpen1] = React.useState(false);
    const [cut_off, setcut_off] = React.useState(false);

    useEffect(() => {
        // dispatch({ type: SELECTED_CAMERAS, value: [] })
        const axios = require('axios');
        let data = JSON.stringify({
            "user_id": userData._id
        });

        let config = {
            method: 'post',
            maxBodyLength: Infinity,
            url: api.LIST_CAMERA_USER_ID,
            headers: {
                'Content-Type': 'application/json'
            },
            data: data
        };

        axios.request(config)
            .then((response) => {
                // console.log(JSON.stringify(response.data));
                setcameras(response.data)
                // setselectedcameras(response.data)
                // setcut_off(true)
                // dispatch({ type: SELECTED_CAMERAS, value: response.data })
                // dispatch({ type: APPLY, value: !apply })


            })
            .catch((error) => {
                console.log(error);
            })
    }, [])

    if (cut_off) {
        let count = 0
        let count1 = 0
        let value = []
        let value1 = []
        selectedcameras.map((val) => {
            const axios = require('axios');
            let data = JSON.stringify({
                "camera_name": val.camera_gereral_name
            });

            let config1 = {
                method: 'post',
                maxBodyLength: Infinity,
                // url: `${device.empty}/uri_edit`,
                url: `edit/uri_edit`,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: data
            };

            axios.request(config1)
                .then((response) => {
                    // console.log(JSON.stringify(response.data.data));
                    value.push({ ...val, edited_image: response.data.data, mask: response.data.mask })
                    count = count + 1
                    if (count === selectedcameras.length) {
                        setselectedcameras(value)
                        setimage_edited(value)
                    }
                    // setimage_edited(response.data)
                    // dispatch({ type: SELECTED_CAMERAS, value: response.data })
                    // dispatch({ type: APPLY, value: !apply })


                })
                .catch((error) => {
                    console.log(error);
                    count = count + 1
                    value.push({ ...val, edited_image: 'none' })
                    if (count === selectedcameras.length) {
                        setselectedcameras(value)
                        setimage_edited(value)
                    }
                })
        })
        setcut_off(false)
    }

    const handleOpen1 = () => setOpen1(true);
    const handleClose1 = () => setOpen1(false);

    const style = {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        boxShadow: 24,
    };

    let camera_list = cameras.map((val, i) => {

        let chk = ""
        for (let i = 0; i < selectedcameras.length; i++) {
            if (selectedcameras[i]._id === val._id) {
                chk = true
                break
            } else {
                chk = false
            }
        }

        return (
            <tr style={{ borderBottom: '1px solid grey', color: 'black' }}>
                <th style={{ padding: '15px' }}>
                    {/* <input className='check' checked={chk} type='checkbox' onClick={(e) => {
                    if (e.target.checked === true) {
                        setselectedcameras((old) => {
                            dispatch({ type: SELECTED_CAMERAS, value: [...old, val] })
                            dispatch({ type: APPLY, value: !apply })
                            return [...old, val]
                        })
                    } else {
                        let arr = []
                        selectedcameras.map((data) => {
                            if (val._id !== data._id) {
                                arr.push(data)
                            }
                        })
                        setselectedcameras(arr)
                        dispatch({ type: SELECTED_CAMERAS, value: arr })
                        dispatch({ type: APPLY, value: !apply })
                    }

                }}></input> */}

                    <div>

                        <div id={`chk${i}`} className='check' title={`${chk}`} style={{ backgroundColor: chk == true ? '#42cf10' : '#a8a4a4', width: '3rem', height: '1.5rem', borderRadius: '15px', display: 'flex', justifyContent: chk == true ? 'flex-end' : 'flex-start', alignItems: 'center', padding: '2px' }} onClick={() => {
                            // settoggle(!toggle)

                            let ele = document.getElementById(`chk${i}`)

                            let toggle = ele.getAttribute("title") === 'true' ? false : true
                            let arr = []

                            if (toggle === true) {
                                arr = [...selectedcameras, val]
                                setselectedcameras((old) => {
                                    // dispatch({ type: SELECTED_CAMERAS, value: [...old, val] })
                                    // dispatch({ type: APPLY, value: !apply })
                                    return [...old, val]
                                })
                            } else {

                                selectedcameras.map((data) => {
                                    if (val._id !== data._id) {
                                        arr.push(data)
                                    }
                                })
                                setselectedcameras(arr)
                                // dispatch({ type: SELECTED_CAMERAS, value: arr })
                                // dispatch({ type: APPLY, value: !apply })
                            }

                            if (arr.length === cameras.length) {
                                settoggle(true)
                            } else {
                                settoggle(false)
                            }

                            setcut_off(true)
                        }}>
                            <div style={{ backgroundColor: 'white', width: '1.3rem', height: '1.3rem', borderRadius: '50%' }}></div>
                        </div>
                    </div>
                </th>
                <td style={{ padding: '15px' }}><img width={150} height={100} src={`https://sgp1.digitaloceanspaces.com/tentovision/${val.device_id}/${val.camera_gereral_name}.jpg?${new Date()}`}></img></td>
                <td style={{ padding: '15px' }}>{val.camera_gereral_name}</td>
                <td style={{ padding: '15px' }}>{val.camera_gereral_name}</td>
                <td style={{ padding: '15px' }}>360 days</td>
            </tr>
        )
    })

    console.log(image_edited);
    console.log(selectedcameras);


    return (

        <Grid item md={12} sx={12} xs={12} style={{ marginTop: '10px' }}>
            <div>
                <Modal
                    open={open1}
                    onClose={handleClose1}
                    aria-labelledby="modal-modal-title"
                    aria-describedby="modal-modal-description"
                    style={{ overflowY: 'scroll' }}
                >
                    <Row>
                        <Col xl={10} lg={10} md={10} sm={12} xs={12} style={style}>
                            <div >

                                <div style={{ backgroundColor: 'white', borderRadius: '5px', paddingTop: '10px' }}>
                                    <Row style={{ padding: '10px', alignItems: 'center' }}>

                                        <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end' }}>
                                                <CloseIcon style={{ color: 'black' }} onClick={() => handleClose1()} />
                                            </div>
                                        </Col>

                                    </Row>
                                    <Row style={{ padding: '10px', alignItems: 'center' }}>

                                        <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                                                <div>
                                                    <input type='text' placeholder='Search' style={{ backgroundColor: '#e6e8eb', color: 'black', padding: '10px', borderRadius: '20px', border: '1px solid gray', marginRight: '20px' }}></input>

                                                    <button style={{ backgroundColor: '#e6e8eb', color: 'black', padding: '10px', borderRadius: '20px', border: '1px solid gray', }} onClick={() => {
                                                    }}> <TuneOutlinedIcon style={{ marginRight: '10px' }} />Filter</button>
                                                </div>

                                                <div>
                                                    <p style={{ color: 'black', fontSize: '20px', margin: 0 }}><span style={{ color: 'white', backgroundColor: '#1b0182', borderRadius: '50%', paddingLeft: '10px', paddingRight: '10px', paddingTop: '3px', paddingBottom: '3px' }}>{selectedcameras.length}</span> / {cameras.length} Cameras Selected</p>
                                                </div>
                                            </div>
                                        </Col>

                                    </Row>

                                    <Row style={{ padding: '10px', alignItems: 'center', }}>

                                        <Col xl={12} lg={12} md={12} sm={12} xs={12} style={{ overflow: 'scroll' }}>
                                            <table style={{ width: '100%' }}>
                                                <tr style={{ backgroundColor: '#e6e8eb', color: 'black' }}>
                                                    <th style={{ padding: '15px' }}>
                                                        {/* <input type='checkbox' checked={selectedcameras.length === cameras.length ? true : false} onClick={(e) => {
                                                            let check = document.getElementsByClassName('check')

                                                            if (e.target.checked === true) {
                                                                for (let i = 0; i < check.length; i++) {
                                                                    check[i].checked = true
                                                                }
                                                                setselectedcameras(cameras)
                                                                dispatch({ type: SELECTED_CAMERAS, value: cameras })
                                                                dispatch({ type: APPLY, value: !apply })
                                                            } else {
                                                                for (let i = 0; i < check.length; i++) {
                                                                    check[i].checked = false
                                                                }
                                                                setselectedcameras([])
                                                                dispatch({ type: SELECTED_CAMERAS, value: [] })
                                                                dispatch({ type: APPLY, value: !apply })
                                                            }

                                                        }}></input> */}

                                                        <div>

                                                            <div style={{ backgroundColor: toggle == true ? '#42cf10' : '#a8a4a4', width: '3rem', height: '1.5rem', borderRadius: '15px', display: 'flex', justifyContent: toggle == true ? 'flex-end' : 'flex-start', alignItems: 'center', padding: '2px' }} onClick={() => {
                                                                settoggle(!toggle)

                                                                let check = document.getElementsByClassName('check')
                                                                if (toggle === false) {
                                                                    console.log(check);
                                                                    // for (let i = 0; i < check.length; i++) {
                                                                    //     check[i].style.backgroundColor = '#42cf10'
                                                                    //     check[i].style.justifyContent = 'flex-end'
                                                                    // }
                                                                    setselectedcameras(cameras)
                                                                    // dispatch({ type: SELECTED_CAMERAS, value: cameras })
                                                                    // dispatch({ type: APPLY, value: !apply })
                                                                } else {
                                                                    console.log(check);
                                                                    // for (let i = 0; i < check.length; i++) {
                                                                    //     check[i].style.backgroundColor = '#a8a4a4'
                                                                    //     check[i].style.justifyContent = 'flex-start'
                                                                    // }
                                                                    setselectedcameras([])
                                                                    // dispatch({ type: SELECTED_CAMERAS, value: [] })
                                                                    // dispatch({ type: APPLY, value: !apply })
                                                                }
                                                                setcut_off(true)
                                                            }}>
                                                                <div style={{ backgroundColor: 'white', width: '1.3rem', height: '1.3rem', borderRadius: '50%' }}></div>
                                                            </div>
                                                        </div>

                                                    </th>
                                                    <th style={{ padding: '15px' }}>Cameras</th>
                                                    <th style={{ padding: '15px' }}>Cameras name</th>
                                                    <th style={{ padding: '15px' }}>Tags</th>
                                                    <th style={{ padding: '15px' }}>Cloud storage duration</th>
                                                </tr>
                                                {
                                                    camera_list
                                                }
                                            </table>

                                        </Col>

                                    </Row>
                                </div>
                            </div>
                        </Col>
                    </Row>
                </Modal>
            </div>

            <div className='eventsDiv1' style={{ marginBottom: '20px' }}>
                <div style={{ position: 'relative' }}>
                    <button className='eventbtn' id='cameras' onClick={() => {
                        handleOpen1()

                    }} style={{ display: 'flex', borderRadius: '20px', padding: '10px', border: '1px solid grey', }}> <AccessTimeIcon style={{ marginRight: '10px' }} />Cameras <div style={{ backgroundColor: '#e32747', padding: '3px', borderRadius: '50%', height: '25px', width: '25px', marginLeft: '10px' }}><p style={{ color: 'white' }}>{selectedcameras.length}</p></div> <ArrowDropDownIcon style={{ marginLeft: '0px' }} /></button>
                </div>
            </div>
            <hr></hr>

            {
                image_edited.length !== 0 && selectedcameras.length === image_edited.length ?
                    selectedcameras.map((val, i) => (
                        <Mask image_edited={val.edited_image} data1={val} camera_name={val.camera_gereral_name} mask1={val.mask} />
                    ))
                    :
                    <div>
                        {
                            selectedcameras.length === 0 ?
                                <div>
                                    <h5 style={{ color: '#e32747', fontWeight: 'bold', margin: 0, textAlign: 'center' }}>No camera's have been selected!</h5>
                                </div>
                                :
                                <div style={{ width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
                                    <CircularProgress size={'30px'} style={{ color: 'blue' }} />
                                    <p>Please Wait...</p>
                                </div>
                        }
                    </div>
            }
        </Grid>

    )
}

export default DrawRectangle;