import React, { useState, useEffect, useRef } from 'react';
import { Button, Container, Row, Col } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import CircularProgress from '@mui/material/CircularProgress';
import VideocamOffOutlinedIcon from '@mui/icons-material/VideocamOffOutlined';
import { WebRTCAdaptor } from '@antmedia/webrtc_adaptor';
import { CreateBucketCommand, S3Client, GetObjectCommand, ListBucketsCommand, DeleteBucketCommand, ListObjectsCommand, DeleteObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

const PlayingComponent = ({ i, data }) => {
  const [playing, setPlaying] = useState(false);
  const [videoFlag, setvideoFlag] = useState(1);
  const [websocketConnected, setWebsocketConnected] = useState(false);
  const [streamId, setStreamId] = useState(data.stream_id);
  const [imguri, setimguri] = useState('');
  const webRTCAdaptor = useRef(null);
  var playingStream = useRef(null);
  const handlePlay = () => {
    setPlaying(true);
    playingStream.current = streamId
    webRTCAdaptor.current.play(streamId);
  };

  const handleStopPlaying = () => {
    setPlaying(false);
    webRTCAdaptor.current.stop(playingStream.current);
  };

  const handleStreamIdChange = (event) => {
    setStreamId(event.target.value);
  };

  useEffect(() => {
    webRTCAdaptor.current = new WebRTCAdaptor({
      websocket_url: 'wss://live.tentovision.com:5443/WebRTCAppEE/websocket',
      mediaConstraints: {
        video: true,
        audio: true,
      },
      peerconnection_config: {
        iceServers: [{ urls: 'stun:stun1.l.google.com:19302' }],
      },
      sdp_constraints: {
        OfferToReceiveAudio: false,
        OfferToReceiveVideo: true, // Set to true to receive video
      },
      remoteVideoId: `video${i}`,
      callback: (info, obj) => {
        if (info === 'initialized') {
          setWebsocketConnected(true)
          handlePlay()
        }
      },
      callbackError: function (error, message) {
        console.log(error);
        console.log(message);
        if (error === 'no_stream_exist') {
          let div1 = document.getElementById(`div${i}`)
          console.log(div1);
          div1.style.display = 'none'

          let div2 = document.getElementById(`div1${i}`)
          div2.style.display = 'none'

          let div3 = document.getElementById(`div2${i}`)
          div3.style.display = 'none'

          let loadimg = document.getElementById(`loadimg${i}`)
          loadimg.style.display = 'none'

          let div4 = document.getElementById(`div3${i}`)
          div4.style.display = 'none'

          // let outerdiv = document.getElementById(`outerDiv${i}`)
          // outerdiv.style.height = '85%'

          let tech = document.getElementById(`tech${i}`)
          tech.style.display = 'block'


          // document.getElementById(`p1${i}`).innerText('yggfgf')
          handleStopPlaying();
          setPlaying(false);
        } else if (error === 'WebSocketNotConnected') {
          setvideoFlag(0)
        } else if (error === 'invalidStreamName') {
          let div1 = document.getElementById(`div${i}`)
          div1.style.display = 'none'

          let div2 = document.getElementById(`div1${i}`)
          div2.style.display = 'none'

          let div3 = document.getElementById(`div2${i}`)
          div3.style.display = 'none'

          let loadimg = document.getElementById(`loadimg${i}`)
          loadimg.style.display = 'none'

          let div4 = document.getElementById(`div3${i}`)
          div4.style.display = 'none'

          // let outerdiv = document.getElementById(`outerDiv${i}`)
          // outerdiv.style.height = '85%'

          let tech = document.getElementById(`tech${i}`)
          tech.style.display = 'block'

          // document.getElementById(`p1${i}`).innerText(`"${data.camera_gereral_name}"`)
          // document.getElementById(`p2${i}`).innerText('Please Check the Stream Name')
        }
      },
    });

    getimageuri('AKIA3CYTPKNZWMDIHN5F', '5YuMuo8u/tOTiEp7V7Zi1jM4Xtp5qPLRY1DRImEg', 'tentovision', data)

    return () => {
      if (playing)
        handleStopPlaying();
    }
  }, []);

  async function getimageuri(accessKeyId, secretAccessKey, Bucket, data) {
    const s3Client = new S3Client({
      region: "ap-south-1",
      credentials: {
        accessKeyId: accessKeyId,
        secretAccessKey: secretAccessKey,
      },
    });

    const image_command = new GetObjectCommand({
      Bucket: Bucket,
      Key: data.image_uri,
    });

    const image_url = await getSignedUrl(s3Client, image_command)
    setimguri(image_url)

  }

  return (
    <div>
      <div className='outerDiv' id={`outerDiv${i}`} style={{ backgroundColor: 'black', position: 'relative', height: '100%', width: '100%' }} onClick={() => {
        localStorage.setItem('cameraDetails', JSON.stringify(data))
        window.history.replaceState(null, null, "/Home/Home/" + data.camera_gereral_name)
        window.location.reload();

      }} onMouseOver={() => {
        let div = document.getElementById(`div${i}`)
        div.style.display = 'block'
      }} onMouseOut={() => {
        let div = document.getElementById(`div${i}`)
        div.style.display = 'none'
      }}>
        <video
          id={`video${i}`}
          autoPlay
          style={{
            width: '100%',
            height: '100%',
            maxWidth: '100%',
            maxHeight: '100%',
            lineHeight: 0, display: 'block', cursor: 'pointer', objectFit: 'cover'
          }}
          onPlay={() => {
            let div1 = document.getElementById(`div${i}`)
            div1.style.display = 'none'

            let div2 = document.getElementById(`div1${i}`)
            div2.style.display = 'block'

            let div3 = document.getElementById(`div2${i}`)
            div3.style.display = 'none'

            let loadimg = document.getElementById(`loadimg${i}`)
            loadimg.style.display = 'none'

            let div4 = document.getElementById(`div3${i}`)
            div4.style.display = 'none'

            // let outerdiv = document.getElementById(`outerDiv${i}`)
            // outerdiv.style.height = 'auto'

            let tech = document.getElementById(`tech${i}`)
            tech.style.display = 'none'
          }}

          onWaiting={() => {
            let div1 = document.getElementById(`div${i}`)
            div1.style.display = 'block'

            let div2 = document.getElementById(`div1${i}`)
            div2.style.display = 'none'

            let div3 = document.getElementById(`div2${i}`)
            div3.style.display = 'none'

            let loadimg = document.getElementById(`loadimg${i}`)
            loadimg.style.display = 'none'

            let div4 = document.getElementById(`div3${i}`)
            div4.style.display = 'block'

            // let outerdiv = document.getElementById(`outerDiv${i}`)
            // outerdiv.style.height = '85%'

            let tech = document.getElementById(`tech${i}`)
            tech.style.display = 'none'
          }}

          onPlaying={() => {
            let div1 = document.getElementById(`div${i}`)
            div1.style.display = 'none'

            let div2 = document.getElementById(`div1${i}`)
            div2.style.display = 'block'

            let div3 = document.getElementById(`div2${i}`)
            div3.style.display = 'none'

            let loadimg = document.getElementById(`loadimg${i}`)
            loadimg.style.display = 'none'

            let div4 = document.getElementById(`div3${i}`)
            div4.style.display = 'none'

            // let outerdiv = document.getElementById(`outerDiv${i}`)
            // outerdiv.style.height = 'auto'

            let tech = document.getElementById(`tech${i}`)
            tech.style.display = 'none'
          }}

          onPause={() => {
            let div1 = document.getElementById(`div${i}`)
            div1.style.display = 'block'

            let div2 = document.getElementById(`div1${i}`)
            div2.style.display = 'block'

            let div3 = document.getElementById(`div2${i}`)
            div3.style.display = 'none'

            let loadimg = document.getElementById(`loadimg${i}`)
            loadimg.style.display = 'none'

            let div4 = document.getElementById(`div3${i}`)
            div4.style.display = 'none'

            // let outerdiv = document.getElementById(`outerDiv${i}`)
            // outerdiv.style.height = 'auto'

            let tech = document.getElementById(`tech${i}`)
            tech.style.display = 'none'

            // document.getElementById(`p1${i}`).innerText(`"${data.camera_gereral_name}" camera is offline`)
            // document.getElementById(`p2${i}`).innerText('Please switch on the camera and try again!')
          }}

          onError={() => {
            let div1 = document.getElementById(`div${i}`)
            div1.style.display = 'none'

            let div2 = document.getElementById(`div1${i}`)
            div2.style.display = 'none'

            let div3 = document.getElementById(`div2${i}`)
            div3.style.display = 'none'

            let loadimg = document.getElementById(`loadimg${i}`)
            loadimg.style.display = 'none'


            let div4 = document.getElementById(`div3${i}`)
            div4.style.display = 'none'

            // let outerdiv = document.getElementById(`outerDiv${i}`)
            // outerdiv.style.height = '85%'

            let tech = document.getElementById(`tech${i}`)
            tech.style.display = 'block'

            // document.getElementById(`p1${i}`).innerText(`"${data.camera_gereral_name}" camera is offline`)
            // document.getElementById(`p2${i}`).innerText('Please switch on the camera and try again!')
          }}
        ></video>

        <div id={`loadimg${i}`} style={{ display: 'block' }}>
          <div style={{ position: 'absolute', bottom: 0, top: 0, left: 0, right: 0, width: '100%', height: '100%', backgroundColor: 'black', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>

            <img id={`loadimge${i}`} crossorigin="anonymous" style={{ style: 'none' }} width='100%' height="100%" src={imguri} onError={() => {
              // document.getElementById(`loadimge${i}`).src = 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Image_created_with_a_mobile_phone.png/1200px-Image_created_with_a_mobile_phone.png'
            }} onLoad={() => {
              document.getElementById(`loadimge${i}`).src = imguri
            }}></img>

          </div>
        </div>

        <div id={`div${i}`} style={{ position: 'absolute', bottom: 0, width: '100%', backgroundColor: 'rgba(0,0,0,0.5)', padding: '5px', display: 'block' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <p style={{ color: 'white', margin: 0 }}>{data.camera_gereral_name}</p>

            <div id={`div1${i}`} style={{ display: 'none' }}>
              <div style={{ display: 'flex', alignItems: 'center', }}>
                <div style={{ width: '10px', height: '10px', borderRadius: '50%', backgroundColor: '#00ff00' }}></div>
                <p style={{ color: 'white', marginLeft: '10px', marginBottom: 0 }}>Live</p>
              </div>
            </div>

            <div id={`div2${i}`} style={{ display: 'block', }}>
              <div style={{ display: 'flex', alignItems: 'center', }}>
                <CircularProgress size={'15px'} style={{ color: 'white' }} />
                <p style={{ color: 'white', marginLeft: '10px', marginBottom: 0 }}>Loading</p>
              </div>
            </div>

            <div id={`div3${i}`} style={{ display: 'none', }}>
              <div style={{ display: 'flex', alignItems: 'center', }}>
                <CircularProgress size={'15px'} style={{ color: 'white' }} />
                <p style={{ color: 'white', marginLeft: '10px', marginBottom: 0 }}>Buffering</p>
              </div>
            </div>
          </div>
        </div>

        <div id={`tech${i}`} style={{ display: 'none' }}>
          <div style={{ position: 'absolute', bottom: 0, top: 0, left: 0, right: 0, width: '100%', height: '100%', backgroundColor: 'black', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
            {/* {console.log('https://sgp1.digitaloceanspaces.com/tentovision/' +
              'tento1' +
              '/' +
              data.camera_gereral_name +
              '.jpg' +
              '?' +
              new Date(),)} */}
            <img id={`orginal_image${i}`} crossorigin="anonymous" style={{ filter: 'blur(1px)' }} width='100%' height="100%" src={imguri} onError={() => {
              document.getElementById(`errorimage${i}`).style.display = 'block'
            }} onLoad={() => {
              document.getElementById(`errorimage${i}`).style.display = 'none'
            }}></img>

            <img id={`errorimage${i}`} crossorigin="anonymous" style={{ filter: 'blur(1px)', style: 'none', display: 'none' }} width='100%' height="100%" src='https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Image_created_with_a_mobile_phone.png/1200px-Image_created_with_a_mobile_phone.png' onLoad={() => {
              document.getElementById(`orginal_image${i}`).style.display = 'none'
            }}></img>

            <div style={{ position: 'absolute', bottom: 0, top: 0, left: 0, right: 0, width: '100%', height: '100%', backgroundColor: 'black', opacity: '0.5' }}></div>

            <div style={{ position: 'absolute', bottom: 0, top: 0, left: 0, right: 0, width: '100%', height: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column', padding: '5px' }}>
              <div style={{ backgroundColor: 'red', borderRadius: '50%', padding: '5px' }}>
                <VideocamOffOutlinedIcon style={{ color: 'white' }} />
              </div>
              <p id={`p1${i}`} style={{ color: 'white', margin: '0px', fontWeight: 'bolder' }}>"{data.camera_gereral_name}" camera is offline</p>
              <p id={`p2${i}`} style={{ color: 'white', margin: '0px', fontSize: '10px' }}>Please switch on the camera and try again!</p>
            </div>
          </div>
        </div>

        {videoFlag === 0 ?
          <div style={{ position: 'absolute', bottom: 0, top: 0, left: 0, right: 0, width: '100%', height: '100%', backgroundColor: 'black', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
            <VideocamOffOutlinedIcon style={{ color: 'gray' }} />
            <p style={{ color: 'white' }}>No internet</p>
          </div> : ''}
      </div>
    </div >
  );
};

export default PlayingComponent;
