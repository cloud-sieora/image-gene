import React, { useEffect, useState } from 'react'
import {
  Row,
  Col,
  Card,
  Table,
  Tabs,
  Tab,
  Container,
  Button,
} from "react-bootstrap";
import Modal from '@mui/material/Modal';
import CloseIcon from '@mui/icons-material/Close';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import ArrowDropUpIcon from '@mui/icons-material/ArrowDropUp';
import CloudOffRoundedIcon from '@mui/icons-material/CloudOffRounded';
import CircularProgress from '@mui/material/CircularProgress';
import { date } from '../DateTimeFun'
import '../style.css'

export default function Index() {
  const date1 = date()
  const userData = JSON.parse(localStorage.getItem("userData"))
  const [open1, setOpen1] = React.useState(false);
  const [clickbtn1, setclickbtn1] = useState(false)
  const [btn1, setbtn1] = useState('')
  const [type, settype] = useState('')
  const [config, setconfig] = useState(true)
  const [startDate, setstartDate] = useState('')
  const [startTime, setstartTime] = useState('')
  const [endDate, setendDate] = useState('')
  const [endTime, setendTime] = useState('')
  const [data, setdata] = useState([])
  const [res, setres] = useState('')
  const [apply, setapply] = useState(true)
  const [selecteddata, setselecteddata] = useState('')

  useEffect(() => {
    setres('')
    const axios = require('axios');
    let data = JSON.stringify({
      "user_id": userData._id,
      "start_date": startDate,
      "end_date": endDate,
    });

    let config = {
      method: 'post',
      maxBodyLength: Infinity,
      url: 'https://tentovision1.cloudjiffy.net/alert_creation_api_device_get/',
      headers: {
        'Content-Type': 'application/json'
      },
      data: data
    };

    axios.request(config)
      .then((response) => {
        console.log(JSON.stringify(response.data));
        setdata(response.data)
        if (response.data.length === 0) {
          setres('empty response')
        } else {
          setres('')
        }
      })
      .catch((error) => {
        console.log(error);
      })
  }, [apply])

  const handleOpen1 = () => setOpen1(true);
  const handleClose1 = () => setOpen1(false);

  const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    boxShadow: 24,
  };

  if (config === true) {
    setstartDate(date1[0])
    setstartTime('00:00')
    setendDate(date1[1])
    setendTime(`${date1[2]}:${date1[3]}`)
    settype()
    setconfig(false)
  }

  if (clickbtn1 === true) {
    if (btn1 === 'day') {
      setbtn1('')
      let btn = document.getElementById('day')
      btn.style.backgroundColor = '#f0f0f0'
      btn.style.color = 'black'
    } else if (btn1 === '' || btn1 === 'analytics') {
      setbtn1('day')
      let btn = document.getElementById('day')
      btn.style.backgroundColor = '#e32747'
      btn.style.color = 'white'
    }
    setclickbtn1(false)
  }
  return (
    <>

      <div>
        <Modal
          open={open1}
          onClose={handleClose1}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
          style={{ overflowY: 'scroll' }}
        >
          <Row>
            <Col xl={6} lg={6} md={6} sm={12} xs={12} style={style}>
              <div >

                <div style={{ backgroundColor: 'white', borderRadius: '5px', }}>
                  {/* <Row style={{ padding: '10px', alignItems: 'center' }}>

                    <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end' }}>
                        <CloseIcon style={{ color: 'black' }} onClick={() => handleClose1()} />
                      </div>
                    </Col>

                  </Row> */}

                  <Row style={{ alignItems: 'center' }}>

                    <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                      <div style={{ backgroundColor: '#181828', padding: '20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderTopLeftRadius: '5px', borderTopRightRadius: '5px' }}>
                        <p style={{ margin: 0, color: 'white', fontSize: '20px', }}>Alert from TentoVision</p>
                        <CloseIcon style={{ color: 'white' }} onClick={() => handleClose1()} />
                      </div>
                    </Col>

                  </Row>

                  <Row style={{ alignItems: 'center' }}>

                    <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                      <div style={{}}>
                        <img width='100%' src={selecteddata.uri}></img>
                      </div>
                    </Col>

                  </Row>

                  <Row style={{ alignItems: 'center' }}>

                    <Col xl={12} lg={12} md={12} sm={12} xs={12}>
                      <div style={{ margin: '15px', borderBottom: '1px solid grey' }}>
                        <p style={{ margin: 0, marginBottom: '15px', color: 'black', fontSize: '20px', fontWeight: 'bold' }}>{selecteddata.camera_name}, {selecteddata.date} at {selecteddata.time} </p>
                      </div>
                    </Col>

                  </Row>

                  <Row style={{ padding: '10px', alignItems: 'center' }}>

                    <Col xl={3} lg={3} md={3} sm={6} xs={6}>
                      <div style={{}}>
                        <p style={{ color: 'black', fontWeight: 'bold', margin: 0, fontSize: '18px' }}>Device id</p>
                        <p style={{ color: 'black', margin: '5px' }}>{selecteddata.device_id}</p>
                      </div>
                    </Col>

                    <Col xl={3} lg={3} md={3} sm={6} xs={6}>
                      <div style={{}}>
                        <p style={{ color: 'black', fontWeight: 'bold', margin: 0, fontSize: '18px' }}>Message</p>
                        <p style={{ color: 'black', margin: '5px' }}>{selecteddata.msg}</p>
                      </div>
                    </Col>

                    <Col xl={3} lg={3} md={3} sm={6} xs={6}>
                      <div style={{}}>
                        <p style={{ color: 'black', fontWeight: 'bold', margin: 0, fontSize: '18px' }}>Mobile number</p>
                        <p style={{ color: 'black', margin: '5px' }}>{selecteddata.mobile_number}</p>
                      </div>
                    </Col>

                    <Col xl={3} lg={3} md={3} sm={6} xs={6}>
                      <div style={{}}>
                        <p style={{ color: 'black', fontWeight: 'bold', margin: 0, fontSize: '18px' }}>Location</p>
                        <p style={{ color: 'black', margin: '5px' }}>{selecteddata.device_location}</p>
                      </div>
                    </Col>

                  </Row>
                </div>
              </div>
            </Col>
          </Row>
        </Modal>
      </div>


      <Row style={{ padding: '10px', alignItems: 'center', position: 'sticky', top: 0, zIndex: 1, marginTop: 0 }}>
        <div style={{ position: 'relative', backgroundColor: '#1b0182', width: '100%', padding: '15px' }}>
          <button className='eventbtn' id='day' onClick={() => {
            setclickbtn1(true)

          }}> <AccessTimeIcon style={{ marginRight: '10px' }} />{`${startDate} (${startTime}) - ${endDate} (${endTime})`} <ArrowDropDownIcon style={{ marginLeft: '10px' }} /></button>

          <div>
            <div style={{ width: '500px', borderRadius: '5px', backgroundColor: '#181828', padding: '10px', position: 'absolute', top: '65px', boxShadow: 'rgba(0, 0, 0, 0.35) 0px 5px 15px', display: btn1 === 'day' ? 'block' : 'none' }}>
              <div style={{ position: 'relative' }}>

                <ArrowDropUpIcon style={{ fontSize: '50px', color: '#181828', margin: 0, position: 'absolute', top: '-37px', left: 0 }} />
                <div style={{ display: 'flex', justifyContent: 'flex-end', flexDirection: 'column', alignItems: 'flex-end' }}>
                  <div style={{ backgroundColor: '#e32747', borderRadius: '50%', padding: '2px', display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '10px' }}>
                    <CloseIcon style={{ fontSize: '12px', color: 'white' }} onClick={() => {
                      setclickbtn1(true)
                    }} />
                  </div>
                </div>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', padding: '10px', justifyContent: 'space-between' }}>
                    <p style={{ margin: 0, color: 'white', fontWeight: 'bolder' }}>Start</p>
                    <input type="date" value={startDate} style={{ padding: '10px', borderRadius: '5px' }} onChange={(e) => {
                      console.log('lkjlj');
                      setstartDate(e.target.value)
                    }}></input>
                    <input type="time" value={startTime} style={{ padding: '10px', borderRadius: '5px' }} onChange={(e) => {

                      setstartTime(e.target.value)
                    }}></input>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', padding: '10px', justifyContent: 'space-between' }}>
                    <p style={{ margin: 0, color: 'white', fontWeight: 'bolder' }}>End</p>
                    <input type="date" value={endDate} style={{ padding: '10px', borderRadius: '5px' }} onChange={(e) => {
                      setendDate(e.target.value)
                    }}></input>
                    <input type="time" value={endTime} style={{ padding: '10px', borderRadius: '5px' }} onChange={(e) => {
                      setendTime(e.target.value)
                    }}></input>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'flex-end', paddingRight: '10px' }}>
                    <button className="my-2" style={{ backgroundColor: '#e32747', color: 'white', borderRadius: '5px', border: 'none', padding: '5px' }} onClick={() => {
                      setclickbtn1(true)
                      setapply(!apply)
                      document.getElementById('day').innerText = `${startDate} (${startTime}) - ${endDate} (${endTime})`
                    }}>Apply</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Row>


      <Row style={{ padding: '10px', alignItems: 'center' }}>

        {
          data.length !== 0 ?
            <Col xl={12} lg={12} md={12} sm={12} xs={12} style={{ overflowX: 'scroll', backgroundColor: 'white' }}>
              <table style={{ width: '100%', backgroundColor: 'white', marginTop: '15px' }}>
                <tr style={{ backgroundColor: '#e6e8eb', color: 'black' }}>
                  <th style={{ padding: '15px' }}>Alert image</th>
                  <th style={{ padding: '15px' }}>Camera name</th>
                  <th style={{ padding: '15px' }}>Date</th>
                  <th style={{ padding: '15px' }}>Time</th>
                  <th style={{ padding: '15px' }}>Location</th>
                </tr>
                {
                  data.map((val) => (
                    <tr style={{ borderBottom: '1px solid grey', color: 'black' }}>
                      <td style={{ padding: '15px' }} onClick={() => {
                        handleOpen1()
                        setselecteddata(val)
                      }}><img width={150} height={100} style={{ cursor: 'pointer' }} src={val.uri}></img></td>
                      <td style={{ padding: '15px' }}>{val.camera_name}</td>
                      <td style={{ padding: '15px' }}>{val.date}</td>
                      <td style={{ padding: '15px' }}>{val.time}</td>
                      <td style={{ padding: '15px' }}>{val.device_location}</td>
                    </tr>
                  ))
                }
              </table>

            </Col>
            :
            <Col xl={12} lg={12} md={12} sm={12} xs={12}>
              {
                res === 'empty response' ?
                  <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', padding: '10px' }}>
                    <CloudOffRoundedIcon size={'50px'} style={{ color: '#e32747' }} />
                    <h5 style={{ color: '#e32747', fontWeight: 'bold', margin: 0 }}>No alerts found!</h5>
                  </div>
                  :
                  <div style={{ width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
                    <CircularProgress size={'30px'} style={{ color: 'blue' }} />
                    <p>Please Wait...</p>
                  </div>
              }
            </Col>

        }



      </Row>
    </>
  )
}
